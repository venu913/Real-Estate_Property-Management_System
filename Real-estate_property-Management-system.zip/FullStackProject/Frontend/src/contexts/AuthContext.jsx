import { createContext, useContext, useEffect, useMemo, useState, useCallback } from "react";
import api from "../services/api";
import { authService } from "../services/auth.service";
import {
  ROLE_OVERRIDE_STORAGE_KEY,
  deriveRoleFromUser,
  resolveEffectiveRole,
} from "@/lib/authPaths";
import {
  clearAllAuthTokens,
  getInactiveSessions,
  hasOtherSavedSessions,
  switchToSessionToken,
} from "@/lib/authTokens";

const AuthContext = createContext({
  session: null,
  user: null,
  profile: null,
  roles: [],
  /** 'buyer' | 'agent' | 'admin' — includes QA override */
  role: "buyer",
  /** Role from API only */
  serverRole: "buyer",
  isAdmin: false,
  isAgent: false,
  isBuyer: true,
  roleOverride: null,
  setRoleOverride: () => {},
  loading: true,
  signOut: async () => {},
  refreshProfile: async () => {},
  switchToSavedSession: async () => {},
  inactiveSessions: [],
  hasOtherSavedSessions: false,
  api: null,
});

export const useAuth = () => useContext(AuthContext);

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [roles, setRoles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [sessionEpoch, setSessionEpoch] = useState(0);
  const [roleOverride, setRoleOverrideState] = useState(() =>
    typeof window !== "undefined"
      ? localStorage.getItem(ROLE_OVERRIDE_STORAGE_KEY)
      : null,
  );

  const setRoleOverride = useCallback((value) => {
    if (value === null || value === undefined || value === "") {
      localStorage.removeItem(ROLE_OVERRIDE_STORAGE_KEY);
      setRoleOverrideState(null);
    } else {
      localStorage.setItem(ROLE_OVERRIDE_STORAGE_KEY, value);
      setRoleOverrideState(value);
    }
  }, []);

  /** Buyer accounts have no role override; clear stale localStorage from older builds. */
  useEffect(() => {
    if (!profile) return;
    const sr = deriveRoleFromUser({
      role: profile.role,
      is_agent: profile.is_agent,
      roles,
    });
    if (sr === "buyer" && roleOverride != null) {
      setRoleOverride(null);
    }
  }, [profile, roles, roleOverride, setRoleOverride]);

  const fetchUser = useCallback(async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      setUser(null);
      setProfile(null);
      setRoles([]);
      setSession(null);
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      const userData = await authService.me();
      setUser({ id: userData._id, email: userData.email });
      setProfile({
        user_id: userData._id,
        full_name: userData.full_name,
        role: userData.role,
        is_agent: userData.is_agent,
        phone: userData.phone,
        savedProperties: userData.savedProperties,
        agent_verified: userData.agent_verified,
        company_name: userData.company_name,
        // --- Agent full profile fields ---
        avatar_url: userData.avatar_url,
        cover_url: userData.cover_url,
        bio: userData.bio,
        city: userData.city,
        state: userData.state,
        languages: userData.languages,
        specialization: userData.specialization,
        experience_years: userData.experience_years,
        certifications: userData.certifications,
        agency_name: userData.agency_name,
        rera_number: userData.rera_number,
        website: userData.website,
        social: userData.social,
        show_contact: userData.show_contact,
        availability: userData.availability,
        public_profile: userData.public_profile,
        rating: userData.rating,
        rating_count: userData.rating_count,
      });
      setRoles(userData.roles || []);
      setSession({ access_token: token });
    } catch (error) {
      console.error("Failed to fetch user:", error);
      clearAllAuthTokens();
      setUser(null);
      setProfile(null);
      setRoles([]);
      setSession(null);
    } finally {
      setLoading(false);
    }
  }, []);

  const refreshProfile = async () => {
    await fetchUser();
  };

  useEffect(() => {
    fetchUser();
  }, [sessionEpoch, fetchUser]);

  const bumpSession = useCallback(() => setSessionEpoch((n) => n + 1), []);

  const switchToSavedSession = useCallback(
    async (selectedToken) => {
      const email = user?.email || "";
      if (!switchToSessionToken(selectedToken, email)) return;
      await fetchUser();
    },
    [fetchUser, user?.email],
  );

  const inactiveSessions =
    typeof window !== "undefined" ? getInactiveSessions() : [];
  const hasSavedSessions =
    typeof window !== "undefined" && hasOtherSavedSessions();

  const serverRole = useMemo(() => {
    const fromProfile = profile
      ? deriveRoleFromUser({
          role: profile.role,
          is_agent: profile.is_agent,
          roles,
        })
      : "buyer";
    return fromProfile;
  }, [profile, roles]);

  const role = useMemo(
    () => resolveEffectiveRole(serverRole, roleOverride),
    [serverRole, roleOverride],
  );

  const isAdmin = role === "admin";
  const isAgent = role === "agent" || role === "admin";
  const isBuyer = role === "buyer";

  const signOut = async () => {
    clearAllAuthTokens();
    bumpSession();
  };

  return (
    <AuthContext.Provider
      value={{
        session,
        user,
        profile,
        roles,
        role,
        serverRole,
        isAdmin,
        isAgent,
        isBuyer,
        roleOverride,
        setRoleOverride,
        loading,
        signOut,
        refreshProfile,
        switchToSavedSession,
        inactiveSessions,
        hasOtherSavedSessions: hasSavedSessions,
        api,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
