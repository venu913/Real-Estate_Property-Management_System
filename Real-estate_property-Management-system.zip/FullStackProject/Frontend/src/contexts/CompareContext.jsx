import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { toast as sonner } from "sonner";

const STORAGE_KEY = "propnest_compare_v1";
export const MAX_COMPARE = 4;

function readStored() {
  try {
    const raw = sessionStorage.getItem(STORAGE_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr.slice(0, MAX_COMPARE) : [];
  } catch {
    return [];
  }
}

/** Used when CompareProvider is missing (e.g. stale HMR) — compare becomes a no-op. */
const compareFallback = {
  items: [],
  ids: [],
  count: 0,
  max: MAX_COMPARE,
  hasProperty: () => false,
  addProperty: () => ({ ok: false, reason: "no-provider" }),
  removeProperty: () => {},
  clearAll: () => {},
};

const CompareContext = createContext(compareFallback);

export function CompareProvider({ children }) {
  const [items, setItems] = useState(readStored);
  const itemsRef = useRef(items);
  itemsRef.current = items;

  useEffect(() => {
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      /* ignore */
    }
  }, [items]);

  const ids = useMemo(
    () => items.map((p) => String(p._id || p.id)).filter(Boolean),
    [items],
  );

  const hasProperty = useCallback(
    (id) => ids.includes(String(id)),
    [ids],
  );

  const addProperty = useCallback((property) => {
    const id = String(property?._id || property?.id || "");
    if (!id) return { ok: false, reason: "invalid" };
    const prev = itemsRef.current;
    if (prev.some((p) => String(p._id || p.id) === id)) {
      sonner.message("Already in compare", {
        description: "This listing is on your list.",
      });
      return { ok: false, reason: "duplicate" };
    }
    if (prev.length >= MAX_COMPARE) {
      sonner.error("Compare list full", {
        description: `You can compare up to ${MAX_COMPARE} properties.`,
      });
      return { ok: false, reason: "full" };
    }
    sonner.success("Added to compare", { description: property.title });
    setItems([...prev, property]);
    return { ok: true };
  }, []);

  const removeProperty = useCallback((id) => {
    setItems((prev) => prev.filter((p) => String(p._id || p.id) !== String(id)));
  }, []);

  const clearAll = useCallback(() => setItems([]), []);

  const value = useMemo(
    () => ({
      items,
      ids,
      count: items.length,
      hasProperty,
      addProperty,
      removeProperty,
      clearAll,
      max: MAX_COMPARE,
    }),
    [items, ids, hasProperty, addProperty, removeProperty, clearAll],
  );

  return (
    <CompareContext.Provider value={value}>{children}</CompareContext.Provider>
  );
}

export function useCompare() {
  return useContext(CompareContext);
}
