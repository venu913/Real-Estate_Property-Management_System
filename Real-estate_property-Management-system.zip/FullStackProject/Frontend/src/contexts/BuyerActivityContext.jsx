import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import api from "@/services/api";
import { useAuth } from "./AuthContext";

const STORAGE_RECENT = "recentlyViewed";
const STORAGE_ACTIVITY = "propnest_buyer_activity";
const STORAGE_SEARCH = "propnest_search_prefs";
const STORAGE_ONBOARD = "propnest_onboarding_v1";

/** Safe defaults when provider is missing (e.g. stale HMR) — matches Provider API shape. */
const buyerActivityFallback = {
  recentIds: [],
  activity: { cities: [], categories: [] },
  searchPrefs: null,
  onboarding: { completed: false, skipped: false },
  notifications: [],
  recordPropertyView: () => {},
  clearRecentlyViewed: () => {},
  recordSearchPrefs: () => {},
  completeOnboarding: () => {},
  skipOnboarding: () => {},
  markNotificationRead: () => {},
  addNotification: () => {},
  deleteNotification: () => {},
};

const BuyerActivityContext = createContext(buyerActivityFallback);

function readRecentIds() {
  try {
    const raw = localStorage.getItem(STORAGE_RECENT);
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr.filter(Boolean).map(String) : [];
  } catch {
    return [];
  }
}

function readActivity() {
  try {
    const raw = localStorage.getItem(STORAGE_ACTIVITY);
    const data = raw ? JSON.parse(raw) : {};
    return {
      cities: Array.isArray(data.cities) ? data.cities : [],
      categories: Array.isArray(data.categories) ? data.categories : [],
    };
  } catch {
    return { cities: [], categories: [] };
  }
}

function readSearchPrefs() {
  try {
    const raw = localStorage.getItem(STORAGE_SEARCH);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function readOnboarding() {
  try {
    const raw = localStorage.getItem(STORAGE_ONBOARD);
    if (!raw) return { completed: false };
    const data = JSON.parse(raw);
    return {
      completed: Boolean(data.completed),
      skipped: Boolean(data.skipped),
      city: data.city || "",
      budgetMin: data.budgetMin,
      budgetMax: data.budgetMax,
      propertyType: data.propertyType || "",
      completedAt: data.completedAt,
    };
  } catch {
    return { completed: false };
  }
}

export function BuyerActivityProvider({ children }) {
  const [recentIds, setRecentIds] = useState(readRecentIds);
  const [activity, setActivity] = useState(readActivity);
  const [searchPrefs, setSearchPrefs] = useState(readSearchPrefs);
  const [onboarding, setOnboardingState] = useState(readOnboarding);
  const { user } = useAuth();
  const queryClient = useQueryClient();

  const { data: notificationsData } = useQuery({
    queryKey: ['notifications', user?.id],
    queryFn: async () => {
      const res = await api.get('/notifications');
      return res.data;
    },
    enabled: !!user,
  });

  const notifications = useMemo(() => {
    if (!user) return [];
    return notificationsData?.data || [];
  }, [notificationsData, user]);

  const markReadMutation = useMutation({
    mutationFn: async (id) => {
      await api.put(`/notifications/${id}/read`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications', user?.id]);
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id) => {
      await api.delete(`/notifications/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications', user?.id]);
    }
  });

  const markNotificationRead = useCallback((id) => {
    markReadMutation.mutate(id);
  }, [markReadMutation]);

  const deleteNotification = useCallback((id) => {
    deleteMutation.mutate(id);
  }, [deleteMutation]);

  const addNotificationMutation = useMutation({
    mutationFn: async (notification) => {
      const res = await api.post('/notifications', {
        title: notification.title,
        body: notification.body,
        type: notification.type || 'system'
      });
      return res.data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['notifications', user?.id]);
    }
  });

  const addNotification = useCallback((notification) => {
    if (user) {
      addNotificationMutation.mutate(notification);
    }
  }, [user, addNotificationMutation]);

  const persistRecent = useCallback((ids) => {
    localStorage.setItem(STORAGE_RECENT, JSON.stringify(ids));
    setRecentIds(ids);
  }, []);

  const persistActivity = useCallback((next) => {
    localStorage.setItem(STORAGE_ACTIVITY, JSON.stringify(next));
    setActivity(next);
  }, []);

  const recordSearchPrefs = useCallback((partial) => {
    const next = {
      ...partial,
      updatedAt: Date.now(),
    };
    localStorage.setItem(STORAGE_SEARCH, JSON.stringify(next));
    setSearchPrefs(next);
  }, []);

  const completeOnboarding = useCallback((prefs) => {
    const next = {
      completed: true,
      skipped: false,
      city: prefs.city || "",
      budgetMin: prefs.budgetMin,
      budgetMax: prefs.budgetMax,
      propertyType: prefs.propertyType || "",
      completedAt: Date.now(),
    };
    localStorage.setItem(STORAGE_ONBOARD, JSON.stringify(next));
    setOnboardingState(next);
  }, []);

  const skipOnboarding = useCallback(() => {
    const next = {
      completed: true,
      skipped: true,
      completedAt: Date.now(),
    };
    localStorage.setItem(STORAGE_ONBOARD, JSON.stringify(next));
    setOnboardingState(next);
  }, []);



  const recordPropertyView = useCallback(
    (property) => {
      const id = property?._id || property?.id;
      if (!id) return;

      const prev = readRecentIds();
      const next = [String(id), ...prev.filter((x) => x !== String(id))].slice(
        0,
        12,
      );
      persistRecent(next);

      const city = property.city;
      const category = property.category;
      const act = readActivity();
      const cities = city
        ? [city, ...act.cities.filter((c) => c !== city)].slice(0, 5)
        : act.cities;
      const categories = category
        ? [category, ...act.categories.filter((c) => c !== category)].slice(
            0,
            5,
          )
        : act.categories;
      persistActivity({ cities, categories });
    },
    [persistRecent, persistActivity],
  );

  const clearRecentlyViewed = useCallback(() => {
    localStorage.removeItem(STORAGE_RECENT);
    setRecentIds([]);
  }, []);

  useEffect(() => {
    const onStorage = (e) => {
      if (e.key === STORAGE_RECENT) setRecentIds(readRecentIds());
      if (e.key === STORAGE_ACTIVITY) setActivity(readActivity());
      if (e.key === STORAGE_SEARCH) setSearchPrefs(readSearchPrefs());
      if (e.key === STORAGE_ONBOARD) setOnboardingState(readOnboarding());
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);

  const value = useMemo(
    () => ({
      recentIds,
      activity,
      searchPrefs,
      onboarding,
      notifications,
      recordPropertyView,
      clearRecentlyViewed,
      recordSearchPrefs,
      completeOnboarding,
      skipOnboarding,
      markNotificationRead,
      addNotification,
      deleteNotification,
    }),
    [
      recentIds,
      activity,
      searchPrefs,
      onboarding,
      notifications,
      recordPropertyView,
      clearRecentlyViewed,
      recordSearchPrefs,
      completeOnboarding,
      skipOnboarding,
      markNotificationRead,
      addNotification,
      deleteNotification,
    ],
  );

  return (
    <BuyerActivityContext.Provider value={value}>
      {children}
    </BuyerActivityContext.Provider>
  );
}

export function useBuyerActivity() {
  return useContext(BuyerActivityContext);
}
