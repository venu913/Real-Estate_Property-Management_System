import { useState, useEffect, useRef, useCallback } from 'react';
import { io } from 'socket.io-client';
import api, { dashboardAPI } from '@/services/api';
import { useToast } from '@/hooks/use-toast';

// Custom hook for dashboard statistics with real-time updates
export const useDashboardStats = (initialStats = {}) => {
  const [stats, setStats] = useState({
    totalProperties: 0,
    totalUsers: 0,
    totalBookings: 0,
    totalRevenue: 0,
    activeListings: 0,
    soldProperties: 0,
    monthlyBookings: 0,
    monthlyRevenue: 0,
    ...initialStats
  });
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [revenueData, setRevenueData] = useState([]);
  const [bookingTrends, setBookingTrends] = useState([]);
  const [timeFilter, setTimeFilter] = useState('30d');
  
  const socketRef = useRef(null);
  const { toast } = useToast();

  // Fetch dashboard stats from API
  const fetchStats = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await dashboardAPI.getStats();
      if (response.data.success) {
        setStats(response.data.data);
      } else {
        throw new Error(response.data.message);
      }
    } catch (err) {
      console.error('Failed to fetch dashboard stats:', err);
      setError(err.message);
      toast({
        title: "Error",
        description: "Failed to load dashboard statistics",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [toast]);

  // Fetch revenue data for charts
  const fetchRevenueData = useCallback(async (period = timeFilter) => {
    try {
      const response = await dashboardAPI.getRevenue(period);
      if (response.data.success) {
        setRevenueData(response.data.data);
      }
    } catch (err) {
      console.error('Failed to fetch revenue data:', err);
    }
  }, [timeFilter]);

  // Fetch booking trends
  const fetchBookingTrends = useCallback(async (period = timeFilter) => {
    try {
      const response = await dashboardAPI.getBookingTrends(period);
      if (response.data.success) {
        setBookingTrends(response.data.data);
      }
    } catch (err) {
      console.error('Failed to fetch booking trends:', err);
    }
  }, [timeFilter]);

  // Initialize Socket.io connection
  useEffect(() => {
    const socket = io(process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000', {
      transports: ['websocket', 'polling']
    });
    
    socketRef.current = socket;

    // Join agent-specific room if user is authenticated
    const user = JSON.parse(localStorage.getItem('user'));
    if (user?.id) {
      socket.emit('join-agent-room', user.id);
    }

    // Listen for real-time dashboard updates
    socket.on('dashboard-update', (data) => {
      console.log('Dashboard update received:', data);
      
      // Update stats based on the type of update
      setStats(prevStats => {
        const newStats = { ...prevStats };
        
        switch (data.type) {
          case 'property-created':
            newStats.totalProperties += 1;
            newStats.activeListings += 1;
            break;
          case 'property-updated':
            // Refresh stats when property is updated
            fetchStats();
            break;
          case 'property-deleted':
            newStats.totalProperties -= 1;
            newStats.activeListings -= 1;
            break;
          case 'booking-created':
            newStats.totalBookings += 1;
            newStats.monthlyBookings += 1;
            if (data.data.amount) {
              newStats.totalRevenue += data.data.amount;
              newStats.monthlyRevenue += data.data.amount;
            }
            break;
          case 'user-registered':
            newStats.totalUsers += 1;
            break;
          case 'property-sold':
            newStats.soldProperties += 1;
            newStats.activeListings -= 1;
            break;
        }
        
        return newStats;
      });
    });

    // Listen for agent-specific updates
    socket.on('agent-dashboard-update', (data) => {
      console.log('Agent dashboard update received:', data);
      
      // Refresh stats for agent-specific updates
      if (data.type === 'property-updated' || data.type === 'property-sold') {
        fetchStats();
      }
    });

    // Handle connection errors
    socket.on('connect_error', (error) => {
      console.error('Socket connection error:', error);
    });

    socket.on('disconnect', () => {
      console.log('Socket disconnected');
    });

    return () => {
      socket.disconnect();
    };
  }, [fetchStats]);

  // Initial data fetch
  useEffect(() => {
    fetchStats();
    fetchRevenueData();
    fetchBookingTrends();
  }, [fetchStats, fetchRevenueData, fetchBookingTrends]);

  // Refresh data when time filter changes
  useEffect(() => {
    fetchRevenueData();
    fetchBookingTrends();
  }, [timeFilter, fetchRevenueData, fetchBookingTrends]);

  // Manual refresh function
  const refreshStats = useCallback(() => {
    fetchStats();
    fetchRevenueData();
    fetchBookingTrends();
  }, [fetchStats, fetchRevenueData, fetchBookingTrends]);

  // Update time filter
  const updateTimeFilter = useCallback((newFilter) => {
    setTimeFilter(newFilter);
  }, []);

  return {
    stats,
    loading,
    error,
    revenueData,
    bookingTrends,
    timeFilter,
    refreshStats,
    updateTimeFilter,
    socket: socketRef.current
  };
};
