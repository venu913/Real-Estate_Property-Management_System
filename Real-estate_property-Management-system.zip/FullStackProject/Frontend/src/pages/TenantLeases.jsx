import React from 'react';
import { useQuery } from '@tanstack/react-query';
import api from '@/services/api';

export default function TenantLeases() {
  const { data, isLoading, error } = useQuery({
    queryKey: ['my-leases'],
    queryFn: async () => {
      const res = await api.get('/leases/my');
      return res.data;
    }
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-4xl mx-auto mt-10 p-6 bg-red-50 text-red-600 rounded-lg">
        <p>Error loading leases: {error.message}</p>
      </div>
    );
  }

  const leases = data?.data || [];

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">My Leases</h1>

      {leases.length === 0 ? (
        <div className="bg-white rounded-lg shadow p-8 text-center">
          <h2 className="text-xl font-medium text-gray-700 mb-2">You have no active leases.</h2>
          <p className="text-gray-500">When an owner accepts your rental inquiry, your lease will appear here.</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {leases.map((lease) => (
            <div key={lease._id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow">
              <div className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    lease.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                  }`}>
                    {lease.status.charAt(0).toUpperCase() + lease.status.slice(1)}
                  </span>
                  <span className="text-sm text-gray-500 font-medium">
                    {new Date(lease.startDate).toLocaleDateString('en-US', {
                      month: 'short', day: 'numeric', year: 'numeric'
                    })} 
                    {' - '} 
                    {lease.endDate ? new Date(lease.endDate).toLocaleDateString('en-US', {
                      month: 'short', day: 'numeric', year: 'numeric'
                    }) : 'Ongoing'}
                  </span>
                </div>
                
                <h3 className="text-lg font-semibold text-gray-900 mb-1">
                  {lease.property_id?.title || 'Unknown Property'}
                </h3>
                <p className="text-sm text-gray-500 mb-4 line-clamp-1">
                  {lease.property_id?.address || 'No address provided'}
                </p>
                
                <div className="pt-4 border-t border-gray-100">
                  <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">Owner Details</h4>
                  <p className="text-sm text-gray-900 font-medium">{lease.owner_id?.name || 'Unknown Owner'}</p>
                  <p className="text-sm text-gray-600">{lease.owner_id?.email || 'No email'}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
