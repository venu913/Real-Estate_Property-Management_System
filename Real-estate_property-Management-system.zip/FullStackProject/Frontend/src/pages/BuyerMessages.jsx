import { useState, useEffect, useRef } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  MessageSquare,
  Send,
  Phone,
  MapPin,
  ArrowLeft,
  Search,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { toTelHref } from "@/lib/phone";

export default function BuyerMessages() {
  const { user } = useAuth();
  const [threads, setThreads] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef(null);

  useEffect(() => {
    fetchThreads();
    // Listen for socket events
    if (user && globalThis.window?.io) {
      // Connect specifically is handled in main.jsx/App.jsx but we assume we joined the room
    }
  }, [user]);

  useEffect(() => {
    if (activeId) {
      fetchMessages(activeId);
    }
  }, [activeId]);

  useEffect(() => {
    // Scroll to bottom when messages load
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const fetchThreads = async () => {
    try {
      const { data } = await api.get('/messages/threads');
      setThreads(data);
      if (data.length > 0 && !activeId) {
        setActiveId(data[0].threadId);
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to load conversations");
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (leadId) => {
    try {
      const { data } = await api.get(`/messages/thread/${leadId}`);
      setMessages(data);
      // Also clear unread in local threads state
      setThreads(prev => prev.map(t => 
        t.threadId === leadId ? { ...t, unread: 0 } : t
      ));
    } catch (err) {
      console.error(err);
      toast.error("Could not load messages");
    }
  };

  const handleSend = async () => {
    if (!draft.trim() || !activeId) return;
    const text = draft;
    setDraft(""); // optimistic clear
    
    // Optimistic UI update
    const optimisticMsg = {
      _id: "temp-" + Date.now(),
      sender_id: user.id || user._id,
      sender_role: "buyer",
      text: text.trim(),
      createdAt: new Date().toISOString(),
    };
    setMessages(prev => [...prev, optimisticMsg]);
    
    try {
      const { data } = await api.post(`/messages/thread/${activeId}`, { text });
      // Replace optimistic with real
      setMessages(prev => prev.map(m => m._id === optimisticMsg._id ? data : m));
      // Update thread last message
      setThreads(prev => prev.map(t => 
        t.threadId === activeId ? { ...t, lastMessage: data.text, lastAt: data.createdAt } : t
      ).sort((a,b) => new Date(b.lastAt) - new Date(a.lastAt)));
    } catch (err) {
      console.error(err);
      toast.error("Failed to send message");
      setDraft(text); // restore
      setMessages(prev => prev.filter(m => m._id !== optimisticMsg._id));
    }
  };

  const active = threads.find((t) => t.threadId === activeId);
  const filtered = threads.filter(
    (t) =>
      (t.propertyTitle || "").toLowerCase().includes(query.toLowerCase()) ||
      (t.agentName || "").toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="min-h-screen bg-background" data-app-shell="buyer">
      <Navbar />

      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground mb-8">
            <Link to="/buyer/dashboard" className="hover:text-primary transition-colors flex items-center gap-1">
              <ArrowLeft className="w-4 h-4" /> Back to Dashboard
            </Link>
          </div>

          <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
            <h1 className="font-display text-4xl md:text-5xl font-black text-foreground mb-8">
              Your Messages
            </h1>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 md:gap-6 min-h-[calc(100vh-20rem)]">
            {/* Sidebar List */}
            <Card className="lg:col-span-4 border-border/80 shadow-sm flex flex-col overflow-hidden max-h-[700px]">
              <CardHeader className="pb-3 space-y-3 border-b border-border/60">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Search properties or agents…"
                    className="pl-9 h-10 rounded-xl bg-muted/40"
                  />
                </div>
              </CardHeader>
              <CardContent className="p-0 flex-1 min-h-[280px]">
                <ScrollArea className="h-[420px] lg:h-[600px]">
                  <div className="flex flex-col">
                    {loading && <div className="p-4 text-center text-muted-foreground text-sm">Loading conversations...</div>}
                    {!loading && filtered.length === 0 && (
                      <div className="p-10 text-center flex flex-col items-center">
                        <MessageSquare className="w-10 h-10 text-muted-foreground/30 mb-3" />
                         <p className="text-sm text-muted-foreground font-medium">No conversations yet.</p>
                      </div>
                    )}
                    {filtered.map((t) => {
                      const d = new Date(t.lastAt || Date.now());
                      const timeStr = d.toLocaleDateString() === new Date().toLocaleDateString() 
                        ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                        : d.toLocaleDateString([], { month: 'short', day: 'numeric' });
                      
                      return (
                        <button
                          key={t.threadId}
                          type="button"
                          onClick={() => setActiveId(t.threadId)}
                          className={cn(
                            "text-left px-4 py-4 border-b border-border/40 transition-colors hover:bg-muted/50",
                            activeId === t.threadId && "bg-primary/5 border-l-4 border-l-primary",
                          )}
                        >
                          <div className="flex gap-3">
                            <Avatar className="w-12 h-12 rounded-xl shrink-0">
                              <AvatarImage src={t.propertyImage} className="object-cover" />
                              <AvatarFallback className="rounded-xl bg-muted"><MessageSquare className="w-5 h-5 text-muted-foreground"/></AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                               <div className="flex items-start justify-between gap-2 mb-1">
                                <span className="font-bold text-sm truncate text-foreground">{t.propertyTitle}</span>
                                <span className="text-[10px] font-bold text-muted-foreground shrink-0">{timeStr}</span>
                              </div>
                              <p className="text-xs text-muted-foreground line-clamp-1 mb-1">
                                Agent
                              </p>
                              <p className={cn("text-xs line-clamp-1", t.unread > 0 ? "font-bold text-foreground" : "text-muted-foreground")}>
                                {t.lastMessage || "Started conversation"}
                              </p>
                            </div>
                          </div>
                          {t.unread > 0 && (
                            <Badge className="absolute mt-[-20px] right-4 h-5 px-1.5 text-[10px]">{t.unread} new</Badge>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>

            {/* Chat Area */}
            <Card className="lg:col-span-8 border-border/80 shadow-md flex flex-col overflow-hidden max-h-[700px]">
              {!active ? (
                <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-muted/10">
                  <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                    <MessageSquare className="w-10 h-10 text-primary" />
                  </div>
                  <h3 className="font-display font-bold text-xl mb-2">Your Conversations</h3>
                  <p className="text-muted-foreground text-sm max-w-sm">
                    Select a thread from the side to continue your conversation with an agent.
                  </p>
                </div>
              ) : (
                <>
                  <CardHeader className="border-b border-border/60 py-4 bg-muted/10">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="flex items-center gap-4 min-w-0">
                        <Avatar className="h-12 w-12 rounded-xl">
                          <AvatarImage src={active.propertyImage} className="object-cover" />
                          <AvatarFallback className="rounded-xl bg-muted"><MessageSquare className="w-5 h-5 text-muted-foreground"/></AvatarFallback>
                        </Avatar>
                        <div className="min-w-0">
                          <Link to={`/property/${active.propertyId}`} className="hover:underline">
                            <h3 className="font-display font-bold text-lg truncate text-foreground">{active.propertyTitle}</h3>
                          </Link>
                          <div className="flex items-center gap-1.5 text-xs text-muted-foreground font-medium mt-0.5">
                            Conversation with Agent
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2 shrink-0">
                        <Button asChild variant="outline" size="sm" className="rounded-xl font-bold">
                          <Link to={`/property/${active.propertyId}`}>View Listing</Link>
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="flex-1 flex flex-col p-0 h-full relative">
                    <ScrollArea 
                      className="flex-1 p-4 lg:p-6"
                      viewportRef={scrollRef}
                    >
                      <div className="space-y-4">
                        {messages.length === 0 ? (
                           <div className="text-center py-10 opacity-70">
                             <p className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Beginning of conversation</p>
                           </div>
                        ) : null}
                        {messages.map((m, i) => {
                          const isMe = m.sender_role === "buyer";
                          const timeStr = new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                          return (
                            <motion.div
                              key={m._id}
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: 0.05 }}
                              className={cn(
                                "flex",
                                isMe ? "justify-end" : "justify-start",
                              )}
                            >
                              <div
                                className={cn(
                                  "max-w-[85%] md:max-w-[70%] rounded-2xl px-4 py-3 text-sm font-medium shadow-sm",
                                  isMe
                                    ? "bg-primary text-primary-foreground rounded-br-md"
                                    : "bg-muted text-foreground border border-border/40 rounded-bl-md",
                                )}
                              >
                                <p className="whitespace-pre-wrap">{m.text}</p>
                                <p
                                  className={cn(
                                    "text-[10px] mt-1.5 font-bold uppercase tracking-wide text-right",
                                    isMe
                                      ? "text-primary-foreground/70"
                                      : "text-muted-foreground",
                                  )}
                                >
                                  {timeStr}
                                </p>
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>
                    </ScrollArea>
                    <div className="p-4 border-t border-border/60 bg-card">
                      <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex gap-2">
                        <Input
                          value={draft}
                          onChange={(e) => setDraft(e.target.value)}
                          placeholder="Type your message…"
                          className="rounded-xl h-12 bg-muted/40 border-border/60 flex-1 px-4"
                        />
                        <Button
                          type="submit"
                          disabled={!draft.trim()}
                          className="rounded-xl h-12 px-6 shrink-0 shadow-hero bg-gradient-hero"
                        >
                          <Send className="w-5 h-5 mr-2" />
                          <span className="font-bold">Send</span>
                        </Button>
                      </form>
                    </div>
                  </CardContent>
                </>
              )}
            </Card>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
