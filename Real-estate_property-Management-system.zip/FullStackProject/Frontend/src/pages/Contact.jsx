import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

export default function Contact() {
  const { toast } = useToast();
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "Message Sent!",
      description: "We'll get back to you within 24 hours.",
    });
    setForm({ name: "", email: "", phone: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center mb-12"
          >
            <p className="text-primary font-semibold text-sm uppercase tracking-wider mb-2">
              Get in Touch
            </p>
            <h1 className="font-display text-4xl font-bold text-foreground">
              Contact Us
            </h1>
          </motion.div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-6"
            >
              <div className="bg-card rounded-2xl p-6 border border-border/50 shadow-card">
                <h3 className="font-display text-lg font-semibold text-foreground mb-4">
                  Contact Information
                </h3>
                <div className="space-y-4">
                  {[
                    {
                      icon: MapPin,
                      text: "123, Bandra Kurla Complex, Mumbai - 400051",
                    },
                    { icon: Phone, text: "+91 98765 43210" },
                    { icon: Mail, text: "hello@propnest.in" },
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-3">
                      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                        <item.icon className="w-5 h-5 text-primary" />
                      </div>
                      <p className="text-muted-foreground text-sm pt-2">
                        {item.text}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-card rounded-2xl overflow-hidden border border-border/50 shadow-card">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.363!2d72.8601!3d19.0665!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMTnCsDAzJzU5LjQiTiA3MsKwNTEnMzYuNCJF!5e0!3m2!1sen!2sin!4v1"
                  className="w-full h-64"
                  loading="lazy"
                  title="Office Location"
                />
              </div>
            </motion.div>

            <motion.form
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              onSubmit={handleSubmit}
              className="bg-card rounded-2xl p-8 border border-border/50 shadow-card space-y-5"
            >
              <h3 className="font-display text-lg font-semibold text-foreground">
                Send us a Message
              </h3>
              {[
                {
                  name: "name",
                  label: "Full Name",
                  type: "text",
                  placeholder: "Enter your name",
                },
                {
                  name: "email",
                  label: "Email",
                  type: "email",
                  placeholder: "Enter your email",
                },
                {
                  name: "phone",
                  label: "Phone",
                  type: "tel",
                  placeholder: "+91 XXXXX XXXXX",
                },
              ].map((field) => (
                <div key={field.name}>
                  <label className="text-xs font-medium text-muted-foreground mb-2 block">
                    {field.label}
                  </label>
                  <input
                    type={field.type}
                    placeholder={field.placeholder}
                    value={form[field.name]}
                    onChange={(e) =>
                      setForm({ ...form, [field.name]: e.target.value })
                    }
                    required
                    className="w-full h-12 px-4 rounded-xl bg-muted border-0 text-sm text-foreground focus:ring-2 focus:ring-primary/30 outline-none"
                  />
                </div>
              ))}
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-2 block">
                  Message
                </label>
                <textarea
                  rows={4}
                  placeholder="How can we help you?"
                  value={form.message}
                  onChange={(e) =>
                    setForm({ ...form, message: e.target.value })
                  }
                  required
                  className="w-full px-4 py-3 rounded-xl bg-muted border-0 text-sm text-foreground focus:ring-2 focus:ring-primary/30 outline-none resize-none"
                />
              </div>
              <Button
                type="submit"
                className="w-full h-12 bg-gradient-hero text-primary-foreground shadow-hero font-semibold rounded-xl"
              >
                <Send className="w-4 h-4 mr-2" /> Send Message
              </Button>
            </motion.form>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
