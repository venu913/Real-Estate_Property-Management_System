import { useParams, Link, useNavigate, useLocation } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  MapPin,
  Bed,
  Bath,
  Maximize2,
  Star,
  Heart,
  Share2,
  Phone,
  Calendar,
  Shield,
  Car,
  Compass,
  Building,
  CheckCircle,
  ExternalLink,
  Info,
  ChevronRight,
  ShieldCheck,
  Zap,
  TrendingUp,
  Mail,
  Scale,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect } from "react";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";
import { useToast } from "@/hooks/use-toast";
import ContactAgentDialog from "@/components/property/ContactAgentDialog";
import ScheduleVisitDialog from "@/components/property/ScheduleVisitDialog";
import PropertyDetailSimilarRail from "@/components/property/PropertyDetailSimilarRail";
import PropertyMiniMap from "@/components/map/PropertyMiniMap";
import EmiCalculator from "@/components/property/EmiCalculator";
import PropertyReviewsSection from "@/components/property/PropertyReviewsSection";
import PropertyLiveBadges from "@/components/property/PropertyLiveBadges";
import { useCompare } from "@/contexts/CompareContext";
import { toast as sonner } from "sonner";
import { toTelHref } from "@/lib/phone";

export default function PropertyDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const { user, profile, refreshProfile } = useAuth();
  const { recordPropertyView } = useBuyerActivity();
  const { addProperty, hasProperty } = useCompare();
  const { toast } = useToast();
  const [property, setProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeImage, setActiveImage] = useState(0);
  const [liked, setLiked] = useState(false);
  const [contactOpen, setContactOpen] = useState(false);
  const [scheduleOpen, setScheduleOpen] = useState(false);

  const { data: leadsResponse, refetch: refetchLeads } = useQuery({
    queryKey: ['my-requests'],
    queryFn: async () => {
      const res = await api.get('/leads/my-requests');
      return res.data;
    },
    enabled: !!user
  });

  const myLeads = leadsResponse?.data || [];
  const propertyLeads = myLeads.filter(lead => {
    const leadPropId = lead.property_id?._id || lead.property_id;
    const currentPropId = property?._id || property?.id;
    return leadPropId && currentPropId && String(leadPropId) === String(currentPropId);
  });
  
  const hasSiteVisit = propertyLeads.some(l => l.lead_type === 'site_visit' && l.visit_status !== 'cancelled');
  const hasAcceptedInquiry = propertyLeads.some(l => l.lead_type !== 'site_visit' && l.status === 'accepted');
  const hasPendingInquiry = propertyLeads.some(l => l.lead_type !== 'site_visit' && !['rejected', 'lost', 'closed', 'accepted'].includes(l.status));

  useEffect(() => {
    if (profile?.savedProperties && id) {
      setLiked(profile.savedProperties.includes(id));
    }
  }, [profile, id]);

  useEffect(() => {
    const fetchProperty = async () => {
      try {
        const res = await api.get(`/properties/${id}`);
        setProperty(res.data);
        recordPropertyView(res.data);

      } catch (err) {
        console.error(err);
        toast({
          title: "Error",
          description: "Could not load property details.",
          variant: "destructive",
        });
      } finally {
        setLoading(false);
      }
    };
    fetchProperty();
  }, [id, recordPropertyView]);

  const handleToggleLike = async () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please login to save properties.",
      });
      navigate("/login", { state: { from: location.pathname } });
      return;
    }

    try {
      await api.post(`/auth/favorites/toggle/${id}`);
      await refreshProfile();
      setLiked(!liked);
      toast({
        title: !liked ? "Saved to Favorites" : "Removed from Favorites",
        description: property.title,
      });
      sonner.success(!liked ? "Property saved" : "Removed from saved", {
        description: property.title,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not update favorites.",
        variant: "destructive",
      });
    }
  };

  const handleScheduleVisit = () => {
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please login to schedule a visit.",
      });
      navigate("/login", { state: { from: location.pathname } });
      return;
    }
    setScheduleOpen(true);
  };

  const handleShare = async () => {
    const url = window.location.href;
    try {
      if (navigator.share) {
        await navigator.share({ title: property.title, url });
      } else {
        await navigator.clipboard.writeText(url);
        sonner.success("Link copied", { description: "Share this listing anywhere." });
      }
    } catch {
      try {
        await navigator.clipboard.writeText(url);
        sonner.success("Link copied");
      } catch {
        sonner.error("Could not share");
      }
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground font-medium">Fetching details...</p>
        </div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-display text-2xl font-bold text-foreground mb-4">
            Property Not Found
          </h2>
          <Button onClick={() => navigate("/properties")}>
            Browse Properties
          </Button>
        </div>
      </div>
    );
  }

  const formatPrice = (price) => {
    if (price >= 10000000) return `${(price / 10000000).toFixed(2)} Cr`;
    if (price >= 100000) return `${(price / 100000).toFixed(2)} L`;
    return price.toLocaleString('en-IN');
  };

  const details = [
    { icon: Bed, label: "Bedrooms", value: property.bedrooms > 0 ? `${property.bedrooms} BHK` : "N/A" },
    { icon: Bath, label: "Bathrooms", value: property.bathrooms },
    { icon: Maximize2, label: "Area", value: `${property.area_sqft} sqft` },
    { icon: ShieldCheck, label: "Status", value: property.status },
    { icon: Car, label: "Parking", value: 'Available' },
    { icon: Compass, label: "Facing", value: 'North' },
    { icon: Shield, label: "Furnished", value: property.furnishing },
    { icon: Zap, label: "Listed", value: 'New' },
  ];

  const agentName = property.agent?.name || "Listing agent";
  const agentTelHref = toTelHref(property.agent?.phone);

  return (
    <div className="min-h-screen bg-background" data-app-shell="buyer">
      <ContactAgentDialog
        open={contactOpen}
        onOpenChange={setContactOpen}
        propertyId={property._id || property.id}
        propertyTitle={property.title}
        agentName={agentName}
        defaultName={profile?.full_name || ""}
        defaultEmail={user?.email || ""}
        defaultPhone={profile?.phone ? String(profile.phone).replace(/\D/g, "").slice(-10) : ""}
        onSuccess={() => refetchLeads()}
      />
      <ScheduleVisitDialog
        open={scheduleOpen}
        onOpenChange={setScheduleOpen}
        propertyTitle={property.title}
        propertyId={property._id || property.id}
        onSuccess={() => refetchLeads()}
      />
      <Navbar />

      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Breadcrumbs */}
          <div className="flex items-center gap-2 text-sm font-medium text-muted-foreground mb-8">
            <Link to="/" className="hover:text-primary transition-colors">Home</Link>
            <ChevronRight className="w-4 h-4" />
            <Link to="/properties" className="hover:text-primary transition-colors">Properties</Link>
            <ChevronRight className="w-4 h-4" />
            <span className="text-foreground truncate max-w-[200px]">{property.title}</span>
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-12 gap-10">
            {/* Main Content (Left) */}
            <div className="xl:col-span-8 space-y-10">
              
              {/* Header Hero */}
              <section className="space-y-6">
                <div className="flex flex-wrap items-center gap-3">
                  <Badge className="bg-primary/10 text-primary border-primary/20 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest">
                    {property.listing_type}
                  </Badge>
                  {property.is_verified && (
                    <Badge className="bg-success/10 text-success border-success/20 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5" /> Verified Listing
                    </Badge>
                  )}
                </div>

                <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                  <div className="max-w-2xl">
                    <h1 className="font-display text-3xl md:text-5xl font-black text-foreground leading-[1.1] mb-4">
                      {property.title}
                    </h1>
                    <div className="flex items-center gap-2 text-muted-foreground font-semibold">
                      <MapPin className="w-5 h-5 text-primary" />
                      {property.address}, {property.city}, {property.state}
                    </div>
                    <PropertyLiveBadges
                      propertyId={property._id || property.id}
                      createdAt={property.createdAt}
                      className="mt-4"
                    />
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Button
                      type="button"
                      title="Add to compare"
                      variant="outline"
                      className={`h-12 w-12 rounded-2xl p-0 shadow-sm ${hasProperty(property._id || property.id) ? "border-primary bg-primary/10 text-primary" : ""}`}
                      onClick={() => addProperty(property)}
                    >
                      <Scale className="w-5 h-5" />
                    </Button>
                    <Button 
                      onClick={handleToggleLike}
                      variant="outline" 
                      className={`h-12 w-12 rounded-2xl p-0 shadow-sm transition-all ${liked ? 'bg-destructive/5 text-destructive border-destructive/30' : ''}`}
                    >
                      <Heart className={`w-5 h-5 ${liked ? "fill-current" : ""}`} />
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      className="h-12 w-12 rounded-2xl p-0 shadow-sm"
                      onClick={handleShare}
                    >
                      <Share2 className="w-5 h-5" />
                    </Button>
                  </div>
                </div>
              </section>

              {/* Media Gallery */}
              <section className="space-y-4">
                <div className="rounded-[2.5rem] overflow-hidden aspect-[21/10] bg-muted shadow-2xl relative border border-border/40">
                  <AnimatePresence mode="wait">
                    <motion.img
                      key={activeImage}
                      src={property.images?.[activeImage] || property.image}
                      initial={{ opacity: 0, scale: 1.05 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.5 }}
                      className="w-full h-full object-cover"
                    />
                  </AnimatePresence>
                </div>
                
                {property.images?.length > 1 && (
                  <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
                    {property.images.map((img, i) => (
                      <button
                        key={i}
                        onClick={() => setActiveImage(i)}
                        className={`relative rounded-2xl overflow-hidden w-28 h-20 shrink-0 border-2 transition-all p-0.5 ${
                          i === activeImage ? "border-primary ring-4 ring-primary/10" : "border-transparent opacity-70 grayscale-[50%] hover:grayscale-0"
                        }`}
                      >
                        <img src={img} className="w-full h-full object-cover rounded-xl" />
                      </button>
                    ))}
                  </div>
                )}
              </section>

              {/* Core Features */}
              <section className="bg-card rounded-[2.5rem] p-8 md:p-10 border border-border/40 shadow-sm grid grid-cols-2 md:grid-cols-4 gap-8">
                {details.map((d, i) => (
                  <div key={i} className="flex flex-col gap-2">
                    <div className="w-10 h-10 rounded-xl bg-primary/5 flex items-center justify-center">
                      <d.icon className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{d.label}</p>
                      <p className="font-display font-bold text-foreground text-sm uppercase">{d.value}</p>
                    </div>
                  </div>
                ))}
              </section>

              <PropertyMiniMap property={property} />

              <EmiCalculator
                propertyPrice={property.price}
                listingType={property.listing_type}
              />

              {/* Description & Amenities */}
              <section className="grid md:grid-cols-2 gap-10">
                <div className="bg-card rounded-[2.5rem] p-8 md:p-10 border border-border/40 shadow-sm">
                  <h3 className="font-display font-bold text-xl text-foreground mb-6 flex items-center gap-3">
                    <Info className="w-5 h-5 text-primary" /> Description
                  </h3>
                  <p className="text-muted-foreground leading-relaxed font-medium">
                    {property.description}
                  </p>
                </div>

                <div className="bg-card rounded-[2.5rem] p-8 md:p-10 border border-border/40 shadow-sm">
                  <h3 className="font-display font-bold text-xl text-foreground mb-6 flex items-center gap-3">
                    <Zap className="w-5 h-5 text-primary" /> Amenities
                  </h3>
                  <div className="grid grid-cols-2 gap-y-4 gap-x-6">
                    {['Clubhouse', 'Gym', 'Parking', 'Pool', 'Security'].map((a) => (
                      <div key={a} className="flex items-center gap-3 text-sm font-bold text-muted-foreground">
                        <CheckCircle className="w-4 h-4 text-success" />
                        {a}
                      </div>
                    ))}
                  </div>
                </div>
              </section>

              <PropertyReviewsSection
                propertyId={String(property._id || property.id)}
                listingRating={property.rating}
                listingReviewCount={property.reviews}
              />

            </div>

            {/* Sidebar (Right) - Sticky */}
            <div className="xl:col-span-4 space-y-8">
              <aside className="sticky top-28 space-y-6">
                
                {/* Pricing Card */}
                <div className="bg-card rounded-[2.5rem] p-8 border border-border/40 shadow-xl overflow-hidden relative">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -translate-y-12 translate-x-12" />
                  
                  <div className="mb-8">
                    <p className="text-xs font-black text-muted-foreground uppercase tracking-widest mb-1">Total Price</p>
                    <div className="flex items-baseline gap-2">
                      <span className="text-4xl font-display font-black text-foreground">₹{formatPrice(property.price)}</span>
                      <span className="text-sm font-bold text-muted-foreground">{property.listing_type === 'rent' ? '/mo' : ''}</span>
                    </div>
                    <div className="mt-2 flex items-center gap-2 text-xs font-bold text-success bg-success/5 w-fit px-3 py-1 rounded-full border border-success/10">
                      <TrendingUp className="w-3 h-3" /> Price Trending Up
                    </div>
                  </div>

                  <div className="space-y-4">
                    {hasSiteVisit ? (
                      <Button disabled variant="outline" className="w-full h-16 rounded-2xl font-black text-base uppercase tracking-wider border-border/60 bg-muted/30 text-muted-foreground cursor-not-allowed">
                        Visit Scheduled
                      </Button>
                    ) : hasAcceptedInquiry ? (
                      <Button onClick={handleScheduleVisit} className="w-full h-16 bg-gradient-hero text-primary-foreground shadow-hero rounded-2xl font-black text-base uppercase tracking-wider">
                        Schedule a Visit
                      </Button>
                    ) : hasPendingInquiry ? (
                      <Button disabled variant="outline" className="w-full h-16 rounded-2xl font-black text-base uppercase tracking-wider border-border/60 bg-muted/30 text-muted-foreground cursor-not-allowed">
                        Inquiry Sent
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        className="w-full h-16 bg-gradient-hero text-primary-foreground shadow-hero rounded-2xl font-black text-base uppercase tracking-wider"
                        onClick={() => {
                          if (!user) {
                            navigate("/login", { state: { from: location.pathname } });
                            return;
                          }
                          setContactOpen(true);
                        }}
                      >
                        Send an Inquiry
                      </Button>
                    )}
                  </div>

                </div>

                {/* Agent Card */}
                <div className="bg-card rounded-[2.5rem] p-8 border border-border/40 shadow-md">
                  <div className="flex items-center gap-4 mb-6">
                    <div className="w-16 h-16 rounded-2xl bg-gradient-hero flex items-center justify-center text-primary-foreground font-black text-2xl shadow-hero">
                      {agentName.charAt(0)}
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-lg text-foreground leading-none mb-1">{agentName}</h4>
                      <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">Verified partner</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    {agentTelHref ? (
                      <Button
                        asChild
                        variant="outline"
                        className="h-12 rounded-xl font-bold text-xs uppercase tracking-widest"
                      >
                        <a href={agentTelHref} className="inline-flex items-center justify-center gap-2">
                          <Phone className="w-4 h-4 text-primary" /> Call
                        </a>
                      </Button>
                    ) : (
                      <Button
                        type="button"
                        variant="outline"
                        className="h-12 rounded-xl flex items-center gap-2 font-bold text-xs uppercase tracking-widest"
                        disabled
                      >
                        <Phone className="w-4 h-4 text-primary" /> Call
                      </Button>
                    )}
                    <Button
                      type="button"
                      variant="outline"
                      className="h-12 rounded-xl flex items-center gap-2 font-bold text-xs uppercase tracking-widest"
                      onClick={() => setContactOpen(true)}
                    >
                      <Mail className="w-4 h-4 text-primary" /> Contact
                    </Button>
                  </div>
                </div>

              </aside>
            </div>
          </div>

          <PropertyDetailSimilarRail seed={property} />
        </div>
      </main>

      <Footer />
    </div>
  );
}
