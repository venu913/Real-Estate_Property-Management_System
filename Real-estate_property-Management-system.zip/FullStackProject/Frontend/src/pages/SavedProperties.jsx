import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Heart, MapPin, Sparkles, ArrowRight, Bookmark } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate, useLocation, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export default function SavedProperties() {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const { user, loading: authLoading, profile } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login", { state: { from: location.pathname } });
      return;
    }

    if (user) {
      const fetchSaved = async () => {
        try {
          const res = await api.get('/auth/favorites');
          setProperties(res.data);
        } catch (err) {
          console.error(err);
        } finally {
          setLoading(false);
        }
      };
      fetchSaved();
    }
  }, [user, authLoading, profile?.savedProperties?.length]);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground font-black text-[10px] uppercase tracking-widest">Accessing Vault...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-24 pb-20">
        {/* Header Hero Section */}
        <section className="bg-muted/30 border-y border-border/40 mb-12 py-16 md:py-24 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center gap-2 mb-6"
              >
                <div className="w-10 h-px bg-primary" />
                <span className="text-primary font-black text-[10px] uppercase tracking-[0.3em] flex items-center gap-1.5">
                  <Bookmark className="w-3 h-3" /> Curated Collection
                </span>
              </motion.div>
              
              <motion.h1 
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 }}
                className="font-display text-4xl md:text-6xl font-black text-foreground mb-6"
              >
                Saved <span className="text-gradient-hero">Collectibles.</span>
              </motion.h1>
              <p className="text-muted-foreground font-medium text-lg max-w-xl">
                A personalized gallery of your favorite real estate masterpieces. 
                Ready for the next step?
              </p>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4">
          {properties.length > 0 ? (
            <motion.div 
              layout
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8"
            >
              <AnimatePresence>
                {properties.map((property, i) => (
                  <PropertyCard key={property._id} property={property} index={i} />
                ))}
              </AnimatePresence>
            </motion.div>
          ) : (
            <div className="py-32 text-center bg-card rounded-[3rem] border-2 border-dashed border-border/40 max-w-4xl mx-auto px-8">
              <div className="w-24 h-24 rounded-[2rem] bg-muted/50 flex items-center justify-center mx-auto mb-8 shadow-sm">
                <Heart className="w-10 h-10 text-muted-foreground/20" />
              </div>
              <h3 className="font-display text-3xl font-black text-foreground mb-4">Your Vault is Empty.</h3>
              <p className="text-muted-foreground font-medium mb-12 max-w-sm mx-auto">
                Explore our elite curation of properties and save them here for quick comparison and analysis.
              </p>
              <Link to="/properties">
                <Button className="rounded-full px-10 h-14 bg-gradient-hero text-white font-black uppercase tracking-widest text-xs shadow-hero hover:scale-105 transition-all">
                  Browse Properties <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
            </div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
