import { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Bell,
  Bookmark,
  Clock,
  Settings,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";

export default function BuyerDashboard() {
  const { user } = useAuth();
  const { recentIds, notifications, activity, clearRecentlyViewed } = useBuyerActivity();
  const [saved, setSaved] = useState([]);
  const [pool, setPool] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      try {
        const [favRes, allRes] = await Promise.all([
          api.get("/auth/favorites").catch(() => ({ data: [] })),
          api.get("/properties").catch(() => ({ data: [] })),
        ]);
        if (!cancelled) {
          setSaved(favRes.data || []);
          setPool(allRes.data || []);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const recentProperties = useMemo(() => {
    if (!pool.length || !recentIds.length) return [];
    const map = new Map(pool.map((p) => [String(p._id || p.id), p]));
    return recentIds.map((id) => map.get(String(id))).filter(Boolean).slice(0, 6);
  }, [pool, recentIds]);

  const suggestions = useMemo(() => {
    const topCity = activity.cities[0];
    const topCat = activity.categories[0];
    return pool
      .filter((p) => {
        if (saved.find((s) => String(s._id) === String(p._id))) return false;
        if (topCity && p.city === topCity) return true;
        if (topCat && p.category === topCat) return true;
        return p.featured || p.trending;
      })
      .slice(0, 3);
  }, [pool, activity, saved]);

  return (
    <div className="min-h-screen bg-background" data-app-shell="buyer">
      <Navbar />

      <main className="pt-24 pb-20">
        <section className="border-b border-border/40 bg-gradient-to-b from-muted/40 to-background">
          <div className="container mx-auto px-4 py-12 md:py-16">
            <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
              <p className="text-primary font-black text-[10px] uppercase tracking-[0.3em] mb-3">
                Buyer hub
              </p>
              <h1 className="font-display text-4xl md:text-5xl font-black text-foreground mb-4">
                Your PropNest space
              </h1>
              <p className="text-muted-foreground font-medium max-w-2xl">
                Saved homes, picks based on what you browse, and alerts — all in one calm, card-first layout.
              </p>
            </motion.div>
          </div>
        </section>

        <div className="container mx-auto px-4 py-10 space-y-14">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <Card className="lg:col-span-2 border-border/70 shadow-sm rounded-3xl overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between border-b border-border/50 bg-muted/20">
                <div className="flex items-center gap-2">
                  <Bell className="w-5 h-5 text-primary" />
                  <CardTitle className="font-display text-lg">Notifications</CardTitle>
                </div>
                <Badge variant="secondary" className="font-bold">
                  {notifications.filter((n) => !n.read).length} new
                </Badge>
              </CardHeader>
              <CardContent className="p-0">
                <ScrollArea className="h-[280px]">
                  <ul className="divide-y divide-border/60">
                    {notifications.map((n) => (
                      <li
                        key={n.id}
                        className={`px-6 py-4 ${!n.read ? "bg-primary/[0.03]" : ""}`}
                      >
                        <p className="font-bold text-sm text-foreground">{n.title}</p>
                        <p className="text-sm text-muted-foreground mt-1">{n.body}</p>
                        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mt-2">
                          {n.time}
                        </p>
                      </li>
                    ))}
                  </ul>
                </ScrollArea>
              </CardContent>
            </Card>

            <Card className="border-border/70 shadow-sm rounded-3xl">
              <CardHeader className="border-b border-border/50">
                <CardTitle className="font-display text-lg flex items-center gap-2">
                  <Settings className="w-5 h-5 text-primary" /> Account
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-6 space-y-3">
                <Link to="/profile">
                  <Button variant="outline" className="w-full justify-between rounded-xl h-12 font-bold">
                    Profile & preferences
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link to="/buyer/messages">
                  <Button variant="outline" className="w-full justify-between rounded-xl h-12 font-bold">
                    Messages
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
                <Link to="/properties">
                  <Button className="w-full justify-between rounded-xl h-12 font-bold bg-gradient-hero shadow-hero">
                    Browse properties
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>

          <section>
            <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
              <div>
                <div className="flex items-center gap-2 text-muted-foreground font-bold text-[10px] uppercase tracking-widest mb-2">
                  <Bookmark className="w-3.5 h-3.5 text-primary" /> Collection
                </div>
                <h2 className="font-display text-3xl font-black">Saved properties</h2>
              </div>
              <Link to="/saved">
                <Button variant="ghost" className="font-bold text-primary">
                  Open full list
                </Button>
              </Link>
            </div>
            {loading ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="aspect-[16/11] bg-muted rounded-[2rem] animate-pulse" />
                ))}
              </div>
            ) : saved.length ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {saved.slice(0, 6).map((p, i) => (
                  <PropertyCard key={p._id || p.id} property={p} index={i} variant="buyer" />
                ))}
              </div>
            ) : (
              <div className="rounded-[2rem] border-2 border-dashed border-border/60 bg-muted/20 py-20 text-center px-6">
                <Bookmark className="w-12 h-12 text-muted-foreground/30 mx-auto mb-4" />
                <h3 className="font-display text-xl font-bold mb-2">No saved properties yet</h3>
                <p className="text-muted-foreground text-sm mb-6 max-w-md mx-auto">
                  Tap the heart on any listing to keep it here for easy comparison.
                </p>
                <Link to="/properties">
                  <Button className="rounded-full px-8 bg-gradient-hero shadow-hero font-bold">
                    Start browsing
                  </Button>
                </Link>
              </div>
            )}
          </section>

          <section>
            <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
              <div>
                <div className="flex items-center gap-2 text-muted-foreground font-bold text-[10px] uppercase tracking-widest mb-2">
                  <Clock className="w-3.5 h-3.5 text-primary" /> History
                </div>
                <h2 className="font-display text-3xl font-black">Recently viewed</h2>
              </div>
              {recentProperties.length > 0 && (
                <Button
                  variant="outline"
                  size="sm"
                  className="rounded-full font-bold text-xs"
                  onClick={clearRecentlyViewed}
                >
                  Clear history
                </Button>
              )}
            </div>
            {recentProperties.length ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {recentProperties.map((p, i) => (
                  <PropertyCard key={p._id || p.id} property={p} index={i} variant="buyer" />
                ))}
              </div>
            ) : (
              <div className="rounded-[2rem] border border-border/60 bg-card/50 py-16 text-center text-muted-foreground text-sm">
                Listings you open will appear here automatically.
              </div>
            )}
          </section>

          {suggestions.length > 0 && (
            <section>
              <div className="flex items-center gap-2 mb-8">
                <Sparkles className="w-5 h-5 text-primary" />
                <h2 className="font-display text-3xl font-black">Suggested next</h2>
              </div>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {suggestions.map((p, i) => (
                  <PropertyCard key={p._id || p.id} property={p} index={i} variant="buyer" />
                ))}
              </div>
            </section>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
}
