import { Link } from "react-router-dom";
import { ArrowLeft, X, Check } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useCompare } from "@/contexts/CompareContext";
import { cn } from "@/lib/utils";

function formatPrice(p, unit) {
  if (p >= 10000000) return `₹${(p / 10000000).toFixed(2)} Cr`;
  if (p >= 100000) return `₹${(p / 100000).toFixed(2)} L`;
  const s = `₹${p?.toLocaleString("en-IN") ?? "—"}`;
  return unit === "rent" ? `${s}/mo` : s;
}

export default function Compare() {
  const { items, removeProperty, clearAll } = useCompare();

  const minPriceIdx =
    items.length === 0
      ? -1
      : items.reduce(
          (best, p, i, arr) =>
            (p.price ?? Infinity) < (arr[best].price ?? Infinity) ? i : best,
          0,
        );

  const maxAreaIdx =
    items.length === 0
      ? -1
      : items.reduce(
          (best, p, i, arr) =>
            (p.area_sqft ?? 0) > (arr[best].area_sqft ?? 0) ? i : best,
          0,
        );

  const maxBhkIdx =
    items.length === 0
      ? -1
      : items.reduce(
          (best, p, i, arr) =>
            (p.bedrooms ?? 0) > (arr[best].bedrooms ?? 0) ? i : best,
          0,
        );

  const maxAmenIdx =
    items.length === 0
      ? -1
      : items.reduce(
          (best, p, i, arr) =>
            (p.amenities?.length ?? 0) > (arr[best].amenities?.length ?? 0)
              ? i
              : best,
          0,
        );

  const highlight = (row, colIdx) => {
    if (items.length < 2) return false;
    if (row === "price") return colIdx === minPriceIdx;
    if (row === "area") return colIdx === maxAreaIdx;
    if (row === "bhk") return colIdx === maxBhkIdx;
    if (row === "amenities") return colIdx === maxAmenIdx;
    return false;
  };

  return (
    <div className="min-h-screen bg-background" data-app-shell="buyer">
      <Navbar />
      <main className="pt-24 pb-28">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-8">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" className="rounded-xl" asChild>
                <Link to="/properties">
                  <ArrowLeft className="w-5 h-5" />
                </Link>
              </Button>
              <div>
                <h1 className="font-display text-3xl md:text-4xl font-black tracking-tight">
                  Compare properties
                </h1>
                <p className="text-muted-foreground text-sm font-medium mt-1">
                  Side-by-side view with smart highlights — add or remove listings anytime.
                </p>
              </div>
            </div>
            {items.length > 0 && (
              <Button variant="outline" className="rounded-xl font-bold" onClick={clearAll}>
                Clear all
              </Button>
            )}
          </div>

          {items.length === 0 ? (
            <div className="rounded-[2rem] border-2 border-dashed border-border/60 bg-muted/20 py-24 text-center px-6">
              <p className="text-muted-foreground font-medium mb-6 max-w-md mx-auto">
                No properties to compare. Use &quot;Compare&quot; on listing cards to add up to 4 homes.
              </p>
              <Button asChild className="rounded-full bg-gradient-hero shadow-hero font-bold">
                <Link to="/properties">Browse listings</Link>
              </Button>
            </div>
          ) : (
            <div className="rounded-2xl border border-border/60 bg-card shadow-sm overflow-hidden">
              <div className="overflow-x-auto max-h-[calc(100vh-8rem)] overflow-y-auto">
                <Table className="min-w-[720px]">
                  <TableHeader>
                    <TableRow className="hover:bg-transparent border-border/60">
                      <TableHead className="sticky left-0 z-20 bg-card w-40 font-black text-xs uppercase tracking-widest text-muted-foreground align-bottom">
                        Metric
                      </TableHead>
                      {items.map((p, colIdx) => (
                        <TableHead
                          key={p._id || p.id}
                          className="sticky top-0 z-30 bg-card/95 backdrop-blur-md align-bottom min-w-[200px] border-b border-border/60 shadow-sm"
                        >
                          <div className="space-y-3 pb-2">
                            <div className="relative aspect-[16/10] rounded-xl overflow-hidden bg-muted">
                              <img
                                src={p.images?.[0] || p.image}
                                alt=""
                                className="h-full w-full object-cover"
                              />
                              <Button
                                type="button"
                                size="icon"
                                variant="secondary"
                                className="absolute top-2 right-2 h-8 w-8 rounded-full shadow-md"
                                onClick={() => removeProperty(p._id || p.id)}
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </div>
                            <p className="font-display font-bold text-sm leading-snug line-clamp-2 text-left">
                              {p.title}
                            </p>
                            <Button asChild size="sm" className="w-full rounded-xl font-bold" variant="outline">
                              <Link to={`/property/${p._id || p.id}`}>View</Link>
                            </Button>
                          </div>
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow className="border-border/50">
                      <TableCell className="sticky left-0 z-10 bg-card font-bold text-muted-foreground text-xs uppercase tracking-wide">
                        Price
                      </TableCell>
                      {items.map((p, colIdx) => (
                        <TableCell
                          key={`pr-${p._id || p.id}`}
                          className={cn(
                            "font-black text-base align-top",
                            highlight("price", colIdx) &&
                              "bg-emerald-500/10 text-emerald-800 dark:text-emerald-300 ring-1 ring-emerald-500/20",
                          )}
                        >
                          <div className="flex items-center gap-2">
                            {formatPrice(p.price, p.listing_type === "rent" ? "rent" : "sale")}
                            {highlight("price", colIdx) && (
                              <Badge className="text-[9px] h-5 bg-emerald-600 hover:bg-emerald-600">Best value</Badge>
                            )}
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow className="border-border/50">
                      <TableCell className="sticky left-0 z-10 bg-card font-bold text-muted-foreground text-xs uppercase tracking-wide">
                        Location
                      </TableCell>
                      {items.map((p) => (
                        <TableCell key={`loc-${p._id || p.id}`} className="align-top text-sm font-medium">
                          {p.city}
                          {p.state ? `, ${p.state}` : ""}
                          <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{p.address || p.location}</div>
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow className="border-border/50">
                      <TableCell className="sticky left-0 z-10 bg-card font-bold text-muted-foreground text-xs uppercase tracking-wide">
                        BHK
                      </TableCell>
                      {items.map((p, colIdx) => (
                        <TableCell
                          key={`bk-${p._id || p.id}`}
                          className={cn(
                            "align-top font-bold",
                            highlight("bhk", colIdx) && "bg-primary/10 ring-1 ring-primary/20",
                          )}
                        >
                          <div className="flex items-center gap-2">
                            {p.bedrooms ?? "—"} BHK
                            {highlight("bhk", colIdx) && <Check className="w-4 h-4 text-primary" />}
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow className="border-border/50">
                      <TableCell className="sticky left-0 z-10 bg-card font-bold text-muted-foreground text-xs uppercase tracking-wide">
                        Area
                      </TableCell>
                      {items.map((p, colIdx) => (
                        <TableCell
                          key={`ar-${p._id || p.id}`}
                          className={cn(
                            "align-top font-bold",
                            highlight("area", colIdx) && "bg-violet-500/10 ring-1 ring-violet-500/25",
                          )}
                        >
                          <div className="flex items-center gap-2">
                            {p.area_sqft ?? "—"} sqft
                            {highlight("area", colIdx) && (
                              <Badge variant="secondary" className="text-[9px] h-5">Largest</Badge>
                            )}
                          </div>
                        </TableCell>
                      ))}
                    </TableRow>
                    <TableRow className="border-border/50">
                      <TableCell className="sticky left-0 z-10 bg-card font-bold text-muted-foreground text-xs uppercase tracking-wide align-top">
                        Amenities
                      </TableCell>
                      {items.map((p, colIdx) => (
                        <TableCell
                          key={`am-${p._id || p.id}`}
                          className={cn(
                            "align-top text-sm",
                            highlight("amenities", colIdx) && "bg-amber-500/10 ring-1 ring-amber-500/20",
                          )}
                        >
                          <ul className="list-disc pl-4 space-y-1 text-muted-foreground">
                            {(p.amenities?.length
                              ? p.amenities
                              : ["Gym", "Parking", "Security"]
                            )
                              .slice(0, 8)
                              .map((a) => (
                                <li key={a}>{a}</li>
                              ))}
                          </ul>
                          {highlight("amenities", colIdx) && (
                            <p className="text-[10px] font-black text-amber-700 dark:text-amber-400 mt-2 uppercase tracking-wide">
                              Richest set
                            </p>
                          )}
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableBody>
                </Table>
              </div>
            </div>
          )}
        </div>
      </main>
      <Footer />
    </div>
  );
}
