import { useState, useEffect, useRef } from "react";
import { useForm, FormProvider, useFormContext } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Building2, MapPin, IndianRupee, Bed, Bath, Move, 
  Check, ChevronRight, ChevronLeft, Upload, Trash2, 
  Save, AlertCircle, Sparkles, Building, Info, Image as ImageIcon,
  CheckCircle2, Loader2, Home, Layout, List
} from "lucide-react";
import PropertyMiniMap from "@/components/map/PropertyMiniMap";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue 
} from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import api from "@/services/api";
import { useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { toast as sonner } from "sonner";

const propertySchema = z.object({
  title: z.string().min(10, "Title must be at least 10 characters"),
  property_type: z.string().min(1, "Select property type"),
  listing_type: z.string().min(1, "Select listing type"),
  price: z.preprocess((val) => Number(val), z.number().min(100, "Price must be at least 100")),
  price_unit: z.string().default("total"),
  bedrooms: z.preprocess((val) => Number(val), z.number().min(0)),
  bathrooms: z.preprocess((val) => Number(val), z.number().min(0)),
  area_sqft: z.preprocess((val) => Number(val), z.number().min(10, "Area must be at least 10 sqft")),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  address: z.string().min(5, "Address must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  amenities: z.array(z.string()).default([]),
});

const STEPS = [
  { id: 1, title: "Basic Info", description: "Basic property details", icon: Home },
  { id: 2, title: "Location", description: "Address & surroundings", icon: MapPin },
  { id: 3, title: "Details", description: "Amenities & layout", icon: Layout },
  { id: 4, title: "Photos", description: "High-quality photos", icon: ImageIcon },
  { id: 5, title: "Review", description: "Review & publish", icon: List },
];

const AMENITIES_LIST = [
  "Swimming Pool", "Gym", "Private Garden", "Club House", 
  "Security", "Power Backup", "Parking", "Lift", 
  "Modular Kitchen", "Balcony", "Sea View", "Smart Home"
];

export default function PostProperty() {
  const [currentStep, setCurrentStep] = useState(1);
  const [images, setImages] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const embedded = location.pathname.startsWith("/agent/");
  const { profile } = useAuth();

  const methods = useForm({
    resolver: zodResolver(propertySchema),
    defaultValues: {
      title: "",
      property_type: "Apartment",
      listing_type: "sale",
      price: 0,
      price_unit: "total",
      bedrooms: 0,
      bathrooms: 0,
      area_sqft: 0,
      city: "",
      state: "",
      address: "",
      description: "",
      amenities: [],
      latitude: undefined,
      longitude: undefined,
    }
  });

  const { handleSubmit, trigger, watch, setValue, formState: { errors } } = methods;

  // Persistence: Load Draft
  useEffect(() => {
    const draft = localStorage.getItem("property_draft");
    if (draft) {
      try {
        const parsed = JSON.parse(draft);
        Object.keys(parsed.data).forEach(key => {
          setValue(key, parsed.data[key]);
        });
        setImages(parsed.images || []);
      } catch (e) {
        console.error("Draft parsing failed", e);
      }
    }
  }, [setValue]);

  // Auto-save Draft
  useEffect(() => {
    const subscription = watch((value) => {
      const data = methods.getValues();
      localStorage.setItem("property_draft", JSON.stringify({ data, images, timestamp: Date.now() }));
    });
    return () => subscription.unsubscribe();
  }, [watch, methods, images]);

  // Also auto-save when images change
  useEffect(() => {
    const data = methods.getValues();
    localStorage.setItem("property_draft", JSON.stringify({ data, images, timestamp: Date.now() }));
  }, [images, methods]);

  const saveDraft = () => {
    const data = methods.getValues();
    localStorage.setItem("property_draft", JSON.stringify({ data, images, timestamp: Date.now() }));
    toast({
      title: "Draft Saved",
      description: "You can resume this listing anytime.",
    });
  };

  const nextStep = async () => {
    const fieldsByStep = {
      1: ["title", "property_type", "listing_type", "price"],
      2: ["city", "state", "address"],
      3: ["bedrooms", "bathrooms", "area_sqft", "description"],
    };
    
    const isValid = await trigger(fieldsByStep[currentStep]);
    if (isValid) {
      setCurrentStep(prev => prev + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevStep = () => {
    setCurrentStep(prev => prev - 1);
    window.scrollTo(0, 0);
  };

  const handleImageUpload = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages(prev => {
          if (prev.length >= 5) return prev;
          return [...prev, { file, preview: reader.result }];
        });
      };
      reader.readAsDataURL(file);
    });
  };

  const removeImage = (index) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  const onSubmit = async (data) => {
    if (images.length === 0) {
      toast({
        title: "Photos Required",
        description: "Please upload at least one property photo.",
        variant: "destructive"
      });
      setCurrentStep(4);
      return;
    }

    setIsSubmitting(true);
    try {
      const imageUrls = images.map((img) => img.preview);
      const payload = {
        title: data.title,
        location: `${data.address}, ${data.city}`,
        address: data.address,
        city: data.city,
        state: data.state,
        price: data.price,
        priceUnit: data.price_unit,
        listing_type: data.listing_type,
        category: data.property_type,
        bedrooms: data.bedrooms,
        bathrooms: data.bathrooms,
        area_sqft: data.area_sqft,
        description: data.description,
        amenities: data.amenities,
        image: imageUrls[0],
        images: imageUrls,
        status: "available",
        latitude: data.latitude,
        longitude: data.longitude,
      };
      if (profile?.role === "admin") {
        toast({
          title: "Admin listing",
          description: "Assign agent_id when creating via API, or sign in as a listing agent to publish here.",
          variant: "destructive",
        });
        setIsSubmitting(false);
        return;
      }
      await api.post("/agent/properties", payload);
      
      toast({
        title: "Property Published!",
        description: "Your listing is now live across the PropNest network.",
      });
      sonner.success("Listing added", {
        description: "Your property is live on PropNest.",
      });
      localStorage.removeItem("property_draft");
      navigate(embedded ? "/agent/listings" : "/properties");
    } catch (error) {
      toast({
        title: "Submission Error",
        description: error.response?.data?.message || "Something went wrong.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#fcfcfd] dark:bg-background">
      {!embedded && <Navbar />}

      <main className={embedded ? "pt-4 pb-10" : "pt-24 pb-16"}>
        <div className="container mx-auto px-4 max-w-5xl">
          
          {/* Header Section */}
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-bold uppercase tracking-widest">
                <Sparkles className="w-3 h-3" /> Post Property
              </div>
              <h1 className="font-display text-4xl md:text-5xl font-black text-foreground tracking-tight italic">
                List Your <span className="text-primary italic">Property.</span>
              </h1>
              <p className="text-muted-foreground font-medium text-lg">Connect with genuine buyers and tenants instantly.</p>
            </div>
            <Button 
              variant="outline" 
              onClick={saveDraft}
              className="rounded-xl font-black uppercase tracking-widest text-[10px] gap-2 border-primary/20 hover:bg-primary/5"
            >
              <Save className="w-3.5 h-3.5" /> Save Draft
            </Button>
          </div>

          {/* Progress Path */}
          <div className="relative mb-16 px-4">
            <div className="absolute top-1/2 left-0 w-full h-0.5 bg-muted -translate-y-1/2" />
            <div 
              className="absolute top-1/2 left-0 h-0.5 bg-gradient-hero transition-all duration-500 -translate-y-1/2 shadow-[0_0_15px_rgba(var(--primary),0.5)]"
              style={{ width: `${((currentStep - 1) / (STEPS.length - 1)) * 100}%` }}
            />
            
            <div className="relative flex justify-between">
              {STEPS.map((step) => (
                <div key={step.id} className="flex flex-col items-center group">
                  <div className={`
                    w-12 h-12 rounded-2xl flex items-center justify-center font-black transition-all duration-500 z-10
                    ${currentStep >= step.id 
                      ? "bg-primary text-primary-foreground shadow-hero scale-110" 
                      : "bg-muted text-muted-foreground border-4 border-background"}
                  `}>
                    {currentStep > step.id ? <Check className="w-6 h-6" /> : <step.icon className="w-5 h-5" />}
                  </div>
                  <div className="absolute top-16 text-center transform -translate-x-1 w-24">
                    <p className={`text-[10px] font-black uppercase tracking-widest mb-1 transition-colors ${currentStep >= step.id ? "text-primary" : "text-muted-foreground/30"}`}>
                      Step 0{step.id}
                    </p>
                    <p className={`text-xs font-bold whitespace-nowrap hidden md:block ${currentStep >= step.id ? "text-foreground" : "text-muted-foreground/20"}`}>
                      {step.title}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Form Content */}
          <section className="bg-card rounded-[3rem] border border-border/50 shadow-sm overflow-hidden min-h-[500px]">
            <FormProvider {...methods}>
              <form onSubmit={handleSubmit(onSubmit)} className="p-8 md:p-12">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentStep}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.3 }}
                  >
                    {currentStep === 1 && <Step1BasicInfo />}
                    {currentStep === 2 && <Step2Location />}
                    {currentStep === 3 && <Step3Specifications />}
                    {currentStep === 4 && <Step4Images images={images} handleImageUpload={handleImageUpload} removeImage={removeImage} />}
                    {currentStep === 5 && <Step5Review images={images} />}
                  </motion.div>
                </AnimatePresence>

                {/* Navigation Controls */}
                <div className="mt-16 flex items-center justify-between pt-8 border-t border-border/50">
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={prevStep}
                    disabled={currentStep === 1}
                    className="h-14 px-8 rounded-2xl font-black uppercase tracking-widest text-xs gap-3 group"
                  >
                    <ChevronLeft className="w-4 h-4 transition-transform group-hover:-translate-x-1" /> Previous
                  </Button>

                  {currentStep < STEPS.length ? (
                    <Button
                      type="button"
                      onClick={nextStep}
                      className="h-14 px-10 rounded-2xl bg-gradient-hero text-primary-foreground shadow-hero font-black uppercase tracking-widest text-xs gap-3 group"
                    >
                      Next Step <ChevronRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      disabled={isSubmitting}
                      className="h-14 px-12 rounded-2xl bg-gradient-hero text-primary-foreground shadow-hero font-black uppercase tracking-widest text-xs gap-3 active:scale-95 transition-all"
                    >
                      {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <CheckCircle2 className="w-5 h-5" />}
                      {isSubmitting ? "Publishing..." : "Publish Property"}
                    </Button>
                  )}
                </div>
              </form>
            </FormProvider>
          </section>

          {/* Guidelines Footer */}
          <div className="mt-12 p-8 rounded-[2.5rem] bg-amber-500/5 border border-amber-500/10 flex gap-6">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 flex items-center justify-center shrink-0">
              <Info className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <h4 className="font-display font-black uppercase tracking-widest text-amber-900 mb-2">Quality Standards</h4>
              <p className="text-sm text-amber-800/70 font-medium leading-relaxed">
                Ensure all media assets are high-resolution (min 1080p) and descriptions are transparent. 
                Listings with accurate geolocation and verified price tags receive <span className="font-bold text-black">4x more conversion.</span>
              </p>
            </div>
          </div>
        </div>
      </main>

      {!embedded && <Footer />}
    </div>
  );
}

function Step1BasicInfo() {
  const { register, formState: { errors }, setValue, watch } = useFormContext();
  const propertyType = watch("property_type");
  const listingType = watch("listing_type");

  return (
    <div className="space-y-10">
      <div className="mb-8">
        <h2 className="font-display text-3xl font-black text-foreground italic mb-2">Basic Information</h2>
        <p className="text-muted-foreground font-medium">Enter the primary details for your property.</p>
      </div>

      <div className="grid gap-10">
        <div className="space-y-2 group">
          <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">Property Title</label>
          <div className="relative">
            <Home className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/30 group-within:text-primary transition-colors" />
            <Input 
              {...register("title")}
              className={`h-16 pl-14 rounded-2xl font-bold bg-muted/20 border-border/40 focus:ring-4 focus:ring-primary/10 transition-all ${errors.title ? "border-destructive focus:ring-destructive/10" : ""}`} 
              placeholder="e.g. Ultra-Luxury 4BHK Penthouse with Sea View"
            />
          </div>
          {errors.title && <p className="text-[10px] font-black uppercase tracking-widest text-destructive ml-2 animate-in fade-in slide-in-from-left-2 transition-all">{errors.title.message}</p>}
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1">Property Type</label>
            <Select onValueChange={(val) => setValue("property_type", val)} defaultValue={propertyType}>
              <SelectTrigger className="h-16 rounded-2xl bg-muted/20 border-border/40 font-bold px-6">
                <SelectValue placeholder="Select type" />
              </SelectTrigger>
              <SelectContent className="rounded-2xl shadow-hero border-border/50">
                {["Apartment", "Villa", "Penthouse", "Office", "Plot", "Shop"].map(t => (
                  <SelectItem key={t} value={t} className="rounded-xl font-bold">{t}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1">Listing Type</label>
            <div className="grid grid-cols-2 gap-4 p-1.5 bg-muted/30 rounded-2xl border border-border/40">
              {['sale', 'rent'].map(t => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setValue("listing_type", t)}
                  className={`py-3.5 rounded-xl font-black uppercase tracking-widest text-[10px] transition-all ${listingType === t ? "bg-primary text-primary-foreground shadow-hero" : "text-muted-foreground hover:bg-muted/50"}`}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-2 group">
          <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">Asking Price / Rent</label>
          <div className="relative max-w-sm">
            <IndianRupee className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/30 group-within:text-primary transition-colors" />
            <Input 
              type="number"
              {...register("price")}
              className={`h-16 pl-14 rounded-2xl font-bold bg-muted/20 border-border/40 focus:ring-4 focus:ring-primary/10 transition-all ${errors.price ? "border-destructive" : ""}`} 
              placeholder="5,00,00,000"
            />
            <div className="absolute right-5 top-1/2 -translate-y-1/2 flex items-center gap-2 pointer-events-none">
              <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{listingType === 'sale' ? 'Total' : '/ month'}</span>
            </div>
          </div>
          {errors.price && <p className="text-[10px] font-black uppercase tracking-widest text-destructive ml-2 transition-all">{errors.price.message}</p>}
        </div>
      </div>
    </div>
  );
}

function Step2Location() {
  const { register, formState: { errors }, watch, setValue } = useFormContext();

  const fetchAddressFromLatLng = async (lat, lng) => {
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`);
      const data = await response.json();
      if (data && data.address) {
        const addr = data.address;
        const city = addr.city || addr.town || addr.village || addr.state_district || "";
        const state = addr.state || "";
        if (city) setValue("city", city, { shouldValidate: true, shouldDirty: true });
        if (state) setValue("state", state, { shouldValidate: true, shouldDirty: true });
      }
    } catch (error) {
      console.error("Reverse geocoding failed", error);
    }
  };

  const handleForwardGeocode = async () => {
    const q = [watch("address"), watch("city"), watch("state")].filter(Boolean).join(", ");
    if (!q) return;
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(q)}&limit=1`);
      const data = await response.json();
      if (data && data.length > 0) {
        setValue("latitude", parseFloat(data[0].lat), { shouldValidate: true, shouldDirty: true });
        setValue("longitude", parseFloat(data[0].lon), { shouldValidate: true, shouldDirty: true });
      }
    } catch (error) {
      console.error("Forward geocoding failed", error);
    }
  };

  const cityReg = register("city");
  const stateReg = register("state");
  const addressReg = register("address");

  return (
    <div className="space-y-10">
       <div className="mb-8">
        <h2 className="font-display text-3xl font-black text-foreground italic mb-2">Location Details</h2>
        <p className="text-muted-foreground font-medium">Help buyers find your property accurately.</p>
      </div>

      <div className="grid gap-8">
         <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-2 group">
              <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">City</label>
              <Input 
                {...cityReg}
                onBlur={(e) => { cityReg.onBlur(e); handleForwardGeocode(); }}
                className={`h-16 px-6 rounded-2xl font-bold bg-muted/20 border-border/40 focus:ring-4 focus:ring-primary/10 transition-all ${errors.city ? "border-destructive" : ""}`} 
                placeholder="e.g. Mumbai"
              />
            </div>
            <div className="space-y-2 group">
               <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">State</label>
               <Input 
                 {...stateReg}
                 onBlur={(e) => { stateReg.onBlur(e); handleForwardGeocode(); }}
                 className={`h-16 px-6 rounded-2xl font-bold bg-muted/20 border-border/40 focus:ring-4 focus:ring-primary/10 transition-all ${errors.state ? "border-destructive" : ""}`} 
                 placeholder="e.g. Maharashtra"
               />
            </div>
         </div>

         <div className="space-y-2 group">
            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">Full Address</label>
            <div className="relative">
              <MapPin className="absolute left-5 top-6 w-5 h-5 text-muted-foreground/30 group-within:text-primary transition-colors" />
              <textarea 
                {...addressReg}
                onBlur={(e) => { addressReg.onBlur(e); handleForwardGeocode(); }}
                rows={4}
                className={`w-full h-32 p-6 pl-14 pt-5 rounded-[2rem] font-bold bg-muted/20 border border-border/40 outline-none focus:ring-4 focus:ring-primary/10 transition-all ${errors.address ? "border-destructive" : ""}`} 
                placeholder="Search building name, street, locality..."
              />
            </div>
            {errors.address && <p className="text-[10px] font-black uppercase tracking-widest text-destructive ml-2 transition-all">{errors.address.message}</p>}
         </div>

         {/* Interactive Map */}
         <PropertyMiniMap 
           property={{
             title: watch("title") || "Property Location",
             address: watch("address") || "",
             city: watch("city") || "",
             state: watch("state") || "",
             latitude: watch("latitude"),
             longitude: watch("longitude"),
           }}
           className="w-full h-64"
           draggable={true}
           onLocationSelect={(lat, lng) => {
             setValue("latitude", lat, { shouldValidate: true });
             setValue("longitude", lng, { shouldValidate: true });
             fetchAddressFromLatLng(lat, lng);
           }}
         />
      </div>
    </div>
  );
}

function Step3Specifications() {
  const { register, formState: { errors }, watch, setValue } = useFormContext();
  const selectedAmenities = watch("amenities") || [];

  const toggleAmenity = (amenity) => {
    const current = [...selectedAmenities];
    const index = current.indexOf(amenity);
    if (index > -1) {
      current.splice(index, 1);
    } else {
      current.push(amenity);
    }
    setValue("amenities", current);
  };

  return (
    <div className="space-y-12">
      <div className="mb-8">
        <h2 className="font-display text-3xl font-black text-foreground italic mb-2">Property Details</h2>
        <p className="text-muted-foreground font-medium">Bedrooms, bathrooms, area, and amenities.</p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
         <div className="space-y-2 group">
            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">Beds</label>
            <div className="relative">
              <Bed className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/30 group-within:text-primary" />
              <Input type="number" {...register("bedrooms")} className="h-16 pl-14 rounded-2xl font-bold bg-muted/20 border-border/40" />
            </div>
         </div>
         <div className="space-y-2 group">
            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">Baths</label>
            <div className="relative">
              <Bath className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/30 group-within:text-primary" />
              <Input type="number" {...register("bathrooms")} className="h-16 pl-14 rounded-2xl font-bold bg-muted/20 border-border/40" />
            </div>
         </div>
         <div className="space-y-2 group">
            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">Area (SQFT)</label>
            <div className="relative">
              <Move className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/30 group-within:text-primary" />
              <Input type="number" {...register("area_sqft")} className="h-16 pl-14 rounded-2xl font-bold bg-muted/20 border-border/40" />
            </div>
         </div>
      </div>

      <div className="space-y-4">
        <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1">Amenities</label>
        <div className="flex flex-wrap gap-3">
          {AMENITIES_LIST.map((amenity) => (
            <button
              key={amenity}
              type="button"
              onClick={() => toggleAmenity(amenity)}
              className={`px-6 py-3 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all ${selectedAmenities.includes(amenity) ? "bg-primary text-primary-foreground border-primary shadow-hero" : "bg-muted/30 border-border/40 text-muted-foreground hover:border-primary/30"}`}
            >
              {amenity}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2 group">
        <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-all group-within:text-primary">Property Description</label>
        <textarea 
          {...register("description")}
          rows={6}
          className={`w-full p-8 rounded-[2.5rem] font-bold bg-muted/20 border border-border/40 outline-none focus:ring-4 focus:ring-primary/10 transition-all ${errors.description ? "border-destructive" : ""}`} 
          placeholder="Describe your property details..."
        />
        {errors.description && <p className="text-[10px] font-black uppercase tracking-widest text-destructive ml-2 transition-all">{errors.description.message}</p>}
      </div>
    </div>
  );
}

function Step4Images({ images, handleImageUpload, removeImage }) {
  const fileInputRef = useRef(null);

  return (
    <div className="space-y-10">
       <div className="mb-8 text-center md:text-left">
        <h2 className="font-display text-3xl font-black text-foreground italic mb-2">Property Photos</h2>
        <p className="text-muted-foreground font-medium">Upload clear photos to attract more interest.</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="aspect-square rounded-[2rem] border-2 border-dashed border-primary/20 bg-primary/5 flex flex-col items-center justify-center gap-3 transition-all hover:bg-primary/10 group cursor-pointer"
        >
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform shadow-hero">
            <Upload className="w-6 h-6" />
          </div>
          <span className="text-[10px] font-black uppercase tracking-widest">Upload Photos</span>
        </button>
        <input type="file" ref={fileInputRef} className="hidden" multiple accept="image/*" onChange={handleImageUpload} />

        {images.map((img, index) => (
          <div key={index} className="relative aspect-square rounded-[2rem] overflow-hidden group shadow-sm">
            <img src={img.preview} alt="" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
               <button
                 type="button"
                 onClick={() => removeImage(index)}
                 className="w-12 h-12 rounded-2xl bg-destructive text-white flex items-center justify-center shadow-hero hover:scale-110 transition-transform active:scale-90"
               >
                 <Trash2 className="w-6 h-6" />
               </button>
            </div>
            {index === 0 && (
              <div className="absolute top-4 left-4 h-8 px-4 rounded-full bg-primary text-primary-foreground text-[10px] font-black uppercase tracking-widest flex items-center shadow-hero">
                Cover Photo
              </div>
            )}
          </div>
        ))}

        {images.length === 0 && (
           <div className="md:col-span-3 lg:col-span-4 flex items-center justify-center">
             <p className="text-[10px] font-black uppercase tracking-[0.2em] text-muted-foreground opacity-30 italic">No photos selected - Please upload at least one.</p>
           </div>
        )}
      </div>

      <div className="p-8 rounded-[2rem] border border-border/50 bg-muted/10 flex items-center gap-6">
         <Info className="w-8 h-8 text-primary shrink-0" />
         <p className="text-xs font-medium text-muted-foreground border-l border-border/50 pl-6">
            Upload at least one clear image to serve as the **Cover Photo**. High-quality photos lead to significantly higher buyer engagement.
         </p>
      </div>
    </div>
  );
}

function Step5Review({ images }) {
  const { watch } = useFormContext();
  const data = watch();

  return (
    <div className="space-y-12">
      <div className="mb-8">
        <h2 className="font-display text-3xl font-black text-foreground italic mb-2">Review & Submit</h2>
        <p className="text-muted-foreground font-medium">Review your property details before publishing.</p>
      </div>

      <div className="grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-7 space-y-10">
           <div className="grid gap-6">
              <div className="space-y-1">
                 <p className="text-[10px] font-black uppercase tracking-widest text-primary italic">Property</p>
                 <h3 className="font-display text-4xl font-black tracking-tight">{data.title || "Target Title Missing"}</h3>
              </div>
              <div className="flex flex-wrap gap-4">
                 <Badge text={data.property_type} />
                 <Badge text={data.listing_type} primary />
                 <Badge text={`₹ ${data.price.toLocaleString("en-IN")} ${data.price_unit}`} />
              </div>
           </div>

           <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-8 rounded-[2.5rem] border border-border/50 bg-muted/10">
              <Stat icon={Bed} value={data.bedrooms} label="Bedrooms" />
              <Stat icon={Bath} value={data.bathrooms} label="Bathrooms" />
              <Stat icon={Move} value={`${data.area_sqft} SQFT`} label="Area" />
              <Stat icon={Building} value={data.property_type} label="Classification" />
           </div>

           <div className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Location</h4>
              <p className="text-lg font-bold flex gap-3">
                 <MapPin className="w-6 h-6 text-primary shrink-0 mt-1" />
                 {data.address}, {data.city}, {data.state}
              </p>
           </div>

           <div className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Description</h4>
              <p className="text-muted-foreground leading-relaxed font-medium">{data.description}</p>
           </div>
        </div>

        <div className="lg:col-span-5 space-y-8">
           <div className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Photos</h4>
              <div className="grid grid-cols-2 gap-4">
                 {images.slice(0, 4).map((img, i) => (
                    <div key={i} className="aspect-square rounded-2xl overflow-hidden border border-border/50">
                       <img src={img.preview} className="w-full h-full object-cover" />
                    </div>
                 ))}
                 {images.length === 0 && <div className="aspect-video col-span-2 rounded-3xl bg-muted animate-pulse" />}
              </div>
           </div>

           <div className="space-y-4">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Selected Amenities</h4>
              <div className="flex flex-wrap gap-2">
                 {data.amenities.map(a => (
                    <span key={a} className="px-5 py-2.5 rounded-xl bg-primary/5 text-primary text-[10px] font-black uppercase tracking-[0.15em] border border-primary/10 transition-all hover:bg-primary hover:text-white">{a}</span>
                 ))}
                 {data.amenities.length === 0 && <p className="text-xs text-muted-foreground italic">No amenities selected.</p>}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
}

function Badge({ text, primary = false }) {
  return (
    <span className={`px-6 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest border transition-all ${primary ? "bg-primary text-primary-foreground border-primary shadow-hero" : "bg-card text-foreground border-border/60 hover:border-primary/40"}`}>
      {text}
    </span>
  );
}

function Stat({ icon: Icon, value, label }) {
  return (
    <div className="flex flex-col items-center gap-2">
       <div className="w-10 h-10 rounded-xl bg-muted/60 flex items-center justify-center text-primary group transition-all">
          <Icon className="w-5 h-5 transition-transform group-hover:scale-110" />
       </div>
       <div className="text-center">
          <p className="text-sm font-black text-foreground leading-none">{value}</p>
          <p className="text-[8px] font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
       </div>
    </div>
  );
}
