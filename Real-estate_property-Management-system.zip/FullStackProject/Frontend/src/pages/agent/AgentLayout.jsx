import { Outlet, useLocation } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import AgentSidebar from "@/components/agent/AgentSidebar";
import { cn } from "@/lib/utils";

const TITLE_MAP = [
  { match: "/agent/add-property", title: "Add property" },
  { match: "/agent/listings", title: "My listings" },
  { match: "/agent/leads", title: "Leads" },
  { match: "/agent/messages", title: "Messages" },
  { match: "/agent/profile", title: "Profile" },
];

function headerTitle(pathname) {
  const row = TITLE_MAP.find((t) => pathname.startsWith(t.match));
  if (row) return row.title;
  if (pathname === "/agent" || pathname === "/agent/") return "Dashboard";
  return "Agent workspace";
}

export default function AgentLayout() {
  const { pathname } = useLocation();

  return (
    <SidebarProvider>
      <div
        className={cn(
          "min-h-screen flex w-full",
          "bg-[#f4f6f8] text-foreground dark:bg-background",
        )}
        data-app-shell="agent"
      >
        <AgentSidebar />
        <div className="flex-1 flex flex-col min-w-0 border-l border-border/60 bg-background/80 backdrop-blur-sm">
          <header className="h-14 flex items-center gap-3 border-b border-border bg-card/90 px-4 sticky top-0 z-30 shadow-sm">
            <SidebarTrigger className="text-muted-foreground shrink-0" />
            <div className="min-w-0">
              <h1 className="font-display text-lg font-bold capitalize truncate">
                {headerTitle(pathname)}
              </h1>
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-widest hidden sm:block">
                PropNest · Agent
              </p>
            </div>
          </header>
          <main className="flex-1 p-4 md:p-6 overflow-auto">
            <Outlet />
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}
