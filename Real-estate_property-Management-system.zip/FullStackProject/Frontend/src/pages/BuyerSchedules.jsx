import { useQuery } from '@tanstack/react-query';
import api from '@/services/api';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { MapPin, Mail, User, Calendar, MessageSquare, Clock } from 'lucide-react';

export default function BuyerSchedules() {
  const { data: responseData, isLoading, isError, error } = useQuery({
    queryKey: ['my-requests'], // same query key as inquiries to share cache
    queryFn: async () => {
      const res = await api.get('/leads/my-requests');
      return res.data;
    }
  });

  const schedules = (responseData?.data || []).filter(
    req => req.lead_type === 'site_visit' || req.status === 'site_visit'
  );

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted-foreground font-black text-[10px] uppercase tracking-widest">Loading Schedules...</p>
        </div>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-red-500 font-medium">Error loading schedules: {error.message}</p>
      </div>
    );
  }

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case 'confirmed':
      case 'completed':
      case 'scheduled':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'cancelled':
      case 'rejected':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'rescheduled':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'pending':
      default:
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="pt-24 pb-20 container mx-auto px-4">
        <h1 className="font-display text-4xl font-black text-foreground mb-8">My Schedules</h1>
        
        {schedules.length === 0 ? (
          <div className="py-20 text-center bg-card rounded-2xl border border-dashed border-border">
            <p className="text-muted-foreground font-medium text-lg">You have no site visit schedules yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {schedules.map((req) => (
              <motion.div 
                key={req._id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="flex justify-between items-start mb-4">
                  <h3 className="font-bold text-xl line-clamp-1">{req.property_id?.title || 'Unknown Property'}</h3>
                  <span className={`px-3 py-1 rounded-full text-xs font-bold border uppercase tracking-wider ${getStatusColor(req.visit_status)}`}>
                    {req.visit_status || 'pending'}
                  </span>
                </div>
                
                <div className="flex items-center text-muted-foreground text-sm mb-4">
                  <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
                  <span className="line-clamp-1">{req.property_id?.address || 'Address unavailable'}</span>
                </div>

                <div className="space-y-3 mb-6 bg-muted/30 p-4 rounded-xl">
                  <div className="flex items-center text-sm">
                    <User className="w-4 h-4 mr-2 text-primary flex-shrink-0" />
                    <span className="font-medium">Agent:</span>
                    <span className="ml-2 text-muted-foreground truncate">{req.agent_id?.name || 'Unknown'}</span>
                  </div>
                  <div className="flex items-center text-sm">
                    <Mail className="w-4 h-4 mr-2 text-primary flex-shrink-0" />
                    <span className="font-medium">Email:</span>
                    <span className="ml-2 text-muted-foreground truncate">{req.agent_id?.email || 'N/A'}</span>
                  </div>
                </div>

                <div className="space-y-3 mb-4 text-sm bg-primary/5 p-4 rounded-xl border border-primary/10">
                  <div className="flex items-start">
                    <Calendar className="w-4 h-4 mr-2 mt-0.5 text-primary flex-shrink-0" />
                    <div>
                      <span className="font-bold block mb-1 text-primary">Requested Date & Time:</span>
                      <p className="text-foreground font-medium">
                        {req.visit_date ? new Date(req.visit_date).toLocaleDateString('en-US', {
                          weekday: 'short',
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric'
                        }) : 'Not specified'}
                        <span className="block mt-1 flex items-center text-muted-foreground">
                          <Clock className="w-3.5 h-3.5 mr-1" />
                          {req.visit_slot || 'Any time'}
                        </span>
                      </p>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t border-border/50 flex flex-col gap-2 text-xs text-muted-foreground">
                  <span className="italic">
                    {req.visit_note ? `Note: ${req.visit_note}` : 'No additional notes'}
                  </span>
                  
                  {req.visit_agent_message && (
                    <span className="italic font-medium text-foreground bg-muted p-2 rounded-lg">
                      Agent replied: {req.visit_agent_message}
                    </span>
                  )}

                  <div className="flex justify-end mt-2">
                    {(req.status === 'accepted' || req.visit_status === 'confirmed' || req.visit_status === 'scheduled' || req.visit_status === 'completed') && (
                      <Button asChild size="sm" variant="secondary" className="h-8 text-[10px] font-bold rounded-lg px-3">
                        <Link to="/buyer/messages">
                          <MessageSquare className="w-3.5 h-3.5 mr-1.5" /> Chat
                        </Link>
                      </Button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  );
}
