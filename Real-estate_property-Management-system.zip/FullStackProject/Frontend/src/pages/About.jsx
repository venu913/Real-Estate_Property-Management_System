import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { Building2, Users, Award, MapPin } from "lucide-react";

const stats = [
  { icon: Building2, value: "10,000+", label: "Properties Listed" },
  { icon: Users, value: "15,000+", label: "Happy Customers" },
  { icon: Award, value: "50+", label: "Awards Won" },
  { icon: MapPin, value: "500+", label: "Cities Covered" },
];

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-3xl mx-auto text-center mb-16"
          >
            <p className="text-primary font-semibold text-sm uppercase tracking-wider mb-2">
              About Us
            </p>
            <h1 className="font-display text-4xl lg:text-5xl font-bold text-foreground mb-6">
              India's Most Trusted{" "}
              <span className="text-gradient-hero">Property Platform</span>
            </h1>
            <p className="text-muted-foreground text-lg leading-relaxed">
              PropNest is redefining how Indians find, buy, and rent properties.
              With RERA-verified listings, expert agents, and transparent
              pricing, we make property search simple, safe, and delightful.
            </p>
          </motion.div>

          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-20">
            {stats.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-card rounded-2xl p-8 text-center shadow-card border border-border/50"
              >
                <s.icon className="w-8 h-8 text-primary mx-auto mb-3" />
                <p className="font-display text-3xl font-bold text-foreground">
                  {s.value}
                </p>
                <p className="text-muted-foreground text-sm mt-1">{s.label}</p>
              </motion.div>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <img
                src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800"
                alt="Team"
                className="rounded-2xl shadow-card-hover"
                loading="lazy"
              />
            </motion.div>
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="font-display text-3xl font-bold text-foreground mb-4">
                Our Mission
              </h2>
              <p className="text-muted-foreground leading-relaxed mb-4">
                We believe every Indian deserves a home they love. PropNest
                bridges the gap between property seekers and verified
                sellers/agents through technology, transparency, and trust.
              </p>
              <p className="text-muted-foreground leading-relaxed">
                Founded in 2020, we've grown from a small Mumbai startup to
                serving over 500 cities across India. Our AI-powered
                recommendations, RERA verification, and dedicated support team
                ensure a seamless experience.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
