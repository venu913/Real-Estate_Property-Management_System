import { Navigate } from "react-router-dom";

/** @deprecated Use `/agent` */
export default function AgentDashboard() {
  return <Navigate to="/agent" replace />;
}
