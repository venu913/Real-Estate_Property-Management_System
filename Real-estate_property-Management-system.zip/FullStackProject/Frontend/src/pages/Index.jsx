import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import FeaturedProperties from "@/components/FeaturedProperties";
import TrendingProperties from "@/components/TrendingProperties";
import SmartRecommendationHub from "@/components/buyer/SmartRecommendationHub";
import RecentlyViewedHome from "@/components/buyer/RecentlyViewedHome";
import PersonalizedHomeBanner from "@/components/buyer/PersonalizedHomeBanner";
import CityExplorer from "@/components/CityExplorer";
import WhyChooseUs from "@/components/WhyChooseUs";
import Testimonials from "@/components/Testimonials";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";
import OnboardingWizard from "@/components/onboarding/OnboardingWizard";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";

const Index = () => {
  const { onboarding } = useBuyerActivity();
  const [wizardOpen, setWizardOpen] = useState(false);

  useEffect(() => {
    if (onboarding && !onboarding.completed) {
      const id = window.setTimeout(() => setWizardOpen(true), 400);
      return () => window.clearTimeout(id);
    }
  }, [onboarding?.completed]);

  return (
    <div className="min-h-screen bg-background" data-app-shell="buyer">
      <OnboardingWizard open={wizardOpen} onOpenChange={setWizardOpen} />
      <Navbar />
      <HeroSection />
      <PersonalizedHomeBanner />
      <FeaturedProperties />
      <SmartRecommendationHub />
      <RecentlyViewedHome />
      <TrendingProperties />
      <CityExplorer />
      <WhyChooseUs />
      <Testimonials />
      <CTASection />
      <Footer />
    </div>
  );
};

export default Index;
