import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import { Building2, Mail, Lock, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

import { useToast } from "@/hooks/use-toast";

import { useAuth } from "@/contexts/AuthContext";
import { authService } from "@/services/auth.service";
import {
  getPostLoginRedirect,
  deriveRoleFromUser,
  resolveEffectiveRole,
  ROLE_OVERRIDE_STORAGE_KEY,
} from "@/lib/authPaths";
import { setActiveTokenPreservingPrevious } from "@/lib/authTokens";
export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const { refreshProfile } = useAuth();

  const from = location.state?.from || "/";

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const data = await authService.login({
        email,
        password,
      });

      let previousEmail = "";
      try {
        if (localStorage.getItem("token")) {
          const cur = await authService.me();
          previousEmail = cur?.email || "";
        }
      } catch {
        /* no valid prior session */
      }
      setActiveTokenPreservingPrevious(data.token, previousEmail);
      const me = await authService.me();
      await refreshProfile();
      const base = deriveRoleFromUser(me);
      const override = localStorage.getItem(ROLE_OVERRIDE_STORAGE_KEY);
      const effective = resolveEffectiveRole(base, override);

      toast({
        title: "Welcome back!",
        description: "You've been logged in successfully.",
      });
      navigate(getPostLoginRedirect(effective, from), { replace: true });
    } catch (error) {
      const message = error.response?.data?.message || error.message || "An error occurred during login.";
      toast({
        title: "Login Failed",
        description: message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex">
      {/* Left - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-gradient-hero items-center justify-center p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=1200')] bg-cover bg-center opacity-20" />
        <div className="relative z-10 text-center">
          <div className="w-20 h-20 rounded-2xl bg-primary-foreground/20 backdrop-blur-sm flex items-center justify-center mx-auto mb-8">
            <Building2 className="w-10 h-10 text-primary-foreground" />
          </div>
          <h1 className="font-display text-5xl font-bold text-primary-foreground mb-4">
            PropNest
          </h1>
          <p className="text-primary-foreground/80 text-lg max-w-md">
            India's most trusted property platform. Find your dream home today.
          </p>
        </div>
      </div>

      {/* Right - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 bg-background">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md space-y-8"
        >
          <div className="lg:hidden flex items-center gap-2 justify-center mb-4">
            <div className="w-10 h-10 rounded-lg bg-gradient-hero flex items-center justify-center">
              <Building2 className="w-5 h-5 text-primary-foreground" />
            </div>
            <span className="font-display text-xl font-bold text-foreground">
              PropNest
            </span>
          </div>

          <div className="text-center">
            <h2 className="font-display text-3xl font-bold text-foreground">
              Welcome Back
            </h2>
            <p className="text-muted-foreground mt-2">
              Sign in to your account
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-5">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Email
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10"
                  required
                />

                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? (
                    <EyeOff className="w-4 h-4" />
                  ) : (
                    <Eye className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>

            <div className="flex justify-end">
              <Link
                to="/forgot-password"
                className="text-sm text-primary hover:underline"
              >
                Forgot password?
              </Link>
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed">
              Already signed in? Signing in again keeps previous accounts in{" "}
              <strong className="text-foreground">Switch user</strong> (Role card, bottom-right).
            </p>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-hero text-primary-foreground shadow-hero font-semibold h-12 text-base"
            >
              {loading ? "Signing in..." : "Sign In"}
            </Button>
          </form>

          <p className="text-center text-sm text-muted-foreground">
            Don't have an account?{" "}
            <Link
              to="/signup"
              className="text-primary font-semibold hover:underline"
            >
              Create Account
            </Link>
          </p>
        </motion.div>
      </div>
    </div>
  );
}
