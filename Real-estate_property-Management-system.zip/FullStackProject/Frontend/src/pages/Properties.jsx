import { useMemo, useState, useCallback, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  MapPin,
  X,
  ChevronDown,
  Filter,
  SortAsc,
  Loader2,
  LayoutGrid,
  Map as MapIcon,
  Columns2,
} from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { cities, filterAmenityOptions } from "@/lib/data";
import { cn } from "@/lib/utils";
import api from "@/services/api";
import { useDebouncedValue } from "@/hooks/useDebouncedValue";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuLabel,
  DropdownMenuRadioGroup,
  DropdownMenuRadioItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import PropertiesLiveMap from "@/components/map/PropertiesLiveMap";
import PropertySplitMapExplorer from "@/components/map/PropertySplitMapExplorer";

const PRICE_MIN = 0;
const PRICE_MAX = 200000000;
const PRICE_STEP = 100000;

const CATEGORY_OPTIONS = [
  { value: "all", label: "All types" },
  { value: "Apartment", label: "Apartment" },
  { value: "Villa", label: "Villa" },
  { value: "Plot", label: "Plot" },
];

function formatPriceShort(price) {
  if (price >= 10000000) return `${(price / 10000000).toFixed(2)} Cr`;
  if (price >= 100000) return `${(price / 100000).toFixed(2)} L`;
  return `₹${price.toLocaleString("en-IN")}`;
}

export default function Properties() {
  const [searchParams] = useSearchParams();
  const { recordSearchPrefs } = useBuyerActivity();
  const [keywordInput, setKeywordInput] = useState("");
  const debouncedKeyword = useDebouncedValue(keywordInput, 400);
  const [categoryFilter, setCategoryFilter] = useState("");
  const [listingTypeFilter, setListingTypeFilter] = useState("all");
  const [cityFilter, setCityFilter] = useState("");
  const [cityOpen, setCityOpen] = useState(false);
  const [bhkFilter, setBhkFilter] = useState("all");
  const [priceRange, setPriceRange] = useState([PRICE_MIN, PRICE_MAX]);
  const [amenityFilters, setAmenityFilters] = useState([]);
  const [sortBy, setSortBy] = useState("newest");
  const [resultsView, setResultsView] = useState("list");
  const [mapUserLocation, setMapUserLocation] = useState(null);

  useEffect(() => {
    const city = searchParams.get("city");
    const cat = searchParams.get("category");
    const minP = searchParams.get("minPrice");
    const maxP = searchParams.get("maxPrice");
    if (city) setCityFilter(city);
    if (cat) setCategoryFilter(cat);
    if (minP || maxP) {
      setPriceRange([
        minP ? Math.max(PRICE_MIN, parseInt(minP, 10) || PRICE_MIN) : PRICE_MIN,
        maxP ? Math.min(PRICE_MAX, parseInt(maxP, 10) || PRICE_MAX) : PRICE_MAX,
      ]);
    }
  }, [searchParams]);

  const queryParams = useMemo(() => {
    const p = {};
    const q = debouncedKeyword.trim();
    if (q) p.q = q;
    if (cityFilter) p.city = cityFilter;
    if (listingTypeFilter !== "all") p.listingType = listingTypeFilter;
    if (categoryFilter) p.category = categoryFilter;
    p.minPrice = priceRange[0];
    p.maxPrice = priceRange[1];
    if (bhkFilter !== "all") p.bhk = bhkFilter;
    if (amenityFilters.length) p.amenities = amenityFilters.join(",");
    if (sortBy) p.sort = sortBy;
    return p;
  }, [
    debouncedKeyword,
    cityFilter,
    listingTypeFilter,
    categoryFilter,
    priceRange,
    bhkFilter,
    amenityFilters,
    sortBy,
  ]);

  useEffect(() => {
    const t = setTimeout(() => {
      recordSearchPrefs({
        city: cityFilter || undefined,
        category: categoryFilter || undefined,
        priceMin: priceRange[0],
        priceMax: priceRange[1],
        bhk: bhkFilter,
        listingType: listingTypeFilter,
        keyword: debouncedKeyword.trim() || undefined,
      });
    }, 450);
    return () => clearTimeout(t);
  }, [
    cityFilter,
    categoryFilter,
    priceRange,
    bhkFilter,
    listingTypeFilter,
    debouncedKeyword,
    recordSearchPrefs,
  ]);

  const {
    data: properties = [],
    isLoading,
    isFetching,
    isError,
  } = useQuery({
    queryKey: ["properties", queryParams],
    queryFn: async () => {
      const res = await api.get("/properties", { params: queryParams });
      return res.data;
    },
  });

  const toggleAmenity = useCallback((name) => {
    setAmenityFilters((prev) =>
      prev.includes(name)
        ? prev.filter((a) => a !== name)
        : [...prev, name],
    );
  }, []);

  const clearAllFilters = useCallback(() => {
    setKeywordInput("");
    setCategoryFilter("");
    setListingTypeFilter("all");
    setCityFilter("");
    setBhkFilter("all");
    setPriceRange([PRICE_MIN, PRICE_MAX]);
    setAmenityFilters([]);
    setSortBy("newest");
  }, []);

  const priceIsNarrowed =
    priceRange[0] > PRICE_MIN || priceRange[1] < PRICE_MAX;

  const filterTags = useMemo(() => {
    const tags = [];
    if (cityFilter) {
      tags.push({
        key: "city",
        label: `City: ${cityFilter}`,
        onRemove: () => setCityFilter(""),
      });
    }
    if (debouncedKeyword.trim()) {
      tags.push({
        key: "q",
        label: `“${debouncedKeyword.trim()}”`,
        onRemove: () => setKeywordInput(""),
      });
    }
    if (categoryFilter) {
      tags.push({
        key: "category",
        label: categoryFilter,
        onRemove: () => setCategoryFilter(""),
      });
    }
    if (listingTypeFilter !== "all") {
      tags.push({
        key: "listing",
        label: `For ${listingTypeFilter}`,
        onRemove: () => setListingTypeFilter("all"),
      });
    }
    if (bhkFilter !== "all") {
      tags.push({
        key: "bhk",
        label: bhkFilter === "4+" ? "4+ BHK" : `${bhkFilter} BHK`,
        onRemove: () => setBhkFilter("all"),
      });
    }
    if (priceIsNarrowed) {
      tags.push({
        key: "price",
        label: `${formatPriceShort(priceRange[0])} – ${formatPriceShort(priceRange[1])}`,
        onRemove: () => setPriceRange([PRICE_MIN, PRICE_MAX]),
      });
    }
    amenityFilters.forEach((a) => {
      tags.push({
        key: `amenity-${a}`,
        label: a,
        onRemove: () => toggleAmenity(a),
      });
    });
    return tags;
  }, [
    cityFilter,
    debouncedKeyword,
    categoryFilter,
    listingTypeFilter,
    bhkFilter,
    priceIsNarrowed,
    priceRange,
    amenityFilters,
    toggleAmenity,
  ]);

  const hasActiveFilters =
    filterTags.length > 0 || sortBy !== "newest";

  const mapFitKey = useMemo(
    () => properties.map((p) => String(p._id || p.id)).join(","),
    [properties],
  );

  const keywordPending =
    keywordInput.trim() !== debouncedKeyword.trim();

  const FilterSidebar = ({ className }) => (
    <div className={cn("space-y-8", className)}>
      <div>
        <h3 className="text-xs font-black text-muted-foreground uppercase tracking-widest mb-4">
          Listing
        </h3>
        <div className="flex flex-wrap gap-2">
          {["all", "sale", "rent"].map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setListingTypeFilter(t)}
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold capitalize transition-all border",
                listingTypeFilter === t
                  ? "bg-primary text-primary-foreground border-primary shadow-hero"
                  : "bg-card border-border hover:border-primary/50 text-muted-foreground",
              )}
            >
              {t === "all" ? "All" : `For ${t}`}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-xs font-black text-muted-foreground uppercase tracking-widest mb-4">
          Property type
        </h3>
        <div className="flex flex-wrap gap-2">
          {CATEGORY_OPTIONS.filter((o) => o.value !== "all").map((o) => (
            <button
              key={o.value}
              type="button"
              onClick={() =>
                setCategoryFilter(categoryFilter === o.value ? "" : o.value)
              }
              className={cn(
                "px-4 py-2 rounded-xl text-xs font-bold transition-all border",
                categoryFilter === o.value
                  ? "bg-primary text-primary-foreground border-primary shadow-lg"
                  : "bg-muted/50 border-white/5 hover:border-primary/30 text-muted-foreground",
              )}
            >
              {o.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <h3 className="text-xs font-black text-muted-foreground uppercase tracking-widest mb-4">
          BHK
        </h3>
        <div className="grid grid-cols-3 gap-2">
          {["all", "1", "2", "3", "4+"].map((b) => (
            <button
              key={b}
              type="button"
              onClick={() => setBhkFilter(b)}
              className={cn(
                "h-11 rounded-xl text-xs font-bold transition-all border",
                bhkFilter === b
                  ? "bg-primary text-primary-foreground border-primary shadow-lg"
                  : "bg-muted/50 border-white/5 hover:border-primary/30 text-muted-foreground",
              )}
            >
              {b === "all" ? "Any" : b === "4+" ? "4+" : `${b} BHK`}
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xs font-black text-muted-foreground uppercase tracking-widest">
            Price range
          </h3>
          <span className="text-xs font-bold text-primary tabular-nums">
            {formatPriceShort(priceRange[0])} – {formatPriceShort(priceRange[1])}
          </span>
        </div>
        <Slider
          value={priceRange}
          min={PRICE_MIN}
          max={PRICE_MAX}
          step={PRICE_STEP}
          minStepsBetweenThumbs={1}
          onValueChange={(v) => setPriceRange(v)}
          className="py-2"
        />
        <div className="flex justify-between mt-1 text-[10px] font-bold text-muted-foreground">
          <span>Min</span>
          <span>20 Cr+</span>
        </div>
      </div>

      <div>
        <h3 className="text-xs font-black text-muted-foreground uppercase tracking-widest mb-3">
          Amenities
        </h3>
        <ScrollArea className="h-[220px] rounded-xl border border-border/60 bg-muted/20 pr-3">
          <div className="space-y-3 p-3">
            {filterAmenityOptions.map((name) => (
              <div key={name} className="flex items-center gap-3">
                <Checkbox
                  id={`am-${name}`}
                  checked={amenityFilters.includes(name)}
                  onCheckedChange={() => toggleAmenity(name)}
                />
                <Label
                  htmlFor={`am-${name}`}
                  className="text-sm font-medium leading-none cursor-pointer"
                >
                  {name}
                </Label>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>

      <Button
        type="button"
        variant="ghost"
        onClick={clearAllFilters}
        className="w-full h-12 text-destructive hover:bg-destructive/5 font-bold uppercase tracking-widest text-[10px]"
      >
        Clear all filters
      </Button>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="pt-24 pb-16">
        <section className="bg-muted/30 border-y border-border/40 mb-12 py-12 md:py-16 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-primary/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
          <div className="container mx-auto px-4 relative z-10">
            <motion.h1
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="font-display text-4xl md:text-5xl font-black text-foreground mb-8 max-w-3xl"
            >
              Collection of <span className="text-gradient-hero">Prime Relics.</span>
            </motion.h1>

            <div className="max-w-5xl rounded-2xl border border-border bg-card/95 backdrop-blur-sm p-3 sm:p-4 shadow-lg">
              <div className="flex flex-col lg:flex-row gap-3 lg:items-stretch">
                <Popover open={cityOpen} onOpenChange={setCityOpen}>
                  <PopoverTrigger asChild>
                    <Button
                      type="button"
                      variant="outline"
                      role="combobox"
                      aria-expanded={cityOpen}
                      className="h-14 lg:h-[4.5rem] justify-between rounded-xl border-border font-semibold px-4 lg:w-[200px] shrink-0"
                    >
                      <span className="flex items-center gap-2 truncate">
                        <MapPin className="h-4 w-4 shrink-0 text-primary" />
                        {cityFilter || "City"}
                      </span>
                      <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-[min(100vw-2rem,320px)] p-0" align="start">
                    <Command>
                      <CommandInput placeholder="Search city..." />
                      <CommandList>
                        <CommandEmpty>No city found.</CommandEmpty>
                        <CommandGroup>
                          <CommandItem
                            value="__all__"
                            onSelect={() => {
                              setCityFilter("");
                              setCityOpen(false);
                            }}
                          >
                            All cities
                          </CommandItem>
                          {cities.map((c) => (
                            <CommandItem
                              key={c}
                              value={c}
                              onSelect={() => {
                                setCityFilter(c);
                                setCityOpen(false);
                              }}
                            >
                              {c}
                            </CommandItem>
                          ))}
                        </CommandGroup>
                      </CommandList>
                    </Command>
                  </PopoverContent>
                </Popover>

                <div className="relative flex-1 min-w-0 group">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground group-focus-within:text-primary transition-colors pointer-events-none" />
                  <input
                    value={keywordInput}
                    onChange={(e) => setKeywordInput(e.target.value)}
                    placeholder="Keyword: locality, project, landmark..."
                    className="w-full h-14 lg:h-[4.5rem] pl-12 pr-12 rounded-xl bg-muted/30 border border-border focus:ring-4 ring-primary/10 focus:border-primary/50 text-foreground font-semibold outline-none transition-all"
                  />
                  {(keywordPending || (isFetching && !isLoading)) && (
                    <Loader2 className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-primary animate-spin" />
                  )}
                </div>

                <Select
                  value={categoryFilter || "all"}
                  onValueChange={(v) => setCategoryFilter(v === "all" ? "" : v)}
                >
                  <SelectTrigger className="h-14 lg:h-[4.5rem] rounded-xl font-semibold border-border lg:w-[180px] shrink-0">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent className="rounded-xl">
                    {CATEGORY_OPTIONS.map((o) => (
                      <SelectItem key={o.value} value={o.value} className="font-medium">
                        {o.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </section>

        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row gap-10">
            <aside className="hidden lg:block w-80 shrink-0">
              <div className="sticky top-24 self-start max-h-[calc(100vh-7rem)] overflow-y-auto overscroll-contain pr-2 pb-4">
                <div className="rounded-2xl border border-border/60 bg-card/50 p-6 shadow-sm">
                  <h2 className="font-display text-lg font-black mb-6 flex items-center gap-2">
                    <Filter className="w-5 h-5 text-primary" />
                    Filters
                  </h2>
                  <FilterSidebar />
                </div>
              </div>
            </aside>

            <div className="flex-1 min-w-0">
              <div className="flex flex-col gap-4 mb-6 pb-6 border-b border-border/40">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-3">
                    <p
                      className={cn(
                        "text-sm font-black text-foreground uppercase tracking-wide tabular-nums",
                        isFetching && "opacity-80",
                      )}
                    >
                      {isLoading
                        ? "Searching…"
                        : isError
                          ? "Could not load listings"
                          : `${properties.length} ${properties.length === 1 ? "property" : "properties"} found`}
                    </p>

                    <Sheet>
                      <SheetTrigger asChild>
                        <Button
                          variant="outline"
                          className="lg:hidden h-10 rounded-xl font-bold gap-2"
                        >
                          <Filter className="w-4 h-4" />
                          Filters
                          {filterTags.length > 0 && (
                            <Badge variant="secondary" className="ml-1 rounded-md px-1.5">
                              {filterTags.length}
                            </Badge>
                          )}
                        </Button>
                      </SheetTrigger>
                      <SheetContent
                        side="left"
                        className="w-full max-w-md flex flex-col"
                      >
                        <SheetHeader className="mb-4 text-left">
                          <SheetTitle className="font-display text-2xl font-black">
                            Filters
                          </SheetTitle>
                        </SheetHeader>
                        <ScrollArea className="flex-1 -mr-4 pr-4">
                          <FilterSidebar className="pb-8" />
                        </ScrollArea>
                      </SheetContent>
                    </Sheet>
                  </div>

                  <div className="flex items-center gap-1 sm:gap-2 rounded-xl border border-border p-1 bg-muted/20 overflow-x-auto max-w-[100vw] sm:max-w-none">
                    <button
                      type="button"
                      onClick={() => setResultsView("list")}
                      className={cn(
                        "h-9 px-2 sm:px-3 rounded-lg text-xs font-black uppercase tracking-wide flex items-center gap-1.5 sm:gap-2 transition-colors shrink-0",
                        resultsView === "list"
                          ? "bg-card text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      <LayoutGrid className="w-4 h-4" />
                      <span className="hidden sm:inline">List</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setResultsView("split")}
                      className={cn(
                        "h-9 px-2 sm:px-3 rounded-lg text-xs font-black uppercase tracking-wide flex items-center gap-1.5 sm:gap-2 transition-colors shrink-0",
                        resultsView === "split"
                          ? "bg-card text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      <Columns2 className="w-4 h-4" />
                      <span className="hidden sm:inline">Split</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setResultsView("map")}
                      className={cn(
                        "h-9 px-2 sm:px-3 rounded-lg text-xs font-black uppercase tracking-wide flex items-center gap-1.5 sm:gap-2 transition-colors shrink-0",
                        resultsView === "map"
                          ? "bg-card text-foreground shadow-sm"
                          : "text-muted-foreground hover:text-foreground",
                      )}
                    >
                      <MapIcon className="w-4 h-4" />
                      <span className="hidden sm:inline">Map</span>
                    </button>
                  </div>

                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button
                        variant="ghost"
                        className="h-10 rounded-xl font-bold gap-2 hover:bg-muted"
                      >
                        <SortAsc className="w-4 h-4" />
                        <span className="hidden sm:inline">Sort:</span>
                        <span className="capitalize">{sortBy.replace("-", " ")}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56 rounded-xl border-border/50">
                      <DropdownMenuLabel className="text-[10px] font-black uppercase tracking-widest text-muted-foreground p-3">
                        Sort by
                      </DropdownMenuLabel>
                      <DropdownMenuSeparator />
                      <DropdownMenuRadioGroup
                        value={sortBy}
                        onValueChange={setSortBy}
                        className="p-1"
                      >
                        <DropdownMenuRadioItem value="newest" className="rounded-lg font-bold p-3">
                          Newest
                        </DropdownMenuRadioItem>
                        <DropdownMenuRadioItem value="price-asc" className="rounded-lg font-bold p-3">
                          Price: Low to High
                        </DropdownMenuRadioItem>
                        <DropdownMenuRadioItem value="price-desc" className="rounded-lg font-bold p-3">
                          Price: High to Low
                        </DropdownMenuRadioItem>
                        <DropdownMenuRadioItem value="popularity" className="rounded-lg font-bold p-3">
                          Popularity
                        </DropdownMenuRadioItem>
                      </DropdownMenuRadioGroup>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                {(filterTags.length > 0 || sortBy !== "newest") && (
                  <div className="flex flex-wrap items-center gap-2">
                    {filterTags.map((t) => (
                      <Badge
                        key={t.key}
                        variant="secondary"
                        className="pl-3 pr-1 py-1 gap-1 font-semibold rounded-full"
                      >
                        <span className="max-w-[200px] truncate">{t.label}</span>
                        <button
                          type="button"
                          onClick={t.onRemove}
                          className="rounded-full p-1 hover:bg-background/80 transition-colors"
                          aria-label={`Remove ${t.label}`}
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </Badge>
                    ))}
                    {sortBy !== "newest" && (
                      <Badge
                        variant="outline"
                        className="pl-3 pr-1 py-1 gap-1 font-semibold rounded-full"
                      >
                        Sort: {sortBy.replace("-", " ")}
                        <button
                          type="button"
                          onClick={() => setSortBy("newest")}
                          className="rounded-full p-1 hover:bg-muted transition-colors"
                          aria-label="Reset sort"
                        >
                          <X className="h-3.5 w-3.5" />
                        </button>
                      </Badge>
                    )}
                    {hasActiveFilters && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="h-8 text-xs font-bold text-primary"
                        onClick={clearAllFilters}
                      >
                        Clear all filters
                      </Button>
                    )}
                  </div>
                )}
              </div>

              {isLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div
                      key={i}
                      className="aspect-[16/11] bg-muted animate-pulse rounded-[2rem]"
                    />
                  ))}
                </div>
              ) : isError ? (
                <div className="py-24 text-center rounded-[3rem] border border-destructive/20 bg-destructive/5">
                  <p className="text-muted-foreground font-medium mb-4">
                    Something went wrong while loading properties.
                  </p>
                  <Button onClick={() => window.location.reload()} className="rounded-full">
                    Retry
                  </Button>
                </div>
              ) : properties.length > 0 ? (
                resultsView === "map" ? (
                  <div className={cn("transition-opacity duration-200", isFetching && "opacity-75")}>
                    <PropertiesLiveMap
                      properties={properties}
                      userLocation={mapUserLocation}
                      onUserLocation={setMapUserLocation}
                      fitKey={mapFitKey}
                    />
                  </div>
                ) : resultsView === "split" ? (
                  <div className={cn("transition-opacity duration-200", isFetching && "opacity-75")}>
                    <PropertySplitMapExplorer properties={properties} />
                  </div>
                ) : (
                  <motion.div
                    layout
                    className={cn(
                      "grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8 transition-opacity duration-200",
                      isFetching && "opacity-75",
                    )}
                  >
                    <AnimatePresence mode="popLayout">
                      {properties.map((property, i) => (
                        <PropertyCard
                          key={property._id}
                          property={property}
                          index={i}
                        />
                      ))}
                    </AnimatePresence>
                  </motion.div>
                )
              ) : (
                <div className="py-32 text-center bg-muted/20 rounded-[3rem] border-2 border-dashed border-border/40">
                  <div className="w-20 h-20 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-6">
                    <MapPin className="w-10 h-10 text-muted-foreground/30" />
                  </div>
                  <h3 className="font-display text-2xl font-black text-foreground mb-3">
                    No properties match
                  </h3>
                  <p className="text-muted-foreground font-medium mb-8 max-w-md mx-auto">
                    Try clearing filters or broadening your search to see more listings.
                  </p>
                  <Button
                    onClick={clearAllFilters}
                    className="rounded-full px-8 h-12 font-black uppercase tracking-widest text-xs"
                  >
                    Clear all filters
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
