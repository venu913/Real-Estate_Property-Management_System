import { useState, useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import api from "@/services/api";
import { motion, AnimatePresence } from "framer-motion";
import {
  User,
  Phone,
  MapPin,
  Briefcase,
  Star,
  Home,
  Save,
  LogOut,
  Heart,
  History,
  Settings,
  ShieldCheck,
  Camera,
  Trash2,
  ChevronRight,
  Plus,
  Loader2,
  AlertCircle,
  Mail,
  Building2,
  CheckCircle2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import PropertyCard from "@/components/PropertyCard";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function Profile() {
  const {
    user,
    profile,
    roles,
    signOut,
    refreshProfile,
    loading: authLoading,
  } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState("profile");
  const [saving, setSaving] = useState(false);
  const [loadingContent, setLoadingContent] = useState(false);
  const [savedProperties, setSavedProperties] = useState([]);
  const [myListings, setMyListings] = useState([]);
  const [recentlyViewed, setRecentlyViewed] = useState([]);
  const [avatarPreview, setAvatarPreview] = useState(null);
  const fileInputRef = useRef(null);

  const [form, setForm] = useState({
    full_name: "",
    phone: "",
    bio: "",
    city: "",
    specialization: "",
    experience_years: 0,
  });

  const isAgent = roles.includes("agent");

  // Auth Guard
  useEffect(() => {
    if (!authLoading && !user) {
      navigate("/login");
    }
  }, [user, authLoading, navigate]);

  // Sync Form with Profile
  useEffect(() => {
    if (profile) {
      setForm({
        full_name: profile.full_name || "",
        phone: profile.phone || "",
        bio: profile.bio || "",
        city: profile.city || "",
        specialization: profile.specialization || "",
        experience_years: profile.experience_years || 0,
      });
    }
  }, [profile]);

  // Fetch Tab Specific Data
  useEffect(() => {
    if (activeTab === "saved") {
      fetchSavedProperties();
    } else if (activeTab === "listings") {
      fetchMyListings();
    } else if (activeTab === "recent") {
      fetchRecentlyViewed();
    }
  }, [activeTab]);

  const fetchSavedProperties = async () => {
    setLoadingContent(true);
    try {
      const res = await api.get("/auth/favorites");
      setSavedProperties(res.data);
    } catch (error) {
      console.error(error);
    } finally {
      setLoadingContent(false);
    }
  };

  const fetchMyListings = async () => {
    setLoadingContent(true);
    try {
      // Since no specific "my listings" endpoint exists in this minimal backend,
      // we'll filter from the general property list for demonstration.
      const res = await api.get("/properties");
      // MOCK: Filtering by whether the agent name matches user name
      const filtered = res.data.filter(p => 
        p.agent?.name?.toLowerCase().includes(profile?.full_name?.toLowerCase())
      );
      setMyListings(filtered);
    } catch (error) {
      console.error(error);
    } finally {
      setLoadingContent(false);
    }
  };

  const fetchRecentlyViewed = async () => {
    const ids = JSON.parse(localStorage.getItem('recentlyViewed') || '[]');
    if (ids.length === 0) {
      setRecentlyViewed([]);
      return;
    }
    
    setLoadingContent(true);
    try {
      // Fetch each property details from history
      const propertyPromises = ids.map(id => api.get(`/properties/${id}`).catch(() => null));
      const responses = await Promise.all(propertyPromises);
      setRecentlyViewed(responses.filter(r => r && r.data).map(r => r.data));
    } catch (error) {
      console.error(error);
    } finally {
      setLoadingContent(false);
    }
  };

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      await api.put("/auth/profile", form);
      await refreshProfile();
      toast({
        title: "Profile Updated",
        description: "Your digital identity has been synchronized.",
      });
    } catch (error) {
      toast({
        title: "Update Failed",
        description: error.response?.data?.message || "Something went wrong.",
        variant: "destructive",
      });
    } finally {
      setSaving(false);
    }
  };

  const handleAvatarChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAvatarPreview(reader.result);
        toast({
          title: "Avatar Preview Ready",
          description: "Don't forget to save your changes.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleLogout = async () => {
    await signOut();
    navigate("/");
  };

  const completionRate = () => {
    let fields = [form.full_name, form.phone, form.city, form.bio];
    let filled = fields.filter(f => f && f.length > 0).length;
    if (avatarPreview || profile?.avatar) filled++;
    return Math.round((filled / 5) * 100);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex flex-col items-center justify-center gap-4">
        <Loader2 className="w-10 h-10 text-primary animate-spin" />
        <p className="text-muted-foreground font-display font-medium">Validating Identity...</p>
      </div>
    );
  }

  const tabs = [
    { id: "profile", label: "Profile", icon: User },
    { id: "saved", label: "Saved Properties", icon: Heart },
    { id: "listings", label: "My Listings", icon: Home },
    { id: "recent", label: "Recently Viewed", icon: History },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#fcfcfd]">
      <Navbar />

      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4 max-w-7xl">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            
            {/* Left Sidebar */}
            <aside className="lg:col-span-3 space-y-6">
              
              {/* Premium Identity Card */}
              <div className="bg-card rounded-[2.5rem] p-8 border border-border/50 shadow-sm text-center relative overflow-hidden group">
                <div className="absolute top-0 left-0 w-full h-2 bg-gradient-hero" />
                
                <div className="relative inline-block mb-6">
                  <div className="w-28 h-28 rounded-[2rem] bg-gradient-hero flex items-center justify-center text-primary-foreground text-4xl font-black shadow-hero overflow-hidden transition-transform duration-500 group-hover:scale-105">
                    {avatarPreview ? (
                      <img src={avatarPreview} className="w-full h-full object-cover" />
                    ) : (
                      form.full_name?.charAt(0)?.toUpperCase() || "U"
                    )}
                  </div>
                  <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="absolute -bottom-2 -right-2 w-10 h-10 rounded-2xl bg-background border border-border shadow-xl flex items-center justify-center text-muted-foreground hover:text-primary transition-all hover:scale-110 active:scale-90"
                  >
                    <Camera className="w-5 h-5" />
                  </button>
                  <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={handleAvatarChange} />
                </div>
                
                <div className="mb-8">
                  <h3 className="font-display font-bold text-2xl text-foreground flex items-center justify-center gap-2 mb-1">
                    {form.full_name || "Guest Traveler"}
                    <ShieldCheck className="w-5 h-5 text-emerald-500" />
                  </h3>
                  <p className="text-xs font-bold text-muted-foreground/60 uppercase tracking-widest">{user?.email}</p>
                </div>

                <div className="space-y-4 pt-6 border-t border-border/50">
                  <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-[0.2em]">
                    <span className="text-muted-foreground">Profile Pulse</span>
                    <span className="text-primary">{completionRate()}%</span>
                  </div>
                  <Progress value={completionRate()} className="h-2 rounded-full bg-primary/10" />
                </div>
              </div>

              {/* Navigation Dashboard */}
              <nav className="bg-card rounded-[2.5rem] p-3 border border-border/50 shadow-sm space-y-1">
                {tabs.map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center justify-between p-4 rounded-3xl text-sm font-bold transition-all duration-300 ${
                      activeTab === tab.id
                        ? "bg-primary text-primary-foreground shadow-hero translate-x-1"
                        : "text-muted-foreground hover:bg-muted/50 hover:text-foreground hover:translate-x-1"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <tab.icon className={`w-5 h-5 ${activeTab === tab.id ? 'text-white' : 'text-primary/40'}`} />
                      {tab.label}
                    </div>
                    {activeTab === tab.id && <ChevronRight className="w-4 h-4" />}
                  </button>
                ))}
              </nav>

              {/* Smart Tips Context */}
              <div className="bg-emerald-500/5 rounded-[2.5rem] p-8 border border-emerald-500/10 hidden lg:block">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mb-4" />
                <h4 className="text-sm font-black text-foreground uppercase tracking-widest mb-2">Pro Visibility</h4>
                <p className="text-xs text-muted-foreground leading-relaxed font-medium">
                  Verified profiles with complete information receive <span className="text-emerald-600 font-bold">85% more engagement</span> from serious buyers.
                </p>
              </div>
            </aside>

            {/* Right Content Area */}
            <div className="lg:col-span-9 space-y-8">
              
              {/* Dynamic Stats Banner */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: "Saved Curations", value: savedProperties.length, icon: Heart, color: "bg-pink-500" },
                  { label: "Market Listings", value: myListings.length, icon: Home, color: "bg-blue-600" },
                  { label: "Recent Path", value: JSON.parse(localStorage.getItem('recentlyViewed') || '[]').length, icon: History, color: "bg-amber-500" },
                  { label: "Trust Score", value: "4.9", icon: ShieldCheck, color: "bg-emerald-600" },
                ].map((stat, i) => (
                  <div key={i} className="bg-card rounded-[2rem] p-6 border border-border/50 shadow-sm flex flex-col items-center justify-center text-center group hover:border-primary/20 transition-all">
                    <div className={`w-12 h-12 rounded-2xl ${stat.color} flex items-center justify-center text-white mb-4 shadow-lg transition-transform group-hover:scale-110`}>
                      <stat.icon className="w-6 h-6" />
                    </div>
                    <p className="text-2xl font-black text-foreground leading-none mb-1">{stat.value}</p>
                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{stat.label}</p>
                  </div>
                ))}
              </div>

              {/* Dynamic Content Panel */}
              <div className="bg-card rounded-[3rem] border border-border/50 shadow-sm overflow-hidden min-h-[650px]">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.3 }}
                    className="p-8 md:p-12"
                  >
                    {activeTab === "profile" && (
                      <div className="max-w-3xl animate-in fade-in slide-in-from-bottom-4 duration-700">
                        <div className="mb-10">
                          <h2 className="font-display text-3xl font-black text-foreground mb-2">Workspace Profile</h2>
                          <p className="text-muted-foreground font-medium">Define your professional presence on the network.</p>
                        </div>

                        <div className="grid md:grid-cols-2 gap-x-8 gap-y-10">
                          <div className="space-y-2 group">
                            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 transition-colors group-within:text-primary">Legal Identity</label>
                            <div className="relative">
                              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/40 group-within:text-primary transition-colors" />
                              <Input 
                                value={form.full_name}
                                onChange={(e) => setForm({...form, full_name: e.target.value})}
                                className="h-16 pl-14 rounded-2xl border-border/60 bg-muted/30 focus:bg-background transition-all font-bold text-base" 
                                placeholder="E.g. Alexander Pierce"
                              />
                            </div>
                          </div>

                          <div className="space-y-2 group">
                            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 group-within:text-primary">Direct Access</label>
                            <div className="relative">
                              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/40 group-within:text-primary transition-colors" />
                              <Input 
                                value={form.phone}
                                onChange={(e) => setForm({...form, phone: e.target.value})}
                                className="h-16 pl-14 rounded-2xl border-border/60 bg-muted/30 focus:bg-background transition-all font-bold text-base" 
                                placeholder="+91 XXXX XXX XXX"
                              />
                            </div>
                          </div>

                          <div className="space-y-2 group">
                            <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 group-within:text-primary">Operational Base</label>
                            <div className="relative">
                              <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/40 group-within:text-primary transition-colors" />
                              <Input 
                                value={form.city}
                                onChange={(e) => setForm({...form, city: e.target.value})}
                                className="h-16 pl-14 rounded-2xl border-border/60 bg-muted/30 focus:bg-background transition-all font-bold text-base" 
                                placeholder="E.g. Mumbai, India"
                              />
                            </div>
                          </div>

                          {isAgent && (
                             <div className="space-y-2 group">
                              <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 group-within:text-primary">Market Specialty</label>
                              <div className="relative">
                                <Briefcase className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground/40 group-within:text-primary transition-colors" />
                                <Input 
                                  value={form.specialization}
                                  onChange={(e) => setForm({...form, specialization: e.target.value})}
                                  className="h-16 pl-14 rounded-2xl border-border/60 bg-muted/30 focus:bg-background transition-all font-bold text-base" 
                                  placeholder="E.g. Luxury Penthouse"
                                />
                              </div>
                            </div>
                          )}
                        </div>

                        <div className="mt-10 space-y-2 group">
                          <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 group-within:text-primary">Professional Narrative</label>
                          <textarea 
                            value={form.bio}
                            onChange={(e) => setForm({...form, bio: e.target.value})}
                            rows={6}
                            className="w-full p-6 pb-2 rounded-[2.5rem] border border-border/60 bg-muted/30 focus:bg-background transition-all font-medium text-sm outline-none focus:ring-4 focus:ring-primary/10" 
                            placeholder="Connect with your audience by sharing your values..."
                          />
                        </div>

                        <Button 
                          onClick={handleSave}
                          disabled={saving}
                          className="mt-12 h-16 px-12 rounded-[1.5rem] bg-gradient-hero text-primary-foreground shadow-hero font-black uppercase tracking-widest text-xs active:scale-95 transition-all group"
                        >
                          {saving ? <Loader2 className="w-5 h-5 mr-3 animate-spin" /> : <Save className="w-5 h-5 mr-3 group-hover:rotate-12 transition-transform" />}
                          Sync Professional Identity
                        </Button>
                      </div>
                    )}

                    {activeTab === "saved" && (
                      <div className="space-y-10">
                        <div className="flex items-center justify-between">
                          <div>
                            <h2 className="font-display text-3xl font-black text-foreground mb-2">Saved Curations</h2>
                            <p className="text-muted-foreground font-medium">Items that caught your attention.</p>
                          </div>
                        </div>

                        {loadingContent ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {[1, 2, 3, 4].map(i => (
                              <div key={i} className="aspect-[4/3] rounded-[3rem] bg-muted animate-pulse" />
                            ))}
                          </div>
                        ) : savedProperties.length > 0 ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {savedProperties.map((p) => (
                              <div key={p._id} className="relative group overflow-hidden rounded-[2.5rem]">
                                <PropertyCard property={p} />
                                <div className="absolute top-4 right-4 z-20">
                                  <Button 
                                    onClick={(e) => {
                                      e.preventDefault();
                                      api.post(`/auth/favorites/toggle/${p._id}`).then(fetchSavedProperties);
                                      toast({ title: "Unsaved", description: p.title });
                                    }}
                                    variant="destructive" size="icon" className="w-12 h-12 rounded-2xl shadow-xl opacity-0 translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300"
                                  >
                                    <Trash2 className="w-5 h-5" />
                                  </Button>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="flex flex-col items-center justify-center py-32 text-center">
                            <div className="w-24 h-24 rounded-[2rem] bg-pink-500/5 flex items-center justify-center text-pink-500 mb-6">
                              <Heart className="w-12 h-12" />
                            </div>
                            <h3 className="text-xl font-bold mb-2">Archive Heartbeat is Silent</h3>
                            <p className="text-muted-foreground max-w-sm mx-auto mb-8 font-medium">Your curated collection starts once you favorite properties across the discovery network.</p>
                            <Button onClick={() => navigate('/properties')} className="rounded-[1.5rem] px-8 h-14 font-black uppercase tracking-widest text-xs">Start Discovering</Button>
                          </div>
                        )}
                      </div>
                    )}

                    {activeTab === "listings" && (
                      <div className="space-y-10">
                        <div className="flex items-center justify-between">
                          <div>
                            <h2 className="font-display text-3xl font-black text-foreground mb-2">Owned Assets</h2>
                            <p className="text-muted-foreground font-medium">Command center for your property portfolio.</p>
                          </div>
                          <Button className="h-14 rounded-2xl gap-2 font-black uppercase tracking-widest text-xs px-6 shadow-hero">
                            <Plus className="w-4 h-4" /> Deploy Listing
                          </Button>
                        </div>

                        {loadingContent ? (
                          <div className="space-y-6">
                             {[1, 2].map(i => (
                              <div key={i} className="h-40 rounded-[2.5rem] bg-muted animate-pulse" />
                             ))}
                          </div>
                        ) : myListings.length > 0 ? (
                          <div className="grid md:grid-cols-2 gap-8">
                            {myListings.map(p => (
                               <div key={p._id} className="relative group overflow-hidden rounded-[2.5rem]">
                                <PropertyCard property={p} />
                                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-all rounded-[2.5rem] z-20 flex flex-col items-center justify-center gap-4 backdrop-blur-md">
                                  <h4 className="text-white font-black uppercase tracking-wider text-xl mb-4">Command Control</h4>
                                  <div className="flex gap-4">
                                    <Button variant="secondary" className="rounded-xl px-8 font-black uppercase tracking-widest text-[10px]">Modify</Button>
                                    <Button variant="destructive" className="rounded-xl px-8 font-black uppercase tracking-widest text-[10px]">Retract</Button>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="flex flex-col items-center justify-center py-32 text-center border-2 border-dashed border-border/60 rounded-[3rem]">
                             <Building2 className="w-16 h-16 text-muted-foreground/20 mb-6" />
                             <h3 className="text-xl font-black mb-2">Portfolio Empty</h3>
                             <p className="text-muted-foreground max-w-sm mx-auto mb-10 font-medium">List your properties to manage sales and rentals with premium analytics.</p>
                             <Button variant="outline" className="h-14 rounded-2xl px-8 border-primary text-primary font-black uppercase tracking-widest text-xs hover:bg-primary hover:text-white transition-all">Onboard First Asset</Button>
                          </div>
                        )}
                      </div>
                    )}

                    {activeTab === "recent" && (
                      <div className="space-y-10">
                        <div>
                          <h2 className="font-display text-3xl font-black text-foreground mb-2">Journey History</h2>
                          <p className="text-muted-foreground font-medium">Digital footprints of your recent explorations.</p>
                        </div>

                        {loadingContent ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                             {[1, 2].map(i => (
                              <div key={i} className="aspect-video rounded-[2.5rem] bg-muted animate-pulse" />
                             ))}
                          </div>
                        ) : recentlyViewed.length > 0 ? (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                            {recentlyViewed.map(p => (
                               <PropertyCard key={p._id} property={p} />
                            ))}
                          </div>
                        ) : (
                          <div className="py-40 text-center bg-muted/20 rounded-[3rem]">
                            <History className="w-20 h-20 text-muted-foreground/10 mx-auto mb-6" />
                            <p className="text-muted-foreground font-display font-bold text-xl uppercase tracking-widest opacity-40">No exploration recorded</p>
                          </div>
                        )}
                      </div>
                    )}

                    {activeTab === "settings" && (
                      <div className="max-w-xl animate-in zoom-in-95 duration-500">
                        <div className="mb-12">
                          <h2 className="font-display text-3xl font-black text-foreground mb-2">System Controls</h2>
                          <p className="text-muted-foreground font-medium">Configure ecosystem access and privacy parameters.</p>
                        </div>

                        <div className="space-y-8">
                          <div className="p-10 rounded-[2.5rem] bg-muted/30 border border-border/40 shadow-sm transition-all hover:bg-muted/50">
                             <h3 className="font-display font-bold text-xl flex items-center gap-3 mb-8">
                                <ShieldCheck className="w-6 h-6 text-primary" /> Credential Rotation
                             </h3>
                             <div className="space-y-6">
                                <div className="space-y-2 group">
                                  <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest ml-1 group-within:text-primary">Target Password</label>
                                  <Input type="password" placeholder="••••••••" className="h-14 rounded-2xl bg-background border-border/40 focus:ring-4 focus:ring-primary/10 transition-all font-bold" />
                                </div>
                                <Button className="w-full h-14 rounded-2xl bg-primary/10 text-primary hover:bg-primary hover:text-white font-black uppercase tracking-widest text-[10px] transition-all">Update Access Key</Button>
                             </div>
                          </div>

                          <div className="grid gap-4">
                            <Button 
                              onClick={handleLogout}
                              variant="ghost" 
                              className="h-16 rounded-[1.5rem] justify-between px-10 border-2 border-border/20 text-foreground hover:bg-white hover:shadow-xl transition-all font-black uppercase tracking-[0.2em] text-[10px]"
                            >
                              Exit Current Session
                              <LogOut className="w-5 h-5" />
                            </Button>

                            <Button 
                              variant="ghost" 
                              className="h-16 rounded-[1.5rem] justify-between px-10 text-destructive hover:bg-destructive/5 font-black uppercase tracking-[0.2em] text-[10px]"
                            >
                              Destroy Ecosystem Profile
                              <Trash2 className="w-5 h-5" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Personalized Hook Footer */}
              <div className="rounded-[3rem] p-12 bg-gradient-hero text-white relative overflow-hidden shadow-hero">
                <div className="relative z-10 flex flex-col md:flex-row items-center gap-10 md:justify-between text-center md:text-left">
                  <div>
                    <h3 className="font-display text-4xl font-black mb-3 italic tracking-tight">Expand Your Reach</h3>
                    <p className="text-white/80 font-medium max-w-sm text-lg">Your activity helps us curate a more personalized experience. See what we've picked for you.</p>
                  </div>
                  <Button size="lg" onClick={() => navigate('/properties')} className="h-16 bg-white text-primary hover:scale-110 active:scale-95 transition-all rounded-[1.5rem] px-12 font-black uppercase tracking-widest text-sm shadow-2xl">
                    View Recommendations
                  </Button>
                </div>
                <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-white/10 rounded-full blur-3xl" />
              </div>

            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
