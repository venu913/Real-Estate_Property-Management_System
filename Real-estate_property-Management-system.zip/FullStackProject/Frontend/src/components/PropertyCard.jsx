import { motion } from "framer-motion";
import {
  Heart,
  MapPin,
  Bed,
  Bath,
  Maximize2,
  ShieldCheck,
  Zap,
  Eye,
  BarChart2,
  Scale,
} from "lucide-react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Badge } from "@/components/ui/badge";
import { useState, useEffect, forwardRef } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { toast as sonner } from "sonner";
import { useCompare } from "@/contexts/CompareContext";

const PropertyCard = forwardRef(({ property, index = 0, variant = "buyer" }, ref) => {
  const { user, profile, refreshProfile, api } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const { addProperty, hasProperty } = useCompare();
  const [liked, setLiked] = useState(false);

  if (!property) return null;

  const propertyId = property._id || property.id;

  useEffect(() => {
    if (profile?.savedProperties && propertyId) {
      setLiked(profile.savedProperties.includes(propertyId));
    }
  }, [profile, propertyId]);

  const handleToggleLike = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "Please login to save properties.",
      });
      navigate("/login", { state: { from: location.pathname } });
      return;
    }

    try {
      await api.post(`/auth/favorites/toggle/${propertyId}`);
      await refreshProfile();
      setLiked(!liked);
      toast({
        title: !liked ? "Saved to Favorites" : "Removed from Favorites",
        description: property.title,
      });
      sonner.success(!liked ? "Property saved" : "Removed from saved", {
        description: property.title,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Could not update favorites.",
        variant: "destructive",
      });
    }
  };

  const formatPrice = (amount) => {
    if (!amount && amount !== 0) return "N/A";
    if (amount >= 10000000) return `${(amount / 10000000).toFixed(2)} Cr`;
    if (amount >= 100000) return `${(amount / 100000).toFixed(2)} L`;
    return amount.toLocaleString('en-IN');
  };

  const calculateEMI = (price) => {
    if (!price) return "0";
    // Rough estimate: 0.7% of property value per month for 20 years
    const emi = (price * 0.007);
    return formatPrice(emi);
  };

  const handleCompare = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addProperty(property);
  };

  const inCompare = hasProperty(propertyId);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      className="group"
    >
      <Link to={`/property/${propertyId}`} className="block">
        <div className="relative bg-card rounded-[2rem] overflow-hidden shadow-card hover:shadow-card-hover transition-all duration-500 border border-border/40 h-full flex flex-col">
          {/* Image Sidebar */}
          <div className="relative aspect-[16/11] overflow-hidden">
            <motion.img
              src={property.images?.[0] || property.image || "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&q=80&w=800"}
              alt={property.title || "Property"}
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
            />
            
            {/* Overlays */}
            <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/60 to-transparent" />
            
            {/* Top Badges */}
            <div className="absolute top-4 left-4 flex flex-col gap-2">
              <Badge className="bg-white/90 backdrop-blur-md text-foreground border-none px-3 py-1.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider shadow-sm">
                {property.listing_type === 'rent' ? 'For Rent' : 'For Sale'}
              </Badge>
              {property.is_verified && (
                <Badge className="bg-success text-success-foreground border-none px-3 py-1.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider shadow-sm flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Verified
                </Badge>
              )}
            </div>

            {/* Favorite Toggle */}
            {variant === "buyer" && (
              <div className="absolute top-4 right-4 flex flex-col gap-2 scale-90 group-hover:scale-100 transition-transform duration-300">
                <button
                  type="button"
                  title={inCompare ? "In compare list" : "Add to compare"}
                  onClick={handleCompare}
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all shadow-md ${
                    inCompare
                      ? "bg-primary text-primary-foreground ring-2 ring-white/50"
                      : "bg-white/20 backdrop-blur-md text-white hover:bg-white hover:text-primary"
                  }`}
                >
                  <Scale className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={handleToggleLike}
                  className={`w-10 h-10 rounded-full flex items-center justify-center transition-all shadow-md ${
                    liked
                      ? "bg-destructive text-destructive-foreground"
                      : "bg-white/20 backdrop-blur-md text-white hover:bg-white hover:text-destructive"
                  }`}
                >
                  <Heart className={`w-5 h-5 ${liked ? "fill-current" : ""}`} />
                </button>
              </div>
            )}

            {variant === "agent" && (
              <div className="absolute top-4 right-4 flex flex-col items-end gap-1">
                <span className="flex items-center gap-1 rounded-full bg-black/55 text-white text-[10px] font-black uppercase tracking-wide px-2.5 py-1 backdrop-blur-md">
                  <Eye className="w-3 h-3" />
                  {(property.viewCount ?? 1240).toLocaleString("en-IN")}
                </span>
                <span className="flex items-center gap-1 rounded-full bg-primary/90 text-primary-foreground text-[10px] font-black uppercase tracking-wide px-2.5 py-1 shadow-md">
                  <BarChart2 className="w-3 h-3" />
                  {property.inquiryCount ?? 12} leads
                </span>
              </div>
            )}

            {/* Price Badge */}
            <div className="absolute bottom-4 left-4">
              <div className="flex flex-col">
                <span className="text-white/80 text-[10px] font-bold uppercase tracking-widest leading-none mb-1">Price</span>
                <span className="text-white text-2xl font-display font-black leading-none drop-shadow-md">
                  ₹{formatPrice(property.price)}
                </span>
              </div>
            </div>

            {/* Property Status/Tag */}
            {property.is_new && (
              <div className="absolute bottom-4 right-4 bg-primary text-primary-foreground px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest flex items-center gap-1 shadow-lg">
                <Zap className="w-3 h-3 fill-current" /> New Launch
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-6 flex-1 flex flex-col">
            <div className="mb-4">
              <h3 className="font-display font-bold text-foreground text-xl leading-tight mb-1.5 line-clamp-1 group-hover:text-primary transition-colors">
                {property.title || "Elite Residence"}
              </h3>
              <div className="flex items-center gap-1.5 text-muted-foreground text-xs font-semibold">
                <MapPin className="w-3.5 h-3.5 text-primary/70" />
                <span className="truncate">{property.city || "Mumbai"}, {property.state || "Maharashtra"}</span>
              </div>
            </div>

            <div className="flex items-center gap-4 py-4 border-y border-border/50 mb-4">
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1">BHK</span>
                <div className="flex items-center gap-1.5">
                  <Bed className="w-3.5 h-3.5 text-primary/60" />
                  <span className="text-sm font-bold text-foreground">{property.bedrooms || 0}</span>
                </div>
              </div>
              <div className="w-px h-8 bg-border/50" />
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1">Baths</span>
                <div className="flex items-center gap-1.5">
                  <Bath className="w-3.5 h-3.5 text-primary/60" />
                  <span className="text-sm font-bold text-foreground">{property.bathrooms || 0}</span>
                </div>
              </div>
              <div className="w-px h-8 bg-border/50" />
              <div className="flex flex-col">
                <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-1">Area</span>
                <div className="flex items-center gap-1.5">
                  <Maximize2 className="w-3.5 h-3.5 text-primary/60" />
                  <span className="text-sm font-bold text-foreground">{property.area_sqft || 0} <span className="text-[10px] font-medium text-muted-foreground">sqft</span></span>
                </div>
              </div>
            </div>

            <div className="mt-auto flex items-center justify-between">
              <div className="flex flex-col">
                <span className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-0.5">
                  {variant === "agent" ? "Performance" : "Estimated EMI"}
                </span>
                <span className="text-foreground font-bold text-sm">
                  {variant === "agent"
                    ? `${(property.viewCount ?? 1240).toLocaleString("en-IN")} views`
                    : `₹${calculateEMI(property.price)}/mo*`}
                </span>
              </div>
              <Button size="sm" variant="outline" className="rounded-full font-bold px-5 border-primary/20 hover:bg-primary/5 hover:text-primary transition-all">
                {variant === "agent" ? "Manage" : "Details"}
              </Button>
            </div>
          </div>
        </div>
      </Link>
    </motion.div>
  );
});

PropertyCard.displayName = "PropertyCard";
export default PropertyCard;
