import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Ravi Mehta",
    city: "Mumbai",
    text: "Found my dream 2BHK in Powai within just 2 weeks! The agents were super helpful and the entire process was transparent.",
    rating: 5,
  },
  {
    name: "Sunita Devi",
    city: "Bangalore",
    text: "PropNest made buying our first home so easy. The verified listings saved us from many fraudulent deals. Highly recommended!",
    rating: 5,
  },
  {
    name: "Arjun Kapoor",
    city: "Delhi",
    text: "The property comparison feature is amazing. I compared 5 flats side-by-side and made a well-informed decision.",
    rating: 4,
  },
];

export default function Testimonials() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <p className="text-primary font-semibold text-sm uppercase tracking-wider mb-2">
            Testimonials
          </p>
          <h2 className="font-display text-3xl lg:text-4xl font-bold text-foreground">
            What Our Users Say
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {testimonials.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-2xl p-7 shadow-card border border-border/50 relative"
            >
              <Quote className="w-8 h-8 text-primary/20 absolute top-5 right-5" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 text-premium fill-premium" />
                ))}
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                "{t.text}"
              </p>
              <div>
                <p className="font-display font-semibold text-card-foreground">
                  {t.name}
                </p>
                <p className="text-muted-foreground text-xs">{t.city}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
