import { useState, useCallback, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { cities } from "@/lib/data";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";
import { MapPin, Wallet, Home, ChevronRight, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const TYPES = [
  { value: "Apartment", label: "Apartment" },
  { value: "Villa", label: "Villa" },
  { value: "Plot", label: "Plot" },
];

const BUDGET_MAX = 200000000;
const BUDGET_STEP = 500000;

function formatCr(n) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(1)} Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(1)} L`;
  return `₹${n.toLocaleString("en-IN")}`;
}

export default function OnboardingWizard({ open, onOpenChange }) {
  const { completeOnboarding, skipOnboarding, recordSearchPrefs } = useBuyerActivity();
  const [step, setStep] = useState(0);
  const [city, setCity] = useState("");
  const [budget, setBudget] = useState([5000000, 50000000]);
  const [ptype, setPtype] = useState("Apartment");
  const finishedRef = useRef(false);

  const handleOpenChange = useCallback(
    (next) => {
      if (!next) {
        if (!finishedRef.current) skipOnboarding();
        finishedRef.current = false;
      }
      onOpenChange(next);
    },
    [onOpenChange, skipOnboarding],
  );

  const finish = useCallback(() => {
    finishedRef.current = true;
    completeOnboarding({
      city: city || undefined,
      budgetMin: budget[0],
      budgetMax: budget[1],
      propertyType: ptype,
    });
    recordSearchPrefs({
      city: city || undefined,
      priceMin: budget[0],
      priceMax: budget[1],
      category: ptype,
    });
    setStep(0);
    handleOpenChange(false);
  }, [city, budget, ptype, completeOnboarding, recordSearchPrefs, handleOpenChange]);

  const skip = useCallback(() => {
    setStep(0);
    handleOpenChange(false);
  }, [handleOpenChange]);

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-lg rounded-[1.75rem] border-border/60 p-0 gap-0 overflow-hidden">
        <div className="bg-gradient-to-br from-primary/15 via-background to-muted/30 p-6 pb-4 border-b border-border/40">
          <DialogHeader className="text-left space-y-1">
            <div className="flex items-center gap-2 text-primary mb-1">
              <Sparkles className="w-5 h-5" />
              <span className="text-[10px] font-black uppercase tracking-widest">Welcome</span>
            </div>
            <DialogTitle className="font-display text-2xl font-black">
              Tailor PropNest to you
            </DialogTitle>
            <DialogDescription className="text-sm font-medium">
              Three quick steps — we’ll highlight matching homes on your feed.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-1.5 mt-4">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className={cn(
                  "h-1.5 flex-1 rounded-full transition-colors duration-300",
                  i <= step ? "bg-primary" : "bg-muted-foreground/20",
                )}
              />
            ))}
          </div>
        </div>

        <div className="p-6 min-h-[280px]">
          <AnimatePresence mode="wait">
            {step === 0 && (
              <motion.div
                key="s0"
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <p className="text-xs font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <MapPin className="w-4 h-4" /> Step 1 — City
                </p>
                <div className="grid grid-cols-2 gap-2 max-h-[220px] overflow-y-auto pr-1">
                  {cities.slice(0, 12).map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setCity(c)}
                      className={cn(
                        "rounded-xl border px-3 py-2.5 text-sm font-bold transition-all active:scale-[0.98]",
                        city === c
                          ? "border-primary bg-primary/10 text-primary shadow-sm"
                          : "border-border/60 hover:border-primary/40 bg-card",
                      )}
                    >
                      {c}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
            {step === 1 && (
              <motion.div
                key="s1"
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <p className="text-xs font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <Wallet className="w-4 h-4" /> Step 2 — Budget
                </p>
                <p className="text-sm font-bold text-foreground">
                  {formatCr(budget[0])} — {formatCr(budget[1])}
                </p>
                <Slider
                  value={budget}
                  min={0}
                  max={BUDGET_MAX}
                  step={BUDGET_STEP}
                  minStepsBetweenThumbs={1}
                  onValueChange={setBudget}
                  className="py-4"
                />
              </motion.div>
            )}
            {step === 2 && (
              <motion.div
                key="s2"
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.2 }}
                className="space-y-4"
              >
                <p className="text-xs font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                  <Home className="w-4 h-4" /> Step 3 — Property type
                </p>
                <div className="flex flex-wrap gap-2">
                  {TYPES.map((t) => (
                    <button
                      key={t.value}
                      type="button"
                      onClick={() => setPtype(t.value)}
                      className={cn(
                        "rounded-xl border px-5 py-3 text-sm font-black uppercase tracking-wide transition-all active:scale-[0.98]",
                        ptype === t.value
                          ? "border-primary bg-primary text-primary-foreground shadow-md"
                          : "border-border/60 bg-card hover:border-primary/40",
                      )}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        <div className="flex items-center justify-between gap-3 p-6 pt-0 border-t border-border/40 bg-muted/10">
          <Button type="button" variant="ghost" className="text-muted-foreground font-bold" onClick={skip}>
            Skip for now
          </Button>
          <div className="flex gap-2">
            {step > 0 && (
              <Button type="button" variant="outline" className="rounded-xl font-bold" onClick={() => setStep((s) => s - 1)}>
                Back
              </Button>
            )}
            {step < 2 ? (
              <Button
                type="button"
                className="rounded-xl font-bold gap-1 bg-gradient-hero shadow-md"
                onClick={() => setStep((s) => s + 1)}
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </Button>
            ) : (
              <Button type="button" className="rounded-xl font-bold bg-gradient-hero shadow-md" onClick={finish}>
                Save & explore
              </Button>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
