import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { FlaskConical, Users, ChevronDown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

function formatRoleLabel(r) {
  if (r === "agent") return "Agent";
  if (r === "admin") return "Admin";
  if (r === "buyer") return "Buyer";
  return String(r || "").replace(/^./, (c) => c.toUpperCase());
}

/**
 * Role indicator + switch among multiple saved sessions (same tab).
 */
export default function RoleSwitcher() {
  const { user, serverRole, hasOtherSavedSessions, inactiveSessions, switchToSavedSession } =
    useAuth();
  const { toast } = useToast();

  if (!user) return null;

  return (
    <div className="fixed bottom-4 right-4 z-[100] pointer-events-auto max-w-[min(100vw-2rem,320px)]">
      <div className="rounded-2xl shadow-lg border border-border/80 bg-card/95 backdrop-blur-md px-3 py-2.5">
        <div className="flex flex-wrap items-center gap-2">
          <div className="inline-flex items-center gap-2 min-w-0">
            <FlaskConical className="w-4 h-4 text-amber-600 shrink-0" aria-hidden />
            <span className="text-xs font-bold text-muted-foreground">Role</span>
            <Badge
              variant="outline"
              className="text-[10px] h-5 px-1.5 font-mono text-foreground shrink-0"
            >
              {formatRoleLabel(serverRole)}
            </Badge>
          </div>
          {hasOtherSavedSessions && inactiveSessions.length > 0 && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  type="button"
                  variant="secondary"
                  size="sm"
                  className="h-8 text-[10px] font-bold rounded-lg gap-1 ml-auto"
                >
                  <Users className="w-3.5 h-3.5" />
                  Switch user
                  <ChevronDown className="w-3 h-3 opacity-70" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 max-h-64 overflow-y-auto">
                {inactiveSessions.map((s, i) => (
                  <DropdownMenuItem
                    key={`${s.token.slice(0, 24)}-${i}`}
                    className="text-xs font-medium cursor-pointer"
                    onClick={async () => {
                      await switchToSavedSession(s.token);
                      toast({
                        title: "Switched user",
                        description: `Active: ${s.email}`,
                      });
                    }}
                  >
                    {s.email}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>
      </div>
    </div>
  );
}
