import { useState, useMemo, useCallback, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, MessageSquareQuote, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import {
  getReviewsForProperty,
  addPropertyReview,
  reviewStats,
} from "@/lib/reviewsStorage";
import { formatDistanceToNow } from "date-fns";

function StarsDisplay({ value, className }) {
  return (
    <div className={cn("flex items-center gap-0.5", className)} aria-hidden>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={cn(
            "w-4 h-4",
            i <= value ? "fill-amber-400 text-amber-400" : "text-muted-foreground/25",
          )}
        />
      ))}
    </div>
  );
}

function StarRatingInput({ value, onChange }) {
  return (
    <div className="flex items-center gap-1" role="group" aria-label="Rating">
      {[1, 2, 3, 4, 5].map((i) => (
        <button
          key={i}
          type="button"
          onClick={() => onChange(i)}
          className="p-1 rounded-lg transition-transform hover:scale-110 active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
        >
          <Star
            className={cn(
              "w-8 h-8 transition-colors",
              i <= value ? "fill-amber-400 text-amber-400" : "text-muted-foreground/30",
            )}
          />
        </button>
      ))}
      <span className="ml-2 text-sm font-bold text-muted-foreground tabular-nums">{value}/5</span>
    </div>
  );
}

export default function PropertyReviewsSection({
  propertyId,
  listingRating,
  listingReviewCount,
  className,
}) {
  const [reviews, setReviews] = useState(() => getReviewsForProperty(propertyId));
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [author, setAuthor] = useState("");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    setReviews(getReviewsForProperty(propertyId));
  }, [propertyId]);

  const { average, count } = useMemo(() => reviewStats(reviews), [reviews]);

  const handleSubmit = useCallback(
    (e) => {
      e.preventDefault();
      if (!comment.trim()) return;
      const next = addPropertyReview(propertyId, { rating, comment, author });
      setReviews(next);
      setComment("");
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 2400);
    },
    [propertyId, rating, comment, author],
  );

  const displayAvg = count > 0 ? average : listingRating || 0;
  const displayCount = count > 0 ? count : listingReviewCount || 0;

  return (
    <section
      className={cn(
        "rounded-[2.5rem] border border-border/40 bg-card p-8 md:p-10 shadow-sm space-y-8",
        className,
      )}
    >
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-4">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
            <MessageSquareQuote className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="font-display font-bold text-xl text-foreground">Reviews</h3>
            <p className="text-sm text-muted-foreground font-medium mt-1">
              Visitor ratings are saved on this device for the demo.
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4 rounded-2xl bg-muted/50 border border-border/50 px-5 py-3">
          <div className="text-center">
            <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">
              Average
            </p>
            <p className="text-3xl font-display font-black text-primary tabular-nums leading-tight">
              {displayAvg > 0 ? displayAvg.toFixed(1) : "—"}
            </p>
          </div>
          <div className="h-10 w-px bg-border" />
          <div>
            <StarsDisplay value={Math.round(displayAvg || 0)} />
            <p className="text-xs text-muted-foreground font-semibold mt-1">
              {displayCount} rating{displayCount === 1 ? "" : "s"}
              {count === 0 && listingReviewCount > 0 && (
                <span className="block text-[10px] font-normal opacity-80">
                  Listing includes {listingReviewCount} verified notes
                </span>
              )}
            </p>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="rounded-2xl border border-border/60 bg-muted/20 p-6 space-y-4">
        <p className="text-xs font-black uppercase tracking-widest text-muted-foreground">
          Write a review
        </p>
        <div className="space-y-2">
          <Label className="text-xs font-bold">Your rating</Label>
          <StarRatingInput value={rating} onChange={setRating} />
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="rev-name" className="text-xs font-bold">
              Name (optional)
            </Label>
            <Input
              id="rev-name"
              value={author}
              onChange={(e) => setAuthor(e.target.value)}
              placeholder="e.g. Rahul"
              className="rounded-xl"
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="rev-comment" className="text-xs font-bold">
            Comment
          </Label>
          <Textarea
            id="rev-comment"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="What did you like about this listing?"
            rows={3}
            className="rounded-xl resize-none"
            required
          />
        </div>
        <Button
          type="submit"
          className="rounded-xl font-bold gap-2 bg-gradient-hero shadow-md transition-transform active:scale-[0.98]"
        >
          <Send className="w-4 h-4" />
          Post review
        </Button>
        <AnimatePresence>
          {submitted && (
            <motion.p
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="text-sm font-semibold text-success"
            >
              Thanks — your review was added.
            </motion.p>
          )}
        </AnimatePresence>
      </form>

      <div className="space-y-4">
        <h4 className="text-sm font-black uppercase tracking-widest text-muted-foreground">
          All reviews ({reviews.length})
        </h4>
        {reviews.length === 0 ? (
          <p className="text-sm text-muted-foreground font-medium py-6 text-center rounded-2xl border border-dashed border-border/60">
            No reviews yet. Be the first to share your thoughts.
          </p>
        ) : (
          <ul className="space-y-3">
            {reviews.map((r) => (
              <motion.li
                key={r.id}
                layout
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-2xl border border-border/50 bg-card p-5 shadow-sm"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <p className="font-bold text-foreground">{r.author}</p>
                  <StarsDisplay value={r.rating} />
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed font-medium">
                  {r.comment}
                </p>
                <p className="text-[11px] text-muted-foreground/80 font-semibold mt-3">
                  {formatDistanceToNow(r.createdAt, { addSuffix: true })}
                </p>
              </motion.li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
