import { useEffect, useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Users, Sparkles } from "lucide-react";
import { formatDistanceToNow } from "date-fns";
import { cn } from "@/lib/utils";

function hashToInt(str) {
  let h = 0;
  for (let i = 0; i < String(str).length; i++) h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export default function PropertyLiveBadges({ propertyId, createdAt, className }) {
  const [viewers, setViewers] = useState(3);

  const listedLabel = useMemo(() => {
    if (createdAt) {
      try {
        const d = new Date(createdAt);
        if (!Number.isNaN(d.getTime())) {
          return `Listed ${formatDistanceToNow(d, { addSuffix: true })}`;
        }
      } catch {
        /* ignore */
      }
    }
    const h = hashToInt(propertyId || "x");
    const hours = 1 + (h % 48);
    return hours < 24
      ? `Recently added ${hours} hour${hours === 1 ? "" : "s"} ago`
      : `Recently added ${Math.floor(hours / 24)} days ago`;
  }, [createdAt, propertyId]);

  useEffect(() => {
    const tick = () => {
      setViewers((v) => {
        const delta = Math.random() > 0.5 ? 1 : -1;
        const next = v + delta;
        return Math.min(12, Math.max(2, next));
      });
    };
    const id = window.setInterval(tick, 14000 + Math.random() * 9000);
    return () => window.clearInterval(id);
  }, [propertyId]);

  return (
    <div className={cn("flex flex-wrap items-center gap-2", className)}>
      <AnimatePresence mode="wait">
        <motion.div
          key={viewers}
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.96 }}
          transition={{ duration: 0.25 }}
          className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/8 px-3 py-1.5 text-xs font-bold text-foreground shadow-sm"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-60" />
            <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
          </span>
          <Users className="w-3.5 h-3.5 text-primary" />
          <span className="tabular-nums">
            {viewers} people viewing this property
          </span>
        </motion.div>
      </AnimatePresence>

      <motion.div
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-muted/40 px-3 py-1.5 text-xs font-semibold text-muted-foreground"
      >
        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
        {listedLabel}
      </motion.div>
    </div>
  );
}
