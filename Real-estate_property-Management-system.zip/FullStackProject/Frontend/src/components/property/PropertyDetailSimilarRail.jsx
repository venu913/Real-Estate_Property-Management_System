import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Layers } from "lucide-react";
import api from "@/services/api";
import { getSimilarProperties } from "@/lib/recommendationEngine";
import HorizontalRecommendationRail from "@/components/buyer/HorizontalRecommendationRail";

export default function PropertyDetailSimilarRail({ seed }) {
  const { data: pool = [], isLoading } = useQuery({
    queryKey: ["properties", "similar-rail", seed?._id || seed?.id],
    queryFn: async () => {
      const res = await api.get("/properties");
      return res.data || [];
    },
    enabled: Boolean(seed),
    staleTime: 60_000,
  });

  const items = useMemo(() => {
    if (!seed) return [];
    return getSimilarProperties(seed, pool, 14);
  }, [seed, pool]);

  if (!seed) return null;

  return (
    <HorizontalRecommendationRail
      title="Similar properties"
      subtitle="Same city & type, priced within a tight band around this listing."
      icon={Layers}
      items={items}
      loading={isLoading}
      emptyMessage="We couldn’t find close matches — try the main gallery for more options."
      hrefSeeAll="/properties"
      className="py-12 border-t border-border/40 bg-muted/10"
    />
  );
}
