import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useState, useEffect } from "react";
import { toast } from "sonner";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";
import { useNavigate } from "react-router-dom";

export default function ContactAgentDialog({
  open,
  onOpenChange,
  propertyId,
  propertyTitle,
  agentName,
  defaultName = "",
  defaultEmail = "",
  defaultPhone = "",
  onSuccess,
}) {
  const [name, setName] = useState(defaultName);
  const [email, setEmail] = useState(defaultEmail);
  const [phone, setPhone] = useState(defaultPhone);
  const [message, setMessage] = useState(
    () => `Hi, I'm interested in "${propertyTitle || "this property"}". Please share more details.`,
  );
  const [sending, setSending] = useState(false);
  const { user, isBuyer } = useAuth();
  const { addNotification } = useBuyerActivity();
  const navigate = useNavigate();

  useEffect(() => {
    if (!open) return;
    setName(defaultName);
    setEmail(defaultEmail);
    setPhone(defaultPhone);
    setMessage(`Hi, I'm interested in "${propertyTitle || "this property"}". Please share more details.`);
  }, [open, defaultName, defaultEmail, defaultPhone, propertyTitle]);

  const handleSend = async () => {
    if (!propertyId) {
      toast.error("Missing listing", { description: "Cannot send inquiry without a property." });
      return;
    }
    if (!name.trim() || !email.trim()) {
      toast.error("Name and email required");
      return;
    }
    setSending(true);
    try {
      if (user) {
        // Authenticated user creates a message thread
        await api.post("/messages/start", {
          property_id: propertyId,
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim() || undefined,
          text: message.trim() || undefined,
        });
        toast.success("Message sent", {
          description: "We've started a conversation with the agent.",
        });
        addNotification({
          title: "Inquiry Sent",
          body: `Your message regarding ${propertyTitle || "the property"} has been sent. Wait for the agent's reply to see if it's accepted.`,
        });
        if (onSuccess) onSuccess();
        onOpenChange(false);
        if (isBuyer) {
          navigate("/buyer/messages");
        }
      } else {
        // Unauthenticated generic lead
        await api.post("/leads", {
          property_id: propertyId,
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim() || undefined,
          message: message.trim() || undefined,
        });
        toast.success("Inquiry sent", {
          description: `${agentName || "The agent"} will receive your message.`,
        });
        addNotification({
          title: "Inquiry Sent",
          body: `Your inquiry for ${propertyTitle || "the property"} has been sent. Wait for the agent's reply to see if it's accepted.`,
        });
        if (onSuccess) onSuccess();
        onOpenChange(false);
      }
    } catch (err) {
      const msg = err.response?.data?.message || err.message || "Could not send inquiry.";
      toast.error("Failed to send", { description: msg });
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md rounded-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Contact agent</DialogTitle>
          <DialogDescription>
            Your inquiry goes to the listing agent for this property.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="ca-name">Your name</Label>
            <Input
              id="ca-name"
              placeholder="Full name"
              className="rounded-xl"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ca-email">Email</Label>
            <Input
              id="ca-email"
              type="email"
              placeholder="you@example.com"
              className="rounded-xl"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ca-phone">Phone</Label>
            <Input
              id="ca-phone"
              type="tel"
              placeholder="+91 …"
              className="rounded-xl"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ca-msg">Message</Label>
            <Textarea
              id="ca-msg"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={4}
              className="rounded-xl resize-none"
            />
          </div>
        </div>
        <DialogFooter className="gap-2 sm:gap-0">
          <Button variant="outline" className="rounded-xl" onClick={() => onOpenChange(false)} disabled={sending}>
            Cancel
          </Button>
          <Button className="rounded-xl bg-gradient-hero shadow-hero" onClick={handleSend} disabled={sending}>
            {sending ? "Sending…" : "Send inquiry"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
