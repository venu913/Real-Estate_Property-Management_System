import { useMemo, useEffect, useState, useCallback } from "react";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { computeEmi } from "@/lib/emi";
import { Calculator, IndianRupee, Percent, CalendarClock } from "lucide-react";

const PRICE_MIN = 500000;
const PRICE_MAX = 500000000;
const DOWN_MIN_PCT = 5;
const DOWN_MAX_PCT = 80;
const RATE_MIN = 6;
const RATE_MAX = 15;
const RATE_STEP = 0.05;
const TENURE_MIN = 5;
const TENURE_MAX = 30;

function formatInr(n) {
  if (n >= 10000000) return `₹${(n / 10000000).toFixed(2)} Cr`;
  if (n >= 100000) return `₹${(n / 100000).toFixed(2)} L`;
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

function clamp(n, a, b) {
  return Math.min(b, Math.max(a, n));
}

export default function EmiCalculator({
  propertyPrice,
  listingType = "sale",
  className,
}) {
  const safePrice = Math.max(PRICE_MIN, Math.min(PRICE_MAX, Number(propertyPrice) || PRICE_MIN));

  const [price, setPrice] = useState(safePrice);
  const [downPercent, setDownPercent] = useState(20);
  const [rateAnnual, setRateAnnual] = useState(8.5);
  const [tenureYears, setTenureYears] = useState(20);

  useEffect(() => {
    setPrice(safePrice);
  }, [safePrice]);

  const downPayment = useMemo(
    () => Math.round((price * downPercent) / 100),
    [price, downPercent],
  );

  const principal = useMemo(() => Math.max(0, price - downPayment), [price, downPayment]);

  const tenureMonths = tenureYears * 12;

  const { emi, totalInterest, totalPayment } = useMemo(
    () => computeEmi(principal, rateAnnual, tenureMonths),
    [principal, rateAnnual, tenureMonths],
  );

  const setPriceFromInput = useCallback((raw) => {
    const n = parseFloat(String(raw).replace(/,/g, ""));
    if (Number.isNaN(n)) return;
    setPrice(clamp(n, PRICE_MIN, PRICE_MAX));
  }, []);

  const setDownFromInput = useCallback((raw) => {
    const n = parseFloat(String(raw).replace(/,/g, ""));
    if (Number.isNaN(n)) return;
    const pct = price > 0 ? clamp((n / price) * 100, DOWN_MIN_PCT, DOWN_MAX_PCT) : DOWN_MIN_PCT;
    setDownPercent(Math.round(pct * 10) / 10);
  }, [price]);

  const setRateFromInput = useCallback((raw) => {
    const n = parseFloat(String(raw).replace(/,/g, ""));
    if (Number.isNaN(n)) return;
    setRateAnnual(clamp(n, RATE_MIN, RATE_MAX));
  }, []);

  const setTenureFromInput = useCallback((raw) => {
    const n = parseInt(String(raw).replace(/\D/g, ""), 10);
    if (Number.isNaN(n)) return;
    setTenureYears(clamp(n, TENURE_MIN, TENURE_MAX));
  }, []);

  return (
    <div
      className={cn(
        "rounded-[2rem] border border-border/40 bg-card p-6 md:p-8 shadow-sm space-y-6",
        className,
      )}
    >
      <div className="flex items-start gap-3">
        <div className="w-11 h-11 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0">
          <Calculator className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="font-display font-bold text-lg text-foreground">EMI calculator</h3>
          <p className="text-xs text-muted-foreground font-medium mt-0.5">
            Adjust loan terms — results update live. Indicative only; subject to bank approval.
          </p>
          {listingType === "rent" && (
            <p className="text-[11px] text-amber-700 dark:text-amber-400 font-semibold mt-2">
              This listing is for rent; EMI models a purchase at the shown price for comparison.
            </p>
          )}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-6">
        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <IndianRupee className="w-3.5 h-3.5" />
              Property price
            </Label>
            <Input
              type="text"
              inputMode="numeric"
              className="h-9 w-[140px] text-right font-bold tabular-nums rounded-xl"
              value={price.toLocaleString("en-IN")}
              onChange={(e) => setPriceFromInput(e.target.value)}
            />
          </div>
          <Slider
            value={[price]}
            min={PRICE_MIN}
            max={PRICE_MAX}
            step={100000}
            onValueChange={(v) => setPrice(v[0])}
            className="py-1"
          />
          <p className="text-[10px] text-muted-foreground font-medium">
            {formatInr(PRICE_MIN)} – {formatInr(PRICE_MAX)}
          </p>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground">
              Down payment ({downPercent}%)
            </Label>
            <Input
              type="text"
              inputMode="numeric"
              className="h-9 w-[130px] text-right font-bold tabular-nums rounded-xl"
              value={downPayment.toLocaleString("en-IN")}
              onChange={(e) => setDownFromInput(e.target.value)}
            />
          </div>
          <Slider
            value={[downPercent]}
            min={DOWN_MIN_PCT}
            max={DOWN_MAX_PCT}
            step={1}
            onValueChange={(v) => setDownPercent(v[0])}
            className="py-1"
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <Percent className="w-3.5 h-3.5" />
              Interest (p.a.)
            </Label>
            <Input
              type="text"
              inputMode="decimal"
              className="h-9 w-20 text-right font-bold tabular-nums rounded-xl"
              value={rateAnnual}
              onChange={(e) => setRateFromInput(e.target.value)}
            />
          </div>
          <Slider
            value={[rateAnnual]}
            min={RATE_MIN}
            max={RATE_MAX}
            step={RATE_STEP}
            onValueChange={(v) => setRateAnnual(v[0])}
            className="py-1"
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between gap-2">
            <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
              <CalendarClock className="w-3.5 h-3.5" />
              Tenure (years)
            </Label>
            <Input
              type="text"
              inputMode="numeric"
              className="h-9 w-16 text-right font-bold tabular-nums rounded-xl"
              value={tenureYears}
              onChange={(e) => setTenureFromInput(e.target.value)}
            />
          </div>
          <Slider
            value={[tenureYears]}
            min={TENURE_MIN}
            max={TENURE_MAX}
            step={1}
            onValueChange={(v) => setTenureYears(v[0])}
            className="py-1"
          />
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4 pt-2">
        <div className="rounded-2xl bg-gradient-to-br from-primary/12 to-primary/5 border border-primary/15 p-5">
          <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">
            Monthly EMI
          </p>
          <p className="text-2xl md:text-3xl font-display font-black text-primary tabular-nums">
            {formatInr(emi)}
          </p>
          <p className="text-[11px] text-muted-foreground font-medium mt-2">
            Loan principal {formatInr(principal)} · {tenureYears} yrs
          </p>
        </div>
        <div className="rounded-2xl bg-muted/40 border border-border/60 p-5">
          <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-1">
            Total interest
          </p>
          <p className="text-2xl md:text-3xl font-display font-black text-foreground tabular-nums">
            {formatInr(totalInterest)}
          </p>
          <p className="text-[11px] text-muted-foreground font-medium mt-2">
            Total payable {formatInr(totalPayment)} (incl. principal)
          </p>
        </div>
      </div>
    </div>
  );
}
