import { useState, useEffect } from "react";
import { format, addDays, isBefore, startOfDay } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Calendar } from "@/components/ui/calendar";
import { cn } from "@/lib/utils";
import { CalendarCheck2, ChevronLeft, Clock, Sparkles, Loader2 } from "lucide-react";
import { toast } from "sonner";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";

const TIME_SLOTS = [
  { id: "9-11",  label: "9:00 – 11:00 AM",  sub: "Morning" },
  { id: "11-1",  label: "11:00 AM – 1:00 PM", sub: "Midday" },
  { id: "2-4",   label: "2:00 – 4:00 PM",   sub: "Afternoon" },
  { id: "4-6",   label: "4:00 – 6:00 PM",   sub: "Evening" },
  { id: "6-8",   label: "6:00 – 8:00 PM",   sub: "Late" },
];

export default function ScheduleVisitDialog({
  open,
  onOpenChange,
  propertyTitle,
  propertyId,
  onSuccess,
}) {
  const { user, profile } = useAuth();
  const { addNotification } = useBuyerActivity();
  const [step, setStep] = useState("date");
  const [date, setDate] = useState(undefined);
  const [slotId, setSlotId] = useState(null);
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Guest fields (shown if not logged in)
  const [guestName, setGuestName] = useState("");
  const [guestEmail, setGuestEmail] = useState("");
  const [guestPhone, setGuestPhone] = useState("");

  useEffect(() => {
    if (!open) {
      setStep("date");
      setDate(undefined);
      setSlotId(null);
      setNote("");
      setSubmitting(false);
    }
  }, [open]);

  const today = startOfDay(new Date());
  const disabledDays = (d) => isBefore(d, today);

  const goConfirm = () => {
    if (!date || !slotId) return;
    setStep("confirm");
  };

  const finalize = async () => {
    const slot = TIME_SLOTS.find((s) => s.id === slotId);

    // Resolve buyer identity
    const name = user ? (profile?.full_name || user.email) : guestName.trim();
    const email = user ? user.email : guestEmail.trim();
    const phone = user ? (profile?.phone || "") : guestPhone.trim();

    if (!name || !email) {
      toast.error("Please fill in your name and email");
      return;
    }

    if (!propertyId) {
      // Fallback: no propertyId passed — just show success locally
      toast.success("Your visit is scheduled", {
        description: `${format(date, "PPP")} · ${slot?.label} · ${propertyTitle}`,
      });
      setStep("done");
      return;
    }

    setSubmitting(true);
    try {
      await api.post("/leads", {
        property_id: propertyId,
        name,
        email,
        phone,
        message: note || undefined,
        lead_type: "site_visit",
        visit_date: date.toISOString(),
        visit_slot: slotId,
        visit_note: note || undefined,
      });

      toast.success("Visit request sent! 📅", {
        description: `${format(date, "PPP")} · ${slot?.label} — The agent will confirm shortly.`,
      });
      addNotification({
        title: "Visit Scheduled",
        body: `Your visit for ${propertyTitle} on ${format(date, "PPP")} is pending confirmation.`,
      });
      if (onSuccess) onSuccess();
      setStep("done");
    } catch (err) {
      toast.error("Could not send visit request", {
        description: err.response?.data?.message || err.message,
      });
    } finally {
      setSubmitting(false);
    }
  };

  const slot = TIME_SLOTS.find((s) => s.id === slotId);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className={cn(
          "sm:max-w-lg rounded-2xl p-0 gap-0 overflow-hidden border-border/60",
          step === "done" && "sm:max-w-md",
        )}
      >
        {step !== "done" && (
          <DialogHeader className="p-6 pb-4 border-b border-border/50 bg-gradient-to-br from-primary/5 to-transparent">
            <div className="flex items-center gap-2 text-primary mb-2">
              <Sparkles className="w-4 h-4" />
              <span className="text-[10px] font-black uppercase tracking-[0.2em]">
                PropNest concierge
              </span>
            </div>
            <DialogTitle className="font-display text-2xl">Schedule a visit</DialogTitle>
            <DialogDescription className="text-base">{propertyTitle}</DialogDescription>
            <div className="flex gap-1.5 pt-4">
              {["date", "time", "note", "confirm"].map((key, i) => {
                const order = ["date", "time", "note", "confirm"];
                const activeIdx = order.indexOf(step);
                const filled = activeIdx >= i;
                return (
                  <div
                    key={key}
                    className={cn(
                      "h-1 flex-1 rounded-full transition-colors",
                      filled ? "bg-primary" : "bg-muted",
                    )}
                  />
                );
              })}
            </div>
          </DialogHeader>
        )}

        <div className="p-6">
          {/* STEP 1 – Date */}
          {step === "date" && (
            <div className="space-y-4">
              <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground">
                Pick a date
              </Label>
              <Calendar
                mode="single"
                selected={date}
                onSelect={setDate}
                disabled={disabledDays}
                fromDate={today}
                toDate={addDays(today, 60)}
                className="rounded-xl border border-border/50 p-2 mx-auto"
              />
              <Button
                className="w-full rounded-xl h-12 font-bold bg-gradient-hero shadow-hero"
                disabled={!date}
                onClick={() => setStep("time")}
              >
                Continue
              </Button>
            </div>
          )}

          {/* STEP 2 – Time slot */}
          {step === "time" && (
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => setStep("date")}
                className="flex items-center gap-1 text-xs font-bold text-muted-foreground hover:text-foreground"
              >
                <ChevronLeft className="w-4 h-4" /> Back
              </button>
              <Label className="text-xs font-black uppercase tracking-widest text-muted-foreground flex items-center gap-2">
                <Clock className="w-4 h-4" /> Available slots
              </Label>
              <p className="text-sm text-muted-foreground">
                {date ? format(date, "EEEE, MMM d") : "Select a day first"}
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {TIME_SLOTS.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => setSlotId(s.id)}
                    className={cn(
                      "rounded-xl border-2 p-4 text-left transition-all hover:border-primary/50",
                      slotId === s.id
                        ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                        : "border-border/60 bg-card",
                    )}
                  >
                    <p className="font-bold text-sm text-foreground">{s.label}</p>
                    <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wide mt-1">
                      {s.sub}
                    </p>
                  </button>
                ))}
              </div>
              <Button
                className="w-full rounded-xl h-12 font-bold bg-gradient-hero shadow-hero"
                disabled={!slotId}
                onClick={() => setStep("note")}
              >
                Next
              </Button>
            </div>
          )}

          {/* STEP 3 – Note + guest info if not logged in */}
          {step === "note" && (
            <div className="space-y-4">
              <button
                type="button"
                onClick={() => setStep("time")}
                className="flex items-center gap-1 text-xs font-bold text-muted-foreground hover:text-foreground"
              >
                <ChevronLeft className="w-4 h-4" /> Back
              </button>

              {!user && (
                <div className="space-y-3 pb-2 border-b border-border/40">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Your details</p>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs">Name *</Label>
                      <Input value={guestName} onChange={e => setGuestName(e.target.value)} placeholder="Full name" className="rounded-xl mt-1" />
                    </div>
                    <div>
                      <Label className="text-xs">Phone</Label>
                      <Input value={guestPhone} onChange={e => setGuestPhone(e.target.value)} placeholder="+91 ..." className="rounded-xl mt-1" />
                    </div>
                  </div>
                  <div>
                    <Label className="text-xs">Email *</Label>
                    <Input value={guestEmail} onChange={e => setGuestEmail(e.target.value)} placeholder="you@example.com" type="email" className="rounded-xl mt-1" />
                  </div>
                </div>
              )}

              <Label htmlFor="visit-note">Note for the agent (optional)</Label>
              <Textarea
                id="visit-note"
                rows={3}
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Parking, gate code, preferred tower…"
                className="rounded-xl resize-none"
              />
              <Button
                className="w-full rounded-xl h-12 font-bold bg-gradient-hero shadow-hero"
                onClick={goConfirm}
              >
                Review request
              </Button>
            </div>
          )}

          {/* STEP 4 – Confirm */}
          {step === "confirm" && date && (
            <div className="space-y-5">
              <button
                type="button"
                onClick={() => setStep("note")}
                className="flex items-center gap-1 text-xs font-bold text-muted-foreground hover:text-foreground"
              >
                <ChevronLeft className="w-4 h-4" /> Back
              </button>
              <div className="rounded-2xl border border-border/60 bg-muted/30 p-5 space-y-3 text-sm">
                <p>
                  <span className="font-black text-muted-foreground text-[10px] uppercase tracking-widest block mb-1">When</span>
                  <span className="font-bold text-foreground">{format(date, "PPP")}</span>
                </p>
                <p>
                  <span className="font-black text-muted-foreground text-[10px] uppercase tracking-widest block mb-1">Slot</span>
                  <span className="font-bold text-foreground">{slot?.label}</span>
                </p>
                {note.trim() && (
                  <p>
                    <span className="font-black text-muted-foreground text-[10px] uppercase tracking-widest block mb-1">Note</span>
                    <span className="text-muted-foreground">{note}</span>
                  </p>
                )}
                {!user && guestName && (
                  <p>
                    <span className="font-black text-muted-foreground text-[10px] uppercase tracking-widest block mb-1">Your name</span>
                    <span className="text-foreground font-bold">{guestName} · {guestEmail}</span>
                  </p>
                )}
              </div>
              <Button
                className="w-full rounded-xl h-12 font-bold bg-gradient-hero shadow-hero"
                onClick={finalize}
                disabled={submitting}
              >
                {submitting ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Sending…</>
                ) : (
                  "Confirm visit request"
                )}
              </Button>
            </div>
          )}
        </div>

        {/* DONE state */}
        {step === "done" && (
          <div className="p-10 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/15 text-emerald-600 flex items-center justify-center mx-auto animate-in zoom-in duration-300">
              <CalendarCheck2 className="w-8 h-8" />
            </div>
            <h3 className="font-display text-2xl font-black text-foreground">
              Visit request sent!
            </h3>
            <p className="text-muted-foreground text-sm font-medium leading-relaxed">
              We've logged your request for{" "}
              <span className="text-foreground font-bold">{date ? format(date, "PPP") : ""}</span>{" "}
              during{" "}
              <span className="text-foreground font-bold">{slot?.label}</span>.{" "}
              The agent will confirm or suggest a new time shortly.
            </p>
            <Button
              className="rounded-xl font-bold mt-4"
              onClick={() => onOpenChange(false)}
            >
              Done
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
