import { Link } from "react-router-dom";
import {
  Building2,
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  ArrowRight,
  ShieldCheck,
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="relative bg-[#0A0A0B] text-white pt-24 pb-12 overflow-hidden border-t border-white/5">
      {/* Top Gradient Indicator */}
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary/50 to-transparent" />
      
      {/* Decorative Blur */}
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-primary/5 rounded-full blur-[100px] -translate-x-1/2 translate-y-1/2" />

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 mb-20">
          
          {/* Brand Column */}
          <div className="lg:col-span-3 max-w-sm">
            <Link to="/" className="flex items-center gap-2.5 mb-8">
              <div className="w-12 h-12 rounded-2xl bg-gradient-hero flex items-center justify-center shadow-hero">
                <Building2 className="w-6 h-6 text-white" />
              </div>
              <span className="font-display text-2xl font-black tracking-tight">PropNest<span className="text-primary italic">.</span></span>
            </Link>
            <p className="text-white/40 text-base leading-relaxed mb-8 font-medium">
              Redefining the luxury real estate experience in India. Founded on transparency, 
              curation, and the relentless pursuit of architectural excellence.
            </p>
            <div className="flex gap-4">
              {[Instagram, Linkedin, Twitter, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-11 h-11 rounded-xl bg-white/5 flex items-center justify-center hover:bg-primary hover:text-white transition-all border border-white/5"
                >
                  <Icon className="w-4 h-4" />
                </a>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          <div className="lg:col-span-2">
            <h4 className="font-display font-black text-xs uppercase tracking-[0.2em] mb-8 text-white/50">Company</h4>
            <ul className="space-y-4">
              {[
                { to: "/about", label: "About PropNest" },
                { to: "/contact", label: "Contact & support" },
                { to: "/properties", label: "Browse properties" },
                { to: "/login", label: "Sign in" },
              ].map((item) => (
                <li key={item.to}>
                  <Link
                    to={item.to}
                    className="text-white/40 hover:text-primary transition-all text-sm font-bold flex items-center group"
                  >
                    <ArrowRight className="w-3 h-3 mr-0 opacity-0 group-hover:mr-2 group-hover:opacity-100 transition-all" />
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-2">
            <h4 className="font-display font-black text-xs uppercase tracking-[0.2em] mb-8 text-white/50">Collections</h4>
            <ul className="space-y-4">
              {["Exclusive Villas", "Luxury Penthouses", "Office Estates", "New Launches"].map((item) => (
                <li key={item}>
                  <Link to="/properties" className="text-white/40 hover:text-primary transition-all text-sm font-bold flex items-center group">
                    <ArrowRight className="w-3 h-3 mr-0 opacity-0 group-hover:mr-2 group-hover:opacity-100 transition-all" />
                    {item}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-2">
            <h4 className="font-display font-black text-xs uppercase tracking-[0.2em] mb-8 text-white/50">Elite Hubs</h4>
            <ul className="space-y-4">
              {["Mumbai", "Delhi NCR", "Bangalore", "Hyderabad"].map((city) => (
                <li key={city}>
                  <Link to="/properties" className="text-white/40 hover:text-primary transition-all text-sm font-bold flex items-center group">
                    <ArrowRight className="w-3 h-3 mr-0 opacity-0 group-hover:mr-2 group-hover:opacity-100 transition-all" />
                    {city}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter Column */}
          <div className="lg:col-span-3">
            <h4 className="font-display font-black text-xs uppercase tracking-[0.2em] mb-8 text-white/50">Newsletter</h4>
            <p className="text-white/40 text-sm font-medium mb-6">
              Subscribe to receive weekly curators' picks of the finest properties.
            </p>
            <div className="relative group">
              <input 
                type="email" 
                placeholder="Ex. elite@lifestyle.com" 
                className="w-full h-14 bg-white/5 border border-white/10 rounded-2xl px-6 text-sm text-white focus:outline-none focus:ring-4 ring-primary/10 focus:border-primary/50 transition-all"
              />
              <button className="absolute right-2 top-2 bottom-2 px-5 bg-gradient-hero rounded-xl flex items-center justify-center hover:scale-[1.02] active:scale-95 transition-all">
                <ArrowRight className="w-5 h-5 text-white" />
              </button>
            </div>
            <div className="mt-4 flex items-center gap-2 text-white/30 text-[10px] font-bold uppercase tracking-widest">
              <ShieldCheck className="w-4 h-4 text-success" /> Verified & Secure Communication
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-col md:flex-row items-center gap-2 md:gap-8">
            <p className="text-white/20 text-xs font-bold uppercase tracking-widest">
              © 2026 PROPNEST REALTY. ALL RIGHTS RESERVED.
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-white/20 hover:text-white transition-colors text-[10px] font-black uppercase tracking-widest">Privacy Policy</a>
              <a href="#" className="text-white/20 hover:text-white transition-colors text-[10px] font-black uppercase tracking-widest">Legal Terms</a>
            </div>
          </div>
          
          <div className="flex items-center gap-6">
             <div className="flex items-center gap-2 text-white/30 text-[10px] font-bold">
               <Phone className="w-3 h-3 text-primary" /> +91 1800 200 400
             </div>
             <div className="flex items-center gap-2 text-white/30 text-[10px] font-bold">
               <Mail className="w-3 h-3 text-primary" /> HELLO@PROPNEST.RE
             </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
