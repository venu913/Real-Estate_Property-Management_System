import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

const propertyTypes = [
  "apartment",
  "villa",
  "house",
  "plot",
  "commercial",
  "farmhouse",
  "penthouse",
];
const listingTypes = ["sale", "rent"];
const furnishingTypes = ["unfurnished", "semi-furnished", "fully-furnished"];
const cities = [
  "Mumbai",
  "Delhi",
  "Bangalore",
  "Hyderabad",
  "Chennai",
  "Kolkata",
  "Pune",
  "Ahmedabad",
  "Jaipur",
  "Lucknow",
  "Goa",
  "Chandigarh",
  "Noida",
  "Gurgaon",
  "Kochi",
];

export default function PropertyFormDialog({
  open,
  onOpenChange,
  property,
  onSaved,
}) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    title: "",
    description: "",
    property_type: "apartment",
    listing_type: "sale",
    price: "",
    area_sqft: "",
    bedrooms: "2",
    bathrooms: "2",
    furnishing: "unfurnished",
    address: "",
    city: "",
    state: "",
    pincode: "",
    images: "",
  });

  useEffect(() => {
    if (property) {
      setForm({
        title: property.title || "",
        description: property.description || "",
        property_type: property.property_type || "apartment",
        listing_type: property.listing_type || "sale",
        price: property.price?.toString() || "",
        area_sqft: property.area_sqft?.toString() || "",
        bedrooms: property.bedrooms?.toString() || "2",
        bathrooms: property.bathrooms?.toString() || "2",
        furnishing: property.furnishing || "unfurnished",
        address: property.address || "",
        city: property.city || "",
        state: property.state || "",
        pincode: property.pincode || "",
        images: property.images?.join(", ") || "",
      });
    } else {
      setForm({
        title: "",
        description: "",
        property_type: "apartment",
        listing_type: "sale",
        price: "",
        area_sqft: "",
        bedrooms: "2",
        bathrooms: "2",
        furnishing: "unfurnished",
        address: "",
        city: "",
        state: "",
        pincode: "",
        images: "",
      });
    }
  }, [property, open]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);

    const payload = {
      agent_id: user.id,
      title: form.title.trim(),
      description: form.description.trim(),
      property_type: form.property_type,
      listing_type: form.listing_type,
      price: parseFloat(form.price) || 0,
      area_sqft: parseFloat(form.area_sqft) || null,
      bedrooms: parseInt(form.bedrooms) || 0,
      bathrooms: parseInt(form.bathrooms) || 0,
      furnishing: form.furnishing,
      address: form.address.trim(),
      city: form.city,
      state: form.state.trim(),
      pincode: form.pincode.trim(),
      images: form.images
        ? form.images
            .split(",")
            .map((s) => s.trim())
            .filter(Boolean)
        : [],
    };

    try {
      if (property) {
        await api.patch(`/agent/properties/${property._id}`, payload);
      } else {
        await api.post("/agent/properties", payload);
      }
      toast({ title: property ? "Property Updated" : "Property Created" });
      onSaved();
    } catch (error) {
      toast({
        title: "Error",
        description: error.response?.data?.message || error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const selectClasses =
    "h-10 w-full rounded-md border border-input bg-background px-3 text-sm focus:ring-2 focus:ring-ring focus:ring-offset-2 outline-none";

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display">
            {property ? "Edit Property" : "Add New Property"}
          </DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-sm font-medium text-foreground">
              Title *
            </label>
            <Input
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="3 BHK Luxury Apartment in Bandra"
              required
            />
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              Description
            </label>
            <Textarea
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
              placeholder="Describe your property..."
              rows={3}
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-sm font-medium text-foreground">
                Type
              </label>
              <select
                className={selectClasses}
                value={form.property_type}
                onChange={(e) =>
                  setForm({ ...form, property_type: e.target.value })
                }
              >
                {propertyTypes.map((t) => (
                  <option key={t} value={t}>
                    {t.charAt(0).toUpperCase() + t.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">
                Listing
              </label>
              <select
                className={selectClasses}
                value={form.listing_type}
                onChange={(e) =>
                  setForm({ ...form, listing_type: e.target.value })
                }
              >
                {listingTypes.map((t) => (
                  <option key={t} value={t}>
                    {t.charAt(0).toUpperCase() + t.slice(1)}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">
                Furnishing
              </label>
              <select
                className={selectClasses}
                value={form.furnishing}
                onChange={(e) =>
                  setForm({ ...form, furnishing: e.target.value })
                }
              >
                {furnishingTypes.map((t) => (
                  <option key={t} value={t}>
                    {t
                      .split("-")
                      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
                      .join(" ")}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div>
              <label className="text-sm font-medium text-foreground">
                Price (₹) *
              </label>
              <Input
                type="number"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                placeholder="5000000"
                required
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">
                Area (sqft)
              </label>
              <Input
                type="number"
                value={form.area_sqft}
                onChange={(e) =>
                  setForm({ ...form, area_sqft: e.target.value })
                }
                placeholder="1200"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">
                Bedrooms
              </label>
              <Input
                type="number"
                value={form.bedrooms}
                onChange={(e) => setForm({ ...form, bedrooms: e.target.value })}
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">
                Bathrooms
              </label>
              <Input
                type="number"
                value={form.bathrooms}
                onChange={(e) =>
                  setForm({ ...form, bathrooms: e.target.value })
                }
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium text-foreground">
                City
              </label>
              <select
                className={selectClasses}
                value={form.city}
                onChange={(e) => setForm({ ...form, city: e.target.value })}
              >
                <option value="">Select City</option>
                {cities.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">
                State
              </label>
              <Input
                value={form.state}
                onChange={(e) => setForm({ ...form, state: e.target.value })}
                placeholder="Maharashtra"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-sm font-medium text-foreground">
                Address
              </label>
              <Input
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                placeholder="Full address"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-foreground">
                Pincode
              </label>
              <Input
                value={form.pincode}
                onChange={(e) => setForm({ ...form, pincode: e.target.value })}
                placeholder="400001"
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-foreground">
              Image URLs (comma-separated)
            </label>
            <Input
              value={form.images}
              onChange={(e) => setForm({ ...form, images: e.target.value })}
              placeholder="https://example.com/img1.jpg, https://example.com/img2.jpg"
            />
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="bg-gradient-hero text-primary-foreground shadow-hero"
            >
              {loading
                ? "Saving..."
                : property
                  ? "Update Property"
                  : "Create Property"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
