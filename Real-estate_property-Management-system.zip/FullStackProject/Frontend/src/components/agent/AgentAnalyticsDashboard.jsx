import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  BarChart,
  Bar,
  Legend,
} from "recharts";
import {
  Eye,
  Bookmark,
  MessageCircle,
  Building,
  TrendingUp,
  Rocket,
  Plus,
  RefreshCw,
} from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";

/* ── Stat card ─────────────────────────────────────────────────── */
function StatCard({ icon: Icon, label, value, sub, color = "text-primary", bgColor = "bg-primary/10" }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl border border-border/60 bg-card p-6 shadow-sm relative overflow-hidden"
    >
      <div className="absolute top-0 right-0 w-24 h-24 bg-primary/5 rounded-full -translate-y-8 translate-x-8" />
      <div className="relative flex items-start gap-4">
        <div className={cn("w-12 h-12 rounded-xl flex items-center justify-center shrink-0", bgColor)}>
          <Icon className={cn("w-6 h-6", color)} />
        </div>
        <div>
          <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{label}</p>
          <p className="text-3xl font-display font-black text-foreground tabular-nums mt-1">
            {typeof value === "number" ? value.toLocaleString("en-IN") : value}
          </p>
          {sub && <p className="text-xs text-muted-foreground font-medium mt-1">{sub}</p>}
        </div>
      </div>
    </motion.div>
  );
}

/* ── Empty chart overlay ────────────────────────────────────────── */
function EmptyChartOverlay() {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-card/80 backdrop-blur-[2px] rounded-xl z-10">
      <div className="w-14 h-14 rounded-2xl bg-muted flex items-center justify-center">
        <TrendingUp className="w-7 h-7 text-muted-foreground/40" />
      </div>
      <p className="text-sm font-bold text-muted-foreground">No data yet</p>
      <p className="text-xs text-muted-foreground/60 text-center max-w-[200px]">
        Data will appear here once you upload properties and receive leads.
      </p>
    </div>
  );
}

/* ── Main component ─────────────────────────────────────────────── */
export default function AgentAnalyticsDashboard() {
  const { user } = useAuth();
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState(false);

  const fetchAnalytics = async () => {
    setLoading(true);
    setError(false);
    try {
      const res = await api.get("/agent/analytics");
      setData(res.data);
    } catch (err) {
      console.error("Analytics fetch failed:", err);
      setError(true);
      // Real zeros — no fake data
      setData({
        totals: { views: 0, saves: 0, inquiries: 0, properties: 0 },
        propertyPerf: [],
        weekSeries: Array.from({ length: 8 }, (_, i) => ({ week: `W${i + 1}`, inquiries: 0 })),
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) fetchAnalytics();
  }, [user]);

  const isEmpty = !loading && data && data.totals.properties === 0;
  const hasNoLeads = !loading && data && data.totals.inquiries === 0;
  const hasNoPropPerf = !loading && data && data.propertyPerf.length === 0;

  /* ── Skeleton ── */
  if (loading) {
    return (
      <div className="space-y-8 p-4 md:p-8 max-w-6xl mx-auto animate-pulse">
        <div className="h-10 w-48 bg-muted rounded-xl" />
        <div className="grid sm:grid-cols-4 gap-4">
          {[1,2,3,4].map(i => <div key={i} className="h-28 bg-muted rounded-2xl" />)}
        </div>
        <div className="grid lg:grid-cols-5 gap-6">
          <div className="lg:col-span-3 h-72 bg-muted rounded-2xl" />
          <div className="lg:col-span-2 h-72 bg-muted rounded-2xl" />
        </div>
        <div className="h-80 bg-muted rounded-2xl" />
      </div>
    );
  }

  const { totals, propertyPerf, weekSeries } = data;

  /* ── Computed quick-pulse values ─────────────────────── */
  const bestWeek = weekSeries.reduce((max, w) => w.inquiries > max ? w.inquiries : max, 0);
  const inquiryRate = totals.views > 0
    ? ((totals.inquiries / totals.views) * 100).toFixed(1) + "%"
    : "—";
  const savesPerHundred = totals.views > 0
    ? ((totals.saves / totals.views) * 100).toFixed(1)
    : "—";

  return (
    <div className="space-y-8 p-4 md:p-8 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="font-display text-3xl font-black text-foreground tracking-tight">Analytics</h1>
          <p className="text-sm text-muted-foreground font-medium mt-1">
            {isEmpty
              ? "Upload your first property to start tracking performance."
              : "Real-time performance based on your listings and leads."}
          </p>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="rounded-xl font-bold border-border/60"
          onClick={fetchAnalytics}
        >
          <RefreshCw className="w-4 h-4 mr-2" /> Refresh
        </Button>
      </div>

      {/* ── Empty CTA ── */}
      {isEmpty && (
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-[2rem] border-2 border-dashed border-primary/30 bg-gradient-to-br from-primary/5 via-background to-purple-500/5 p-10 text-center"
        >
          <div className="absolute -top-12 -right-12 w-40 h-40 rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute -bottom-12 -left-12 w-40 h-40 rounded-full bg-purple-500/10 blur-3xl" />
          <div className="relative z-10 flex flex-col items-center gap-5 max-w-md mx-auto">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-2xl shadow-primary/30">
              <Rocket className="w-10 h-10 text-white" />
            </div>
            <div>
              <h2 className="font-display text-xl font-black text-foreground mb-1">No data to show yet</h2>
              <p className="text-muted-foreground font-medium text-sm leading-relaxed">
                Your analytics will populate automatically as you add properties
                and receive inquiries from buyers.
              </p>
            </div>
            <Button asChild className="rounded-xl bg-gradient-to-r from-primary to-purple-600 text-white font-bold px-8 shadow-lg">
              <Link to="/agent/add-property">
                <Plus className="w-4 h-4 mr-2" /> Add Your First Property
              </Link>
            </Button>
          </div>
        </motion.div>
      )}

      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          icon={Building}
          label="Properties"
          value={totals.properties}
          sub="Total listings"
          color="text-blue-500"
          bgColor="bg-blue-500/10"
        />
        <StatCard
          icon={Eye}
          label="Total Views"
          value={totals.views}
          sub="Across all listings"
          color="text-primary"
          bgColor="bg-primary/10"
        />
        <StatCard
          icon={Bookmark}
          label="Saves"
          value={totals.saves}
          sub="Buyers saved your listings"
          color="text-emerald-500"
          bgColor="bg-emerald-500/10"
        />
        <StatCard
          icon={MessageCircle}
          label="Inquiries"
          value={totals.inquiries}
          sub="Total leads received"
          color="text-amber-500"
          bgColor="bg-amber-500/10"
        />
      </div>

      {/* ── Line chart + Quick Pulse ── */}
      <div className="grid lg:grid-cols-5 gap-6">
        {/* Lead trend chart */}
        <div className="lg:col-span-3 rounded-2xl border border-border/60 bg-card p-6 shadow-sm">
          <div className="flex items-center gap-2 mb-6">
            <TrendingUp className="w-5 h-5 text-primary" />
            <h2 className="font-display font-bold text-lg text-foreground">Leads over time</h2>
            <span className="ml-auto text-xs text-muted-foreground font-medium">Last 8 weeks</span>
          </div>
          <div className="relative h-[260px] w-full">
            {hasNoLeads && <EmptyChartOverlay />}
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weekSeries} margin={{ top: 8, right: 8, left: -8, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-border/60" />
                <XAxis dataKey="week" tick={{ fontSize: 11, fontWeight: 600 }} />
                <YAxis tick={{ fontSize: 11 }} width={36} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    borderRadius: 12,
                    border: "1px solid hsl(var(--border))",
                    background: "hsl(var(--card))",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="inquiries"
                  name="Inquiries"
                  stroke="hsl(var(--primary))"
                  strokeWidth={3}
                  dot={{ r: 4, fill: "hsl(var(--primary))" }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Pulse */}
        <div className="lg:col-span-2 rounded-2xl border border-border/60 bg-card p-6 shadow-sm flex flex-col">
          <h2 className="font-display font-bold text-lg text-foreground mb-1">Quick Pulse</h2>
          <p className="text-xs text-muted-foreground font-medium mb-5">
            {isEmpty
              ? "Stats will appear once you have active listings."
              : "Key ratios based on your real listing data."}
          </p>
          <ul className="space-y-3 text-sm flex-1">
            {[
              {
                label: "Best week (leads)",
                value: bestWeek > 0 ? `${bestWeek} leads` : "—",
              },
              {
                label: "Saves per 100 views",
                value: savesPerHundred,
              },
              {
                label: "Inquiry rate",
                value: inquiryRate,
                highlight: totals.inquiries > 0,
              },
              {
                label: "Active properties",
                value: totals.properties > 0 ? `${totals.properties} listings` : "—",
              },
            ].map(({ label, value, highlight }) => (
              <li key={label} className="flex justify-between gap-2 py-2 border-b border-border/40 last:border-0">
                <span className="text-muted-foreground font-medium">{label}</span>
                <span className={cn("font-bold tabular-nums", highlight && "text-primary")}>{value}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* ── Property Performance Bar Chart ── */}
      <div className="rounded-2xl border border-border/60 bg-card p-6 shadow-sm">
        <h2 className="font-display font-bold text-lg text-foreground mb-1">Property Performance</h2>
        <p className="text-xs text-muted-foreground font-medium mb-6">
          Views, saves and inquiries per listing (top 8 by views).
        </p>
        <div className="relative h-[320px] w-full">
          {hasNoPropPerf && <EmptyChartOverlay />}
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={hasNoPropPerf ? [{ name: "—", views: 0, saves: 0, inquiries: 0 }] : propertyPerf}
              margin={{ top: 8, right: 8, left: -8, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" className="stroke-border/60" />
              <XAxis
                dataKey="name"
                tick={{ fontSize: 10, fontWeight: 600 }}
                interval={0}
                angle={-12}
                textAnchor="end"
                height={56}
              />
              <YAxis tick={{ fontSize: 11 }} width={44} allowDecimals={false} />
              <Tooltip
                contentStyle={{
                  borderRadius: 12,
                  border: "1px solid hsl(var(--border))",
                  background: "hsl(var(--card))",
                }}
              />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="views"     name="Views"     fill="hsl(var(--primary))"  radius={[6, 6, 0, 0]} />
              <Bar dataKey="saves"     name="Saves"     fill="hsl(160 60% 40%)"     radius={[6, 6, 0, 0]} />
              <Bar dataKey="inquiries" name="Inquiries" fill="hsl(38 92% 50%)"      radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
