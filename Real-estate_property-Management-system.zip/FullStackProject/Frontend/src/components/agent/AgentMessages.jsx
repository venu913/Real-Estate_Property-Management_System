import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import {
  MessageSquare,
  Send,
  Phone,
  MapPin,
  User,
  Search,
} from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import { toTelHref } from "@/lib/phone";

export default function AgentMessages() {
  const { user } = useAuth();
  const [threads, setThreads] = useState([]);
  const [activeId, setActiveId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [query, setQuery] = useState("");
  const [draft, setDraft] = useState("");
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef(null);

  useEffect(() => {
    fetchThreads();
  }, [user]);

  useEffect(() => {
    if (activeId) {
      fetchMessages(activeId);
    }
  }, [activeId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const fetchThreads = async () => {
    try {
      const { data } = await api.get('/messages/threads');
      setThreads(data);
      if (data.length > 0 && !activeId) {
        setActiveId(data[0].threadId);
      }
    } catch (err) {
      console.error(err);
      toast.error("Failed to load leads");
    } finally {
      setLoading(false);
    }
  };

  const fetchMessages = async (leadId) => {
    try {
      const { data } = await api.get(`/messages/thread/${leadId}`);
      setMessages(data);
      setThreads(prev => prev.map(t => 
        t.threadId === leadId ? { ...t, unread: 0 } : t
      ));
    } catch (err) {
      console.error(err);
      toast.error("Could not load messages");
    }
  };

  const handleSend = async () => {
    if (!draft.trim() || !activeId) return;
    const text = draft;
    setDraft("");
    
    // Optimistic UI update
    const optimisticMsg = {
      _id: "temp-" + Date.now(),
      sender_id: user.id || user._id,
      sender_role: "agent",
      text: text.trim(),
      createdAt: new Date().toISOString(),
    };
    setMessages(prev => [...prev, optimisticMsg]);
    
    try {
      const { data } = await api.post(`/messages/thread/${activeId}`, { text });
      setMessages(prev => prev.map(m => m._id === optimisticMsg._id ? data : m));
      setThreads(prev => prev.map(t => 
        t.threadId === activeId ? { ...t, lastMessage: data.text, lastAt: data.createdAt } : t
      ).sort((a,b) => new Date(b.lastAt) - new Date(a.lastAt)));
    } catch (err) {
      console.error(err);
      toast.error("Failed to send reply");
      setDraft(text);
      setMessages(prev => prev.filter(m => m._id !== optimisticMsg._id));
    }
  };

  const active = threads.find((t) => t.threadId === activeId);
  const filtered = threads.filter(
    (t) =>
      (t.leadName || "").toLowerCase().includes(query.toLowerCase()) ||
      (t.propertyTitle || "").toLowerCase().includes(query.toLowerCase()),
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 md:gap-6 min-h-[calc(100vh-8rem)]">
      <Card className="lg:col-span-4 border-border/80 shadow-sm flex flex-col overflow-hidden max-h-[700px]">
        <CardHeader className="pb-3 space-y-3 border-b border-border/60">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-primary" />
            <h2 className="font-display font-bold text-lg">Inbox</h2>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search leads…"
              className="pl-9 h-10 rounded-xl bg-muted/40"
            />
          </div>
        </CardHeader>
        <CardContent className="p-0 flex-1 min-h-[280px]">
          <ScrollArea className="h-[420px] lg:h-[calc(100vh-14rem)]">
            <div className="flex flex-col">
              {loading && <div className="p-4 text-center text-muted-foreground text-sm">Loading leads...</div>}
              {!loading && filtered.length === 0 && (
                <div className="p-10 text-center flex flex-col items-center">
                  <MessageSquare className="w-10 h-10 text-muted-foreground/30 mb-3" />
                  <p className="text-sm text-muted-foreground font-medium">No leads yet.</p>
                </div>
              )}
              {filtered.map((t) => {
                const d = new Date(t.lastAt || Date.now());
                const timeStr = d.toLocaleDateString() === new Date().toLocaleDateString() 
                  ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                  : d.toLocaleDateString([], { month: 'short', day: 'numeric' });

                return (
                  <button
                    key={t.threadId}
                    type="button"
                    onClick={() => setActiveId(t.threadId)}
                    className={cn(
                      "text-left px-4 py-3 border-b border-border/40 transition-colors hover:bg-muted/50 relative",
                      activeId === t.threadId && "bg-primary/5 border-l-4 border-l-primary",
                    )}
                  >
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <span className="font-bold text-sm truncate">{t.leadName}</span>
                      <span className="text-[10px] font-bold text-muted-foreground shrink-0 mt-0.5">
                        {timeStr}
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground line-clamp-1 mb-1">
                      {t.propertyTitle}
                    </p>
                    <p className={cn("text-xs line-clamp-1", t.unread > 0 ? "font-bold text-foreground" : "text-muted-foreground")}>
                      {t.lastMessage}
                    </p>
                    {t.unread > 0 && (
                      <Badge className="absolute mt-[2px] right-4 h-5 px-1.5 text-[10px] bg-primary">{t.unread} new</Badge>
                    )}
                  </button>
                )
              })}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      <Card className="lg:col-span-8 border-border/80 shadow-md flex flex-col overflow-hidden max-h-[700px]">
        {active ? (
          <>
            <CardHeader className="border-b border-border/60 pb-4 bg-muted/10">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3 min-w-0">
                  <Avatar className="h-12 w-12 rounded-2xl">
                    <AvatarFallback className="rounded-2xl bg-gradient-hero text-primary-foreground font-black">
                      {active.leadName?.charAt(0) || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="min-w-0">
                    <h3 className="font-display font-bold text-lg truncate">{active.leadName}</h3>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground font-medium">
                      <MapPin className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{active.propertyTitle}</span>
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Button variant="outline" size="sm" className="rounded-xl gap-2 font-bold">
                    <Phone className="w-4 h-4" /> Call
                  </Button>
                  <Button variant="outline" size="sm" className="rounded-xl gap-2 font-bold">
                    <User className="w-4 h-4" /> Profile
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col p-0 h-full relative">
              <ScrollArea 
                className="flex-1 p-4 lg:p-6"
                viewportRef={scrollRef}
              >
                <div className="space-y-4">
                  {messages.map((m, i) => {
                    const isMe = m.sender_role === "agent";
                    const timeStr = new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    return (
                      <motion.div
                        key={m._id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.05 }}
                        className={cn(
                          "flex",
                          isMe ? "justify-end" : "justify-start",
                        )}
                      >
                        <div
                          className={cn(
                            "max-w-[85%] md:max-w-[70%] rounded-2xl px-4 py-3 text-sm font-medium shadow-sm",
                            isMe
                              ? "bg-primary text-primary-foreground rounded-br-md"
                              : "bg-muted text-foreground border border-border/40 rounded-bl-md",
                          )}
                        >
                          <p className="whitespace-pre-wrap">{m.text}</p>
                          <p
                            className={cn(
                              "text-[10px] mt-1.5 font-bold uppercase tracking-wide text-right",
                              isMe
                                ? "text-primary-foreground/70"
                                : "text-muted-foreground",
                            )}
                          >
                            {timeStr}
                          </p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </ScrollArea>
              <div className="p-4 border-t border-border/60 bg-card">
                <form onSubmit={(e) => { e.preventDefault(); handleSend(); }} className="flex gap-2">
                  <Input
                    value={draft}
                    onChange={(e) => setDraft(e.target.value)}
                    placeholder="Type a reply…"
                    className="rounded-xl h-12 bg-muted/40 border-border/60 flex-1 px-4"
                  />
                  <Button
                    type="submit"
                    disabled={!draft.trim()}
                    className="rounded-xl h-12 px-6 shrink-0 shadow-hero bg-gradient-hero"
                  >
                    <Send className="w-5 h-5 mr-2" />
                    <span className="font-bold">Reply</span>
                  </Button>
                </form>
              </div>
            </CardContent>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-muted/10">
            <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mb-4">
              <MessageSquare className="w-10 h-10 text-primary" />
            </div>
            <h3 className="font-display font-bold text-xl mb-2">Agent Inbox</h3>
            <p className="text-muted-foreground text-sm max-w-sm">
              Select a lead from the side to continue your conversation.
            </p>
          </div>
        )}
      </Card>
    </div>
  );
}
