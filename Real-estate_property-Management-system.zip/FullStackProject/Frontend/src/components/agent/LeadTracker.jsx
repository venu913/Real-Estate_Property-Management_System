import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search, Phone, Mail, MessageSquare, Calendar,
  CalendarCheck2, Clock, CheckCircle2, XCircle, RefreshCcw,
  ChevronDown, ChevronUp, MapPin, Send, Trash2
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { toast as sonner } from "sonner";
import { format, parseISO } from "date-fns";
import { cn } from "@/lib/utils";

const STATUSES = ["new", "accepted", "rejected"];

const statusConfig = {
  new:         { label: "New",         color: "bg-blue-500/10 text-blue-500 border-blue-500/20" },
  contacted:   { label: "Contacted",   color: "bg-primary/10 text-primary border-primary/20" },
  interested:  { label: "Interested",  color: "bg-accent/10 text-accent border-accent/20" },
  site_visit:  { label: "Site Visit",  color: "bg-amber-500/10 text-amber-600 border-amber-500/20" },
  negotiation: { label: "Negotiation", color: "bg-purple-500/10 text-purple-600 border-purple-500/20" },
  closed:      { label: "Closed",      color: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" },
  lost:        { label: "Lost",        color: "bg-destructive/10 text-destructive border-destructive/20" },
  accepted:    { label: "Accepted",    color: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20" },
  rejected:    { label: "Rejected",    color: "bg-destructive/10 text-destructive border-destructive/20" },
};

const visitStatusConfig = {
  pending:    { label: "Pending",     color: "bg-amber-500/10 text-amber-600 border-amber-500/20",   icon: Clock },
  confirmed:  { label: "Confirmed",   color: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20", icon: CheckCircle2 },
  rescheduled:{ label: "Rescheduled", color: "bg-blue-500/10 text-blue-600 border-blue-500/20",      icon: RefreshCcw },
  cancelled:  { label: "Cancelled",   color: "bg-destructive/10 text-destructive border-destructive/20", icon: XCircle },
};

const TIME_SLOTS = [
  { id: "9-11",  label: "9:00 – 11:00 AM" },
  { id: "11-1",  label: "11:00 AM – 1:00 PM" },
  { id: "2-4",   label: "2:00 – 4:00 PM" },
  { id: "4-6",   label: "4:00 – 6:00 PM" },
  { id: "6-8",   label: "6:00 – 8:00 PM" },
];

const slotLabel = (id) => TIME_SLOTS.find(s => s.id === id)?.label || id || "—";
const fmtDate = (d) => {
  if (!d) return "—";
  try { return format(typeof d === "string" ? parseISO(d) : new Date(d), "PPP"); }
  catch { return d; }
};

// ── Visit Respond Panel ───────────────────────────────────────────────────────
function VisitRespondPanel({ lead, onDone }) {
  const [action, setAction] = useState(null); // 'confirm' | 'reschedule' | 'cancel'
  const [agentDate, setAgentDate] = useState("");
  const [agentSlot, setAgentSlot] = useState("");
  const [agentMsg, setAgentMsg] = useState("");
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    if (!action) return;
    setSaving(true);
    try {
      const body = { visit_status: action };
      if (action === "rescheduled") {
        if (!agentDate || !agentSlot) {
          sonner.error("Please pick a new date and time slot");
          setSaving(false);
          return;
        }
        body.visit_agent_date = new Date(agentDate).toISOString();
        body.visit_agent_slot = agentSlot;
        body.visit_agent_message = agentMsg;
      }
      if (action === "confirmed" && agentMsg) {
        body.visit_agent_message = agentMsg;
      }
      await api.patch(`/agent/leads/${lead._id}/visit`, body);
      sonner.success(
        action === "confirmed" ? "Visit confirmed ✅" :
        action === "rescheduled" ? "Reschedule sent to buyer 📅" :
        "Visit cancelled"
      );
      onDone();
    } catch (err) {
      sonner.error("Failed", { description: err.response?.data?.message || err.message });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="mt-4 border-t border-border/40 pt-4 space-y-4">
      <p className="text-xs font-black uppercase tracking-widest text-muted-foreground">Respond to visit request</p>

      {/* Action selector */}
      <div className="flex gap-2 flex-wrap">
        {[
          { key: "confirmed",   label: "✅ Confirm",    cls: "border-emerald-400/50 hover:bg-emerald-500/10 data-[active=true]:bg-emerald-500/10 data-[active=true]:border-emerald-500" },
          { key: "rescheduled", label: "📅 Reschedule", cls: "border-blue-400/50 hover:bg-blue-500/10 data-[active=true]:bg-blue-500/10 data-[active=true]:border-blue-500" },
          { key: "cancelled",   label: "❌ Cancel",     cls: "border-destructive/40 hover:bg-destructive/10 data-[active=true]:bg-destructive/10 data-[active=true]:border-destructive" },
        ].map(opt => (
          <button
            key={opt.key}
            type="button"
            data-active={action === opt.key}
            onClick={() => setAction(action === opt.key ? null : opt.key)}
            className={cn(
              "text-xs font-bold border-2 rounded-xl px-4 py-2 transition-all",
              opt.cls
            )}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {/* Reschedule fields */}
      <AnimatePresence>
        {action === "rescheduled" && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-3 overflow-hidden"
          >
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs font-bold text-muted-foreground">New Date</Label>
                <Input
                  type="date"
                  value={agentDate}
                  onChange={e => setAgentDate(e.target.value)}
                  min={new Date().toISOString().slice(0, 10)}
                  className="rounded-xl text-sm"
                />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold text-muted-foreground">New Time Slot</Label>
                <select
                  value={agentSlot}
                  onChange={e => setAgentSlot(e.target.value)}
                  className="w-full text-xs font-medium rounded-xl border border-border/60 px-3 py-2 bg-background"
                >
                  <option value="">Pick a slot…</option>
                  {TIME_SLOTS.map(s => (
                    <option key={s.id} value={s.id}>{s.label}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-xs font-bold text-muted-foreground">Message to buyer</Label>
              <Textarea
                value={agentMsg}
                onChange={e => setAgentMsg(e.target.value)}
                placeholder="Reason for reschedule or any instructions…"
                rows={2}
                className="rounded-xl text-sm resize-none"
              />
            </div>
          </motion.div>
        )}

        {action === "confirmed" && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="space-y-1">
              <Label className="text-xs font-bold text-muted-foreground">Optional message to buyer</Label>
              <Textarea
                value={agentMsg}
                onChange={e => setAgentMsg(e.target.value)}
                placeholder="Looking forward to seeing you! Here's the address…"
                rows={2}
                className="rounded-xl text-sm resize-none"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {action && (
        <Button
          size="sm"
          className="rounded-xl font-bold"
          disabled={saving}
          onClick={submit}
        >
          <Send className="w-3.5 h-3.5 mr-2" />
          {saving ? "Sending…" : "Send response"}
        </Button>
      )}
    </div>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function LeadTracker() {
  const { user } = useAuth();
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all"); // 'all' | 'inquiry' | 'site_visit'
  const [editingNotes, setEditingNotes] = useState(null);
  const [notesText, setNotesText] = useState("");
  const [expandedVisit, setExpandedVisit] = useState(null);

  const fetchLeads = async () => {
    if (!user) return;
    try {
      const res = await api.get("/agent/leads");
      setLeads(res.data || []);
    } catch (err) {
      console.error("Failed to fetch leads:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchLeads(); }, [user]);

  const updateStatus = async (leadId, newStatus) => {
    try {
      await api.patch(`/agent/leads/${leadId}/status`, { status: newStatus });
      fetchLeads();
      sonner.success("Status updated");
    } catch (err) {
      sonner.error("Update failed", { description: err.response?.data?.message || err.message });
    }
  };

  const deleteLead = async (leadId) => {
    if (!window.confirm("Are you sure you want to delete this schedule?")) return;
    try {
      await api.delete(`/agent/leads/${leadId}`);
      fetchLeads();
      sonner.success("Deleted successfully");
    } catch (err) {
      sonner.error("Delete failed", { description: err.response?.data?.message || err.message });
    }
  };

  const saveNotes = async (leadId) => {
    try {
      await api.patch(`/agent/leads/${leadId}/notes`, { notes: notesText });
      setEditingNotes(null);
      fetchLeads();
      sonner.success("Notes saved");
    } catch (err) {
      sonner.error("Update failed", { description: err.response?.data?.message || err.message });
    }
  };

  const filtered = leads.filter((l) => {
    const matchSearch =
      (l.name || "").toLowerCase().includes(search.toLowerCase()) ||
      (l.email || "").toLowerCase().includes(search.toLowerCase());
    const matchType = filterType === "all" || l.lead_type === filterType;
    return matchSearch && matchType;
  });

  const visitLeads = leads.filter(l => l.lead_type === "site_visit");
  const pendingVisits = visitLeads.filter(l => l.visit_status === "pending").length;

  if (loading) {
    return (
      <div className="space-y-3">
        {[1, 2, 3].map(i => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4"><div className="h-20 bg-muted rounded" /></CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">

      {/* ── Pending Visit Requests Banner ─────────────────────────────────── */}
      {pendingVisits > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between bg-amber-500/10 border border-amber-500/30 rounded-2xl px-5 py-4"
        >
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500 flex items-center justify-center">
              <CalendarCheck2 className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="font-bold text-amber-700 dark:text-amber-400 text-sm">
                {pendingVisits} pending visit {pendingVisits === 1 ? "request" : "requests"}
              </p>
              <p className="text-[11px] text-amber-600/80 dark:text-amber-400/70">
                Buyers are waiting for your confirmation
              </p>
            </div>
          </div>
          <Button
            size="sm"
            className="rounded-xl bg-amber-500 text-white font-bold hover:bg-amber-600"
            onClick={() => setFilterType("site_visit")}
          >
            View all
          </Button>
        </motion.div>
      )}

      {/* ── Filters ───────────────────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search leads…"
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>

        {/* Type filter */}
        <div className="flex gap-2">
          {[
            { key: "all",        label: `All (${leads.length})` },
            { key: "inquiry",    label: `Inquiries (${leads.filter(l => l.lead_type !== "site_visit").length})` },
            { key: "site_visit", label: `Schedules (${visitLeads.length})` },
          ].map(opt => (
            <Button
              key={opt.key}
              size="sm"
              variant={filterType === opt.key ? "default" : "outline"}
              onClick={() => setFilterType(opt.key)}
              className="rounded-xl font-bold text-xs"
            >
              {opt.label}
            </Button>
          ))}
        </div>
      </div>

      {/* ── Lead Cards ────────────────────────────────────────────────────── */}
      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <CalendarCheck2 className="w-14 h-14 text-muted-foreground/20 mx-auto mb-4" />
            <p className="text-muted-foreground font-bold">No leads found.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((lead, i) => {
            const isVisit = lead.lead_type === "site_visit";
            const vs = lead.visit_status;
            const VSIcon = visitStatusConfig[vs]?.icon || Clock;
            const isExpanded = expandedVisit === lead._id;
            const isPendingVisit = isVisit && vs === "pending";

            return (
              <motion.div
                key={lead._id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
              >
                <Card className={cn(
                  "transition-shadow",
                  isPendingVisit
                    ? "border-amber-400/50 shadow-amber-100 dark:shadow-none ring-1 ring-amber-400/30"
                    : "hover:shadow-md"
                )}>
                  <CardContent className="p-5">
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">

                      {/* ── Left: person info ── */}
                      <div className="space-y-2 flex-1 min-w-0">
                        <div className="flex items-center gap-3">
                          <div className={cn(
                            "w-11 h-11 rounded-2xl flex items-center justify-center text-white font-black text-sm shrink-0 shadow-sm",
                            isVisit ? "bg-gradient-to-br from-amber-500 to-orange-500" : "bg-gradient-to-br from-primary to-purple-600"
                          )}>
                            {(lead.name || "?").charAt(0).toUpperCase()}
                          </div>
                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className="font-bold text-foreground">{lead.name}</h4>
                              <Badge className={`text-[9px] border rounded-full px-2 py-0.5 font-black uppercase tracking-widest ${statusConfig[lead.status]?.color}`}>
                                {statusConfig[lead.status]?.label}
                              </Badge>
                              {isVisit && (
                                <Badge className={`text-[9px] border rounded-full px-2 py-0.5 font-black uppercase tracking-widest flex items-center gap-1 ${visitStatusConfig[vs]?.color}`}>
                                  <VSIcon className="w-2.5 h-2.5" />
                                  {visitStatusConfig[vs]?.label || vs}
                                </Badge>
                              )}
                            </div>
                            {(lead.property_title || lead.properties?.title) && (
                              <p className="text-xs text-muted-foreground mt-0.5 truncate">
                                📍 {lead.property_title || lead.properties.title}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Contact info */}
                        <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                          {lead.email && (
                            <span className="flex items-center gap-1"><Mail className="w-3 h-3" /> {lead.email}</span>
                          )}
                          {lead.phone && (
                            <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {lead.phone}</span>
                          )}
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {fmtDate(lead.createdAt)}
                          </span>
                        </div>

                        {/* ── Visit slot summary ── */}
                        {isVisit && lead.visit_date && (
                          <div className="flex items-center gap-4 bg-amber-500/5 border border-amber-500/20 rounded-xl px-4 py-3 text-sm mt-2">
                            <CalendarCheck2 className="w-4 h-4 text-amber-600 shrink-0" />
                            <div className="flex-1">
                              <p className="font-bold text-foreground">
                                Requested: {fmtDate(lead.visit_date)} · {slotLabel(lead.visit_slot)}
                              </p>
                              {lead.visit_note && (
                                <p className="text-xs text-muted-foreground mt-0.5">Note: {lead.visit_note}</p>
                              )}
                              {vs === "rescheduled" && lead.visit_agent_date && (
                                <p className="text-xs text-blue-600 mt-1 font-bold">
                                  Agent suggested: {fmtDate(lead.visit_agent_date)} · {slotLabel(lead.visit_agent_slot)}
                                </p>
                              )}
                              {vs === "confirmed" && (
                                <p className="text-xs text-emerald-600 mt-1 font-bold">✅ Visit confirmed</p>
                              )}
                              {lead.visit_agent_message && (
                                <p className="text-xs text-muted-foreground mt-1 italic">"{lead.visit_agent_message}"</p>
                              )}
                            </div>
                          </div>
                        )}

                        {/* Message */}
                        {lead.message && (
                          <p className="text-sm text-muted-foreground bg-muted/50 rounded-xl p-3 flex items-start gap-2">
                            <MessageSquare className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {lead.message}
                          </p>
                        )}

                        {/* Notes */}
                        {editingNotes === lead._id ? (
                          <div className="mt-2 space-y-2">
                            <Textarea
                              value={notesText}
                              onChange={e => setNotesText(e.target.value)}
                              placeholder="Add follow-up notes…"
                              rows={2}
                              className="rounded-xl text-sm resize-none"
                            />
                            <div className="flex gap-2">
                              <Button size="sm" className="rounded-xl" onClick={() => saveNotes(lead._id)}>Save</Button>
                              <Button size="sm" variant="ghost" className="rounded-xl" onClick={() => setEditingNotes(null)}>Cancel</Button>
                            </div>
                          </div>
                        ) : lead.notes ? (
                          <p
                            className="text-xs text-muted-foreground mt-1 cursor-pointer hover:text-foreground"
                            onClick={() => { setEditingNotes(lead._id); setNotesText(lead.notes || ""); }}
                          >
                            📝 {lead.notes}
                          </p>
                        ) : (
                          <button
                            className="text-xs text-primary hover:underline mt-1"
                            onClick={() => { setEditingNotes(lead._id); setNotesText(""); }}
                          >
                            + Add notes
                          </button>
                        )}
                      </div>

                      {/* ── Right: status + action ── */}
                      <div className="flex flex-col gap-2 min-w-[160px] shrink-0">
                        {!isVisit && (
                          <>
                            <select
                              value={lead.status}
                              onChange={e => updateStatus(lead._id, e.target.value)}
                              className={`text-xs font-bold rounded-xl border px-3 py-2 outline-none bg-background ${statusConfig[lead.status]?.color || ""}`}
                            >
                              {STATUSES.map(s => (
                                <option key={s} value={s}>{statusConfig[s]?.label || s}</option>
                              ))}
                            </select>
                            {lead.status === 'accepted' && (
                              <Button asChild size="sm" variant="secondary" className="w-full rounded-xl font-bold text-xs mt-1">
                                <Link to="/agent/messages">
                                  <MessageSquare className="w-3.5 h-3.5 mr-1.5" /> Message Buyer
                                </Link>
                              </Button>
                            )}
                          </>
                        )}

                        {/* Visit respond toggle — only for pending site-visit leads */}
                        {isVisit && vs === "pending" && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="rounded-xl font-bold border-amber-400/50 text-amber-700 dark:text-amber-400 hover:bg-amber-500/10 text-xs"
                            onClick={() => setExpandedVisit(isExpanded ? null : lead._id)}
                          >
                            {isExpanded ? (
                              <><ChevronUp className="w-3.5 h-3.5 mr-1" /> Close</>
                            ) : (
                              <><CalendarCheck2 className="w-3.5 h-3.5 mr-1" /> Respond</>
                            )}
                          </Button>
                        )}
                        
                        {/* Delete button for all leads */}
                        <Button
                          size="sm"
                          variant="ghost"
                          className="rounded-xl font-bold text-destructive hover:bg-destructive/10 text-xs mt-auto"
                          onClick={() => deleteLead(lead._id)}
                        >
                          <Trash2 className="w-3.5 h-3.5 mr-1.5" /> Delete
                        </Button>
                      </div>
                    </div>

                    {/* ── Visit Respond Panel ── */}
                    <AnimatePresence>
                      {isExpanded && isVisit && vs === "pending" && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          exit={{ opacity: 0, height: 0 }}
                          className="overflow-hidden"
                        >
                          <VisitRespondPanel
                            lead={lead}
                            onDone={() => {
                              setExpandedVisit(null);
                              fetchLeads();
                            }}
                          />
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
