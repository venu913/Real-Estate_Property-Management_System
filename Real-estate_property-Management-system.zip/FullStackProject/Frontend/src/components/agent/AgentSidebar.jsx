import {
  Building2,
  LayoutDashboard,
  Home,
  MessageSquare,
  Settings,
  LogOut,
  PlusCircle,
  Users,
  BarChart3,
} from "lucide-react";
import { NavLink, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { Badge } from "@/components/ui/badge";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";
const menuItems = [
  { to: "/agent", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/agent/listings", label: "My listings", icon: Home, end: false },
  { to: "/agent/add-property", label: "Add property", icon: PlusCircle, end: false },
  { to: "/agent/leads", label: "Leads", icon: Users, end: false },
  { to: "/agent/analytics", label: "Analytics", icon: BarChart3, end: false },
  { to: "/agent/messages", label: "Messages", icon: MessageSquare, end: false },
  { to: "/agent/profile", label: "Profile", icon: Settings, end: false },
];

function pathActive(pathname, to, end) {
  if (end) return pathname === to || pathname === `${to}/`;
  return pathname === to || pathname.startsWith(`${to}/`);
}

export default function AgentSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { pathname } = useLocation();
  const { profile, signOut, serverRole, role } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOut();
    navigate("/");
  };

  const showVerified =
    profile?.agent_verified ||
    serverRole === "admin" ||
    (serverRole === "agent" && role === "agent");

  return (
    <Sidebar collapsible="icon" className="border-r-0">
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel
            className="gap-2 cursor-pointer hover:opacity-80 transition-opacity"
            onClick={() => navigate("/")}
            title="Go to home page"
          >
            <Building2 className="w-4 h-4 text-primary" />
            {!collapsed && (
              <span className="font-display font-bold tracking-tight">PropNest</span>
            )}
          </SidebarGroupLabel>
          {!collapsed && (
            <p className="px-2 text-[10px] font-bold text-muted-foreground uppercase tracking-widest mb-2">
              Agent workspace
            </p>
          )}

          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems.map((item) => (
                <SidebarMenuItem key={item.to}>
                  <SidebarMenuButton
                    asChild
                    tooltip={item.label}
                    isActive={pathActive(pathname, item.to, item.end)}
                  >
                    <NavLink to={item.to} end={item.end}>
                      <item.icon className="w-4 h-4" />
                      {!collapsed && <span>{item.label}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        {!collapsed && (
          <div className="px-3 py-2 space-y-2">
            <div className="flex items-center gap-2 flex-wrap">
              <p className="text-xs font-semibold text-foreground truncate">
                {profile?.full_name || "Agent"}
              </p>
              {showVerified && (
                <Badge
                  variant="secondary"
                  className="text-[9px] h-5 px-1.5 font-black uppercase tracking-wide bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-emerald-500/20"
                >
                  Verified
                </Badge>
              )}
            </div>
            <p className="text-[10px] text-muted-foreground truncate">
              {profile?.company_name || "Independent broker"}
            </p>
          </div>
        )}
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={() => navigate("/")}
              tooltip="Buyer experience"
            >
              <Home className="w-4 h-4" />
              {!collapsed && <span>View site</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
          <SidebarMenuItem>
            <SidebarMenuButton
              onClick={handleLogout}
              tooltip="Logout"
              className="text-destructive hover:text-destructive"
            >
              <LogOut className="w-4 h-4" />
              {!collapsed && <span>Logout</span>}
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
