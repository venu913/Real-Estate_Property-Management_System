import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home, Users, TrendingUp, Eye, Clock, ArrowUpRight, Zap, Building, MousePointer2, ChevronRight, Mail, Phone,
  DollarSign, Calendar, BarChart3, PieChart, Activity, Target, Award, Bell, Settings, Download,
  Filter, Search, MoreVertical, Star, MapPin, TrendingDown, AlertCircle, CheckCircle2, Rocket, Plus
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Link } from "react-router-dom";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";

const ZERO_STATS = {
  totalProperties: 0,
  activeProperties: 0,
  totalLeads: 0,
  newLeads: 0,
};

export default function DashboardOverview() {
  const { user } = useAuth();
  const [stats, setStats] = useState(ZERO_STATS);
  const [recentLeads, setRecentLeads] = useState([]);
  const [topProperties, setTopProperties] = useState([]);
  const [timeRange, setTimeRange] = useState("30d");
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("overview");

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    const fetchData = async () => {
      setLoading(true);
      try {
        const [statsRes, recentRes, propertiesRes] = await Promise.all([
          api.get("/agent/stats"),
          api.get("/agent/leads/recent"),
          api.get("/agent/properties/top"),
        ]);
        if (cancelled) return;
        setStats({
          totalProperties: statsRes.data.totalProperties ?? 0,
          activeProperties: statsRes.data.activeProperties ?? 0,
          totalLeads: statsRes.data.totalLeads ?? 0,
          newLeads: statsRes.data.newLeads ?? 0,
        });
        setRecentLeads(recentRes.data || []);
        setTopProperties(propertiesRes.data || []);
      } catch (error) {
        if (!cancelled) {
          console.error("Failed to fetch dashboard data:", error);
          setStats(ZERO_STATS);
          setRecentLeads([]);
          setTopProperties([]);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    fetchData();
    return () => { cancelled = true; };
  }, [user, timeRange]);

  const isEmpty = !loading && stats.totalProperties === 0 && stats.totalLeads === 0;

  const statCards = [
    {
      label: "Total Properties",
      value: stats.totalProperties,
      icon: Building,
      gradient: "from-blue-500/10 to-transparent",
      iconColor: "text-blue-500",
      subtitle: `${stats.activeProperties} active listings`,
    },
    {
      label: "Total Leads",
      value: stats.totalLeads,
      icon: Users,
      gradient: "from-orange-500/10 to-transparent",
      iconColor: "text-orange-500",
      subtitle: `${stats.newLeads} new this week`,
    },
    {
      label: "Active Listings",
      value: stats.activeProperties,
      icon: CheckCircle2,
      gradient: "from-emerald-500/10 to-transparent",
      iconColor: "text-emerald-500",
      subtitle: "Visible to buyers",
    },
    {
      label: "New Leads",
      value: stats.newLeads,
      icon: Target,
      gradient: "from-purple-500/10 to-transparent",
      iconColor: "text-purple-500",
      subtitle: "Awaiting response",
    },
  ];

  const leadStatusColor = {
    new: "bg-blue-500/10 text-blue-500 border-blue-500/20",
    contacted: "bg-amber-500/10 text-amber-500 border-amber-500/20",
    interested: "bg-emerald-500/10 text-emerald-500 border-emerald-500/20",
    site_visit: "bg-purple-500/10 text-purple-500 border-purple-500/20",
    negotiation: "bg-red-500/10 text-red-500 border-red-500/20",
    closed: "bg-success/10 text-success border-success/20",
    lost: "bg-muted text-muted-foreground border-border",
  };

  if (loading) {
    return (
      <div className="space-y-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-32 bg-muted/50 rounded-[2rem] animate-pulse" />
          ))}
        </div>
        <div className="h-96 bg-muted/50 rounded-[2rem] animate-pulse" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2">
          <h1 className="font-display text-3xl lg:text-4xl font-black text-foreground">
            Welcome back, {user?.name || user?.full_name || "Agent"}!
          </h1>
          <p className="text-muted-foreground font-medium text-lg">
            {isEmpty
              ? "Let's get your first listing live 🚀"
              : "Here's your real estate performance overview"}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32 rounded-xl border-border/40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="icon" className="rounded-xl">
            <Bell className="w-4 h-4" />
          </Button>
          <Button variant="outline" size="icon" className="rounded-xl">
            <Settings className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* ── EMPTY STATE ── shown only when agent has nothing yet */}
      {isEmpty && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative overflow-hidden rounded-[2.5rem] border-2 border-dashed border-primary/30 bg-gradient-to-br from-primary/5 via-background to-purple-500/5 p-12 text-center"
        >
          {/* Decorative blobs */}
          <div className="absolute -top-16 -right-16 w-48 h-48 rounded-full bg-primary/10 blur-3xl" />
          <div className="absolute -bottom-16 -left-16 w-48 h-48 rounded-full bg-purple-500/10 blur-3xl" />

          <div className="relative z-10 flex flex-col items-center gap-6 max-w-lg mx-auto">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center shadow-2xl shadow-primary/30">
              <Rocket className="w-12 h-12 text-white" />
            </div>
            <div>
              <h2 className="font-display text-2xl font-black text-foreground mb-2">
                Your dashboard is brand new!
              </h2>
              <p className="text-muted-foreground font-medium leading-relaxed">
                You haven't uploaded any properties yet. Once you add your first listing,
                your stats, leads, and performance will appear here automatically.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4 w-full text-sm">
              {[
                { icon: Building, label: "Properties", value: "0 uploaded" },
                { icon: Users,    label: "Leads",      value: "0 received" },
                { icon: Eye,      label: "Views",       value: "0 total" },
                { icon: Target,   label: "Conversions", value: "0 closed" },
              ].map(({ icon: Icon, label, value }) => (
                <div key={label} className="flex items-center gap-3 p-4 rounded-2xl bg-muted/30 border border-border/40">
                  <div className="p-2 rounded-xl bg-muted">
                    <Icon className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div className="text-left">
                    <p className="font-bold text-foreground">{value}</p>
                    <p className="text-[11px] text-muted-foreground uppercase tracking-widest">{label}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex gap-3 flex-wrap justify-center">
              <Button asChild className="rounded-xl bg-gradient-to-r from-primary to-purple-600 text-white font-bold px-8 shadow-lg shadow-primary/20 hover:shadow-primary/30 transition-shadow">
                <Link to="/agent/add-property">
                  <Plus className="w-4 h-4 mr-2" /> Add Your First Property
                </Link>
              </Button>
              <Button asChild variant="outline" className="rounded-xl font-bold border-border/60">
                <Link to="/agent/listings">View Listings</Link>
              </Button>
            </div>
          </div>
        </motion.div>
      )}

      {/* ── STATS + CONTENT ── shown when agent has data OR as zeros in a lighter state */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3 bg-muted/20 rounded-xl p-1">
          <TabsTrigger value="overview"  className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm font-bold">Overview</TabsTrigger>
          <TabsTrigger value="properties" className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm font-bold">Properties</TabsTrigger>
          <TabsTrigger value="leads"     className="rounded-lg data-[state=active]:bg-background data-[state=active]:shadow-sm font-bold">Leads</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-8 mt-8">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {statCards.map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.08 }}
                whileHover={{ y: -4 }}
                className="group"
              >
                <Card className={`relative overflow-hidden rounded-[2rem] border-border/40 shadow-sm bg-gradient-to-br ${stat.gradient} hover:shadow-xl transition-all duration-300`}>
                  <CardContent className="p-8">
                    <div className="flex items-start justify-between mb-6">
                      <div className={`p-3 rounded-2xl bg-white shadow-sm ${stat.iconColor} group-hover:scale-110 transition-transform`}>
                        <stat.icon className="w-6 h-6" />
                      </div>
                    </div>
                    <div>
                      <p className="text-3xl font-display font-black text-foreground leading-none mb-2">
                        {stat.value}
                      </p>
                      <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-1">
                        {stat.label}
                      </p>
                      <p className="text-xs text-muted-foreground font-medium">{stat.subtitle}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Recent Leads */}
            <Card className="lg:col-span-2 rounded-[2.5rem] border-border/40 shadow-xl overflow-hidden">
              <CardHeader className="p-8 md:p-10 border-b border-border/40 bg-muted/10">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="font-display font-black text-xl">Recent Leads</CardTitle>
                    <CardDescription className="font-medium">Latest inquiries from potential buyers</CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4 md:p-8">
                {recentLeads.length === 0 ? (
                  <div className="py-16 text-center">
                    <div className="w-20 h-20 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-6">
                      <Users className="w-10 h-10 text-muted-foreground/30" />
                    </div>
                    <p className="text-muted-foreground font-bold text-lg">No leads yet</p>
                    <p className="text-muted-foreground/70 text-sm mt-1">
                      Leads will appear here once buyers inquire about your listings.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {recentLeads.map((lead, index) => (
                      <motion.div
                        key={lead._id || lead.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.08 }}
                        whileHover={{ x: 4 }}
                        className="flex items-center justify-between p-4 rounded-xl bg-muted/20 border border-border/40 hover:bg-muted/40 transition-all group cursor-pointer"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white font-black text-lg shadow-sm">
                            {(lead.name || lead.buyer_name || "?").charAt(0).toUpperCase()}
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="font-bold text-foreground">{lead.name || lead.buyer_name}</p>
                              <Badge className={`rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-widest border ${leadStatusColor[lead.status] || "bg-muted"}`}>
                                {(lead.status || "new").replace("_", " ")}
                              </Badge>
                            </div>
                            <p className="text-xs text-muted-foreground font-medium mb-1">{lead.property || lead.property_title || "—"}</p>
                            <div className="flex items-center gap-4 text-[10px] text-muted-foreground">
                              {lead.email && <span className="flex items-center gap-1"><Mail className="w-3 h-3" />{lead.email}</span>}
                              {(lead.phone || lead.buyer_phone) && <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{lead.phone || lead.buyer_phone}</span>}
                            </div>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                          <ChevronRight className="w-4 h-4" />
                        </Button>
                      </motion.div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <div className="space-y-6">
              <Card className="rounded-[2.5rem] border-border/40 p-6 shadow-sm">
                <h4 className="font-display font-black text-foreground mb-4">Quick Actions</h4>
                <div className="space-y-3">
                  <Button asChild className="w-full rounded-xl bg-gradient-to-r from-primary to-purple-600 text-white font-bold justify-start">
                    <Link to="/agent/add-property"><Plus className="w-4 h-4 mr-2" />Add New Property</Link>
                  </Button>
                  <Button asChild variant="outline" className="w-full rounded-xl font-bold justify-start">
                    <Link to="/agent/listings"><Building className="w-4 h-4 mr-2" />Manage Listings</Link>
                  </Button>
                  <Button asChild variant="outline" className="w-full rounded-xl font-bold justify-start">
                    <Link to="/agent/leads"><Users className="w-4 h-4 mr-2" />View All Leads</Link>
                  </Button>
                </div>
              </Card>

              {/* Getting Started Card — only when no properties */}
              {isEmpty && (
                <Card className="rounded-[2.5rem] bg-gradient-to-br from-amber-500/10 to-orange-500/5 border-amber-500/20 p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl bg-amber-500 flex items-center justify-center">
                      <Rocket className="w-5 h-5 text-white" />
                    </div>
                    <h4 className="font-display font-black text-foreground">Getting Started</h4>
                  </div>
                  <p className="text-sm text-muted-foreground font-medium mb-4">
                    Complete your first listing to start receiving leads from buyers!
                  </p>
                  <Button asChild className="w-full rounded-xl bg-amber-500 text-white font-bold hover:bg-amber-600 transition-colors">
                    <Link to="/agent/add-property">Post a Property</Link>
                  </Button>
                </Card>
              )}
            </div>
          </div>

          {/* Top Properties */}
          <Card className="rounded-[2.5rem] border-border/40 shadow-xl overflow-hidden">
            <CardHeader className="p-8 border-b border-border/40 bg-muted/10">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="font-display font-black text-xl">Top Performing Properties</CardTitle>
                  <CardDescription className="font-medium">Your most viewed and inquired listings</CardDescription>
                </div>
                <Button asChild variant="outline" size="sm" className="rounded-full font-bold text-xs uppercase tracking-widest border-primary/20 hover:bg-primary/5">
                  <Link to="/agent/listings">View All</Link>
                </Button>
              </div>
            </CardHeader>
            <CardContent className="p-8">
              {topProperties.length === 0 ? (
                <div className="py-12 text-center">
                  <Building className="w-14 h-14 text-muted-foreground/20 mx-auto mb-4" />
                  <p className="text-muted-foreground font-bold">No properties uploaded yet</p>
                  <p className="text-muted-foreground/70 text-sm mt-1">Upload a listing to see it appear here.</p>
                </div>
              ) : (
                <div className="grid gap-4">
                  {topProperties.map((property, index) => (
                    <motion.div
                      key={property._id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.08 }}
                      className="flex items-center justify-between p-4 rounded-xl bg-muted/20 border border-border/40 hover:bg-muted/40 transition-all group cursor-pointer"
                    >
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-purple-600 flex items-center justify-center text-white font-black">
                          #{index + 1}
                        </div>
                        <div>
                          <p className="font-bold text-foreground group-hover:text-primary transition-colors">{property.title}</p>
                          <p className="text-sm font-black text-primary">
                            ₹{(property.price || 0).toLocaleString("en-IN")}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Views</p>
                          <p className="text-sm font-bold">{property.views || 0}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-xs text-muted-foreground">Inquiries</p>
                          <p className="text-sm font-bold">{property.inquiries || 0}</p>
                        </div>
                      </div>
                    </motion.div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="properties" className="space-y-8 mt-8">
          <Card className="rounded-[2.5rem] border-border/40 shadow-xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-2xl font-black">Property Management</h3>
              <Button asChild className="rounded-xl bg-gradient-to-r from-primary to-purple-600 text-white font-bold">
                <Link to="/agent/listings"><Building className="w-4 h-4 mr-2" />Go to Listings</Link>
              </Button>
            </div>
            <div className="text-center py-12">
              <Building className="w-16 h-16 text-muted-foreground/20 mx-auto mb-4" />
              <p className="text-muted-foreground font-bold">Manage all your listings</p>
              <p className="text-muted-foreground/70 text-sm mt-1">Add, edit, publish or remove properties from the Listings tab.</p>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="leads" className="space-y-8 mt-8">
          <Card className="rounded-[2.5rem] border-border/40 shadow-xl p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-display text-2xl font-black">Lead Management</h3>
              <Button asChild className="rounded-xl bg-gradient-to-r from-primary to-purple-600 text-white font-bold">
                <Link to="/agent/leads"><Users className="w-4 h-4 mr-2" />View All Leads</Link>
              </Button>
            </div>
            {recentLeads.length === 0 ? (
              <div className="text-center py-12">
                <Users className="w-16 h-16 text-muted-foreground/20 mx-auto mb-4" />
                <p className="text-muted-foreground font-bold">No leads yet</p>
                <p className="text-muted-foreground/70 text-sm mt-1">Leads appear once buyers inquire about your properties.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentLeads.map((lead) => (
                  <div key={lead._id || lead.id} className="flex items-center justify-between p-4 rounded-xl bg-muted/20 border border-border/40">
                    <p className="font-bold">{lead.name || lead.buyer_name}</p>
                    <Badge className={`rounded-full px-2 py-0.5 text-[9px] font-black uppercase tracking-widest border ${leadStatusColor[lead.status] || "bg-muted"}`}>
                      {(lead.status || "new").replace("_", " ")}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
