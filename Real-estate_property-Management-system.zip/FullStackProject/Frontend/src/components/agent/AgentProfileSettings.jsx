import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import {
  Camera, BadgeCheck,
  Star, Award, Briefcase, FileText,
  Save, Plus, X, MessageSquare, Instagram, Linkedin,
  Layout, ShieldCheck, Edit3, Phone
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { toast as sonner } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Link } from "react-router-dom";

const SPECIALIZATIONS = ["Residential", "Commercial", "Luxury", "Rentals", "Plots", "Industrial"];
const LANGUAGES = ["English", "Hindi", "Marathi", "Gujarati", "Tamil", "Telugu", "Kannada", "Bengali"];
const BIO_TEMPLATES = [
  "Experienced real estate professional with a passion for helping clients find their dream homes. Specializing in luxury properties and off-market deals.",
  "Dedicated agent with a deep understanding of the local market. Committed to providing transparent, seamless, and high-yield investment options.",
  "Your trusted partner in real estate. From first-time homebuyers to seasoned investors, I provide customized solutions with unparalleled service."
];

export default function AgentProfileSettings() {
  const { user, profile, refreshProfile } = useAuth();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});
  const [draftSaved, setDraftSaved] = useState(false);
  const [listingCount, setListingCount] = useState(0);
  const fileInputRef = useRef(null);
  const coverInputRef = useRef(null);

  const [form, setForm] = useState({
    full_name: "",
    email: "",
    phone: "",
    city: "",
    state: "",
    bio: "",
    experience_years: "0",
    agency_name: "",
    rera_number: "",
    website: "",
    languages: [],
    specialization: [],
    certifications: [],
    avatar_url: "",
    cover_url: "",
    social: {
      whatsapp: "",
      linkedin: "",
      instagram: "",
      youtube: "",
    },
    show_contact: true,
    availability: "Available",
    public_profile: true,
  });

  const [certInput, setCertInput] = useState("");

  // ── Fetch real listing count ──────────────────────────────────────────────
  useEffect(() => {
    if (!user) return;
    api.get("/agent/stats")
      .then(res => setListingCount(res.data.totalProperties ?? 0))
      .catch(() => {});
  }, [user]);

  // ── Populate form from profile (loaded by AuthContext) ────────────────────
  useEffect(() => {
    if (!profile) return;

    const savedDraft = localStorage.getItem(`agent_draft_${user?.id}`);

    setForm({
      full_name: profile.full_name || "",
      email: user?.email || "",
      phone: profile.phone || "",
      city: profile.city || "",
      state: profile.state || "",
      bio: profile.bio || "",
      experience_years: profile.experience_years?.toString() || "0",
      agency_name: profile.agency_name || "",
      rera_number: profile.rera_number || "",
      website: profile.website || "",
      languages: profile.languages || [],
      specialization: profile.specialization || [],
      certifications: profile.certifications || [],
      avatar_url: profile.avatar_url || "",
      cover_url: profile.cover_url || "",
      social: {
        whatsapp: profile.social?.whatsapp || "",
        linkedin: profile.social?.linkedin || "",
        instagram: profile.social?.instagram || "",
        youtube: profile.social?.youtube || "",
      },
      show_contact: profile.show_contact !== false,
      availability: profile.availability || "Available",
      public_profile: profile.public_profile !== false,
    });

    if (savedDraft) {
      try {
        const parsed = JSON.parse(savedDraft);
        setForm(prev => ({ ...prev, ...parsed }));
        sonner.info("Restored unpublished draft");
      } catch (e) {}
    }
  }, [profile, user]);

  // ── Auto-save draft ───────────────────────────────────────────────────────
  useEffect(() => {
    if (form.full_name && user?.id) {
      const timer = setTimeout(() => {
        localStorage.setItem(`agent_draft_${user.id}`, JSON.stringify(form));
        setDraftSaved(true);
        setTimeout(() => setDraftSaved(false), 2000);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [form, user?.id]);

  // ── Validation ────────────────────────────────────────────────────────────
  const validate = () => {
    const errs = {};
    if (!form.full_name.trim()) errs.full_name = "Name is required";
    if (form.phone && !/^\+?[0-9\s-]+$/.test(form.phone)) errs.phone = "Invalid phone format";
    if (form.website && !/^https?:\/\//.test(form.website)) errs.website = "URL must start with http:// or https://";
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  // ── Save to backend ───────────────────────────────────────────────────────
  const handleSave = async () => {
    if (!validate()) {
      sonner.error("Please fix the validation errors");
      return;
    }

    setLoading(true);
    try {
      await api.put("/auth/profile", {
        ...form,
        experience_years: parseInt(form.experience_years) || 0,
      });
      sonner.success("Profile published successfully! ✨");
      localStorage.removeItem(`agent_draft_${user?.id}`);
      await refreshProfile();
    } catch (error) {
      sonner.error("Failed to publish profile", {
        description: error.response?.data?.message || error.message
      });
    } finally {
      setLoading(false);
    }
  };

  const toggleArrayItem = (field, item) => {
    setForm(prev => {
      const arr = prev[field];
      return {
        ...prev,
        [field]: arr.includes(item) ? arr.filter(i => i !== item) : [...arr, item]
      };
    });
  };

  const addCertification = (e) => {
    if (e.key === "Enter" || e.type === "click") {
      e.preventDefault();
      if (certInput.trim() && !form.certifications.includes(certInput.trim())) {
        setForm(prev => ({ ...prev, certifications: [...prev.certifications, certInput.trim()] }));
      }
      setCertInput("");
    }
  };

  const removeCertification = (cert) => {
    setForm(prev => ({
      ...prev,
      certifications: prev.certifications.filter(c => c !== cert)
    }));
  };

  const handleImageUpload = (type, e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      sonner.error("File too large (Max 2MB)");
      return;
    }
    const url = URL.createObjectURL(file);
    setForm(prev => ({ ...prev, [type]: url }));
    sonner.success("Image preview updated");
  };

  const isComplete = form.full_name && form.phone && form.city && form.bio && form.specialization.length > 0;

  return (
    <div className="flex flex-col xl:flex-row gap-6 relative max-w-7xl mx-auto">

      {/* ── LEFT: FORM ───────────────────────────────────────────────────────── */}
      <div className="flex-1 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-display font-black tracking-tight">Profile Settings</h1>
            <p className="text-muted-foreground font-medium">Manage your professional presence.</p>
          </div>
          <div className="flex items-center gap-4">
            {draftSaved && (
              <span className="text-xs font-bold text-muted-foreground flex items-center gap-1">
                <Save className="w-3 h-3" /> Draft saved
              </span>
            )}
            <Button
              id="publish-profile-btn"
              onClick={handleSave}
              disabled={loading}
              className="bg-gradient-hero shadow-hero px-8 rounded-xl font-bold"
            >
              {loading ? "Publishing..." : "Publish Profile"}
            </Button>
          </div>
        </div>

        {/* Media & Identity */}
        <Card className="border-border/60 shadow-sm rounded-3xl overflow-hidden">
          <CardHeader className="bg-muted/30 border-b border-border/40 pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <Camera className="w-5 h-5 text-primary" /> Branding &amp; Media
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              <div>
                <Label>Cover Image</Label>
                <div
                  className="mt-2 h-32 w-full rounded-2xl border-2 border-dashed border-border/60 bg-muted/20 flex flex-col items-center justify-center cursor-pointer hover:bg-muted/40 transition-colors relative overflow-hidden"
                  onClick={() => coverInputRef.current?.click()}
                >
                  {form.cover_url ? (
                    <img src={form.cover_url} className="absolute inset-0 w-full h-full object-cover" alt="cover" />
                  ) : (
                    <>
                      <Layout className="w-8 h-8 text-muted-foreground mb-2" />
                      <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Click to upload banner</span>
                    </>
                  )}
                  <input type="file" ref={coverInputRef} className="hidden" accept="image/*" onChange={(e) => handleImageUpload('cover_url', e)} />
                </div>
              </div>

              <div className="flex items-center gap-6">
                <Avatar className="w-24 h-24 rounded-2xl border-4 border-background shadow-lg relative cursor-pointer group" onClick={() => fileInputRef.current?.click()}>
                  <AvatarImage src={form.avatar_url} className="object-cover" />
                  <AvatarFallback className="rounded-2xl bg-primary/10 text-primary font-display text-2xl font-black">
                    {form.full_name?.charAt(0) || "U"}
                  </AvatarFallback>
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-2xl">
                    <Camera className="w-6 h-6 text-white" />
                  </div>
                </Avatar>
                <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => handleImageUpload('avatar_url', e)} />
                <div className="flex-1 space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Full Name</Label>
                      <Input
                        value={form.full_name}
                        onChange={e => setForm({ ...form, full_name: e.target.value })}
                        className={cn("rounded-xl bg-muted/40", errors.full_name && "border-destructive")}
                      />
                      {errors.full_name && <p className="text-[10px] text-destructive font-bold">{errors.full_name}</p>}
                    </div>
                    <div className="space-y-1">
                      <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground flex items-center gap-1">
                        Email <ShieldCheck className="w-3 h-3 text-success" />
                      </Label>
                      <Input value={form.email} readOnly className="rounded-xl bg-muted/50 opacity-70 cursor-not-allowed" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Professional Info */}
        <Card className="border-border/60 shadow-sm rounded-3xl overflow-hidden">
          <CardHeader className="bg-muted/30 border-b border-border/40 pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-primary" /> Professional Info
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1">
                <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Agency Name</Label>
                <Input value={form.agency_name} onChange={e => setForm({ ...form, agency_name: e.target.value })} placeholder="Independent or Company Name" className="rounded-xl" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">RERA Number</Label>
                <Input value={form.rera_number} onChange={e => setForm({ ...form, rera_number: e.target.value })} placeholder="Registration ID" className="rounded-xl" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Experience (Years)</Label>
                <Input type="number" min="0" value={form.experience_years} onChange={e => setForm({ ...form, experience_years: e.target.value })} className="rounded-xl" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Portfolio Website</Label>
                <Input value={form.website} onChange={e => setForm({ ...form, website: e.target.value })} placeholder="https://..." className={cn("rounded-xl", errors.website && "border-destructive")} />
                {errors.website && <p className="text-[10px] text-destructive font-bold">{errors.website}</p>}
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">City</Label>
                <Input value={form.city} onChange={e => setForm({ ...form, city: e.target.value })} placeholder="Primary operating city" className="rounded-xl" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">State</Label>
                <Input value={form.state} onChange={e => setForm({ ...form, state: e.target.value })} className="rounded-xl" />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Specializations</Label>
              <div className="flex flex-wrap gap-2">
                {SPECIALIZATIONS.map(spec => (
                  <Badge
                    key={spec}
                    variant={form.specialization.includes(spec) ? "default" : "outline"}
                    className="cursor-pointer rounded-lg text-xs py-1"
                    onClick={() => toggleArrayItem("specialization", spec)}
                  >
                    {spec}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Languages Spoken</Label>
              <div className="flex flex-wrap gap-2">
                {LANGUAGES.map(lang => (
                  <Badge
                    key={lang}
                    variant={form.languages.includes(lang) ? "default" : "secondary"}
                    className="cursor-pointer rounded-lg text-xs py-1 hover:bg-primary/20"
                    onClick={() => toggleArrayItem("languages", lang)}
                  >
                    {lang}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="space-y-3">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Certifications &amp; Awards</Label>
              <div className="flex gap-2">
                <Input
                  value={certInput}
                  onChange={e => setCertInput(e.target.value)}
                  onKeyDown={addCertification}
                  placeholder="e.g. Best Realtor 2023..."
                  className="rounded-xl flex-1"
                />
                <Button type="button" onClick={addCertification} variant="secondary" className="rounded-xl">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
              {form.certifications.length > 0 && (
                <div className="flex flex-col gap-2 mt-2">
                  {form.certifications.map((cert, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-muted/40 px-3 py-2 rounded-lg border border-border/40 text-sm font-medium">
                      <div className="flex items-center gap-2"><Award className="w-4 h-4 text-primary" /> {cert}</div>
                      <button onClick={() => removeCertification(cert)} className="text-muted-foreground hover:text-destructive">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Bio & Links */}
        <Card className="border-border/60 shadow-sm rounded-3xl overflow-hidden">
          <CardHeader className="bg-muted/30 border-b border-border/40 pb-4">
            <CardTitle className="text-lg flex items-center gap-2">
              <FileText className="w-5 h-5 text-primary" /> Biography
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6 space-y-6">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Professional Bio</Label>
                <span className="text-[10px] font-bold text-muted-foreground">{form.bio.length} / 1000 chars</span>
              </div>
              <Textarea
                value={form.bio}
                onChange={e => setForm({ ...form, bio: e.target.value.substring(0, 1000) })}
                className="rounded-xl min-h-[120px] resize-none leading-relaxed"
                placeholder="Share your story, values, and what makes you unique..."
              />
              <div className="flex gap-2 pt-2 pb-4 overflow-x-auto scrollbar-hide">
                {BIO_TEMPLATES.map((tmpl, i) => (
                  <button
                    key={i}
                    onClick={() => setForm({ ...form, bio: tmpl })}
                    className="shrink-0 text-left text-[11px] font-medium bg-muted/50 hover:bg-primary/10 border border-border/60 transition-colors p-3 rounded-xl w-64 leading-tight"
                  >
                    "{tmpl}"
                  </button>
                ))}
              </div>
            </div>

            <div className="border-t border-border/40 pt-6 space-y-4">
              <Label className="text-xs font-bold uppercase tracking-widest text-muted-foreground mb-4 block">Social &amp; Contact Links</Label>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2"><Phone className="w-4 h-4 text-muted-foreground" /></div>
                  <Input
                    value={form.phone}
                    onChange={e => setForm({ ...form, phone: e.target.value })}
                    placeholder="Phone Number"
                    className={cn("pl-9 rounded-xl", errors.phone && "border-destructive")}
                  />
                </div>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#25D366] font-black text-sm">W</div>
                  <Input value={form.social.whatsapp} onChange={e => setForm({ ...form, social: { ...form.social, whatsapp: e.target.value } })} placeholder="WhatsApp Number" className="pl-9 rounded-xl" />
                </div>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2"><Linkedin className="w-4 h-4 text-[#0A66C2]" /></div>
                  <Input value={form.social.linkedin} onChange={e => setForm({ ...form, social: { ...form.social, linkedin: e.target.value } })} placeholder="LinkedIn URL" className="pl-9 rounded-xl" />
                </div>
                <div className="relative">
                  <div className="absolute left-3 top-1/2 -translate-y-1/2"><Instagram className="w-4 h-4 text-[#E1306C]" /></div>
                  <Input value={form.social.instagram} onChange={e => setForm({ ...form, social: { ...form.social, instagram: e.target.value } })} placeholder="Instagram URL" className="pl-9 rounded-xl" />
                </div>
              </div>
            </div>

            <div className="pt-4">
              <Button
                onClick={handleSave}
                disabled={loading}
                className="w-full sm:w-auto bg-gradient-hero shadow-hero px-10 h-14 rounded-2xl font-black text-sm uppercase tracking-wider"
              >
                {loading ? "Saving Changes..." : "Save Changes"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* ── RIGHT: PREVIEW & SETTINGS ────────────────────────────────────────── */}
      <div className="w-full xl:w-[380px] space-y-6">

        {/* Visibility Toggles */}
        <Card className="border-border/60 shadow-sm rounded-3xl">
          <CardContent className="p-6 space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-sm">Public Profile</p>
                <p className="text-xs text-muted-foreground">Your profile is visible to buyers.</p>
              </div>
              <Switch
                id="public-profile-toggle"
                checked={form.public_profile}
                onCheckedChange={(c) => setForm({ ...form, public_profile: c })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-sm">Show Contact Info</p>
                <p className="text-xs text-muted-foreground">Display phone &amp; email publicly.</p>
              </div>
              <Switch
                id="show-contact-toggle"
                checked={form.show_contact}
                onCheckedChange={(c) => setForm({ ...form, show_contact: c })}
              />
            </div>
            <div className="flex items-center justify-between">
              <div>
                <p className="font-bold text-sm">Available Status</p>
                <p className="text-xs text-muted-foreground">Show green "Available" badge.</p>
              </div>
              <Switch
                id="availability-toggle"
                checked={form.availability !== "Busy"}
                onCheckedChange={(c) => setForm({ ...form, availability: c ? "Available" : "Busy" })}
              />
            </div>
          </CardContent>
        </Card>

        {/* Live Preview Card */}
        <div className="sticky top-28">
          <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground mb-3 text-center">Live Preview</p>
          <div className="bg-card border border-border/60 shadow-xl rounded-[2rem] overflow-hidden flex flex-col">
            {/* Cover */}
            <div className="h-28 bg-muted relative">
              {form.cover_url ? (
                <img src={form.cover_url} className="w-full h-full object-cover" alt="cover" />
              ) : (
                <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-primary/5" />
              )}
              {form.availability === "Available" && (
                <Badge className="absolute top-4 right-4 bg-success border-none shadow-sm text-[10px] px-2 py-0.5">
                  <div className="w-1.5 h-1.5 rounded-full bg-white mr-1.5 animate-pulse" />Available
                </Badge>
              )}
              {!form.public_profile && (
                <Badge className="absolute top-4 left-4 bg-muted-foreground/80 border-none text-[10px] px-2 py-0.5 text-white">
                  Hidden
                </Badge>
              )}
            </div>

            {/* Profile Main */}
            <div className="px-6 pb-6 relative flex-1 flex flex-col items-center text-center">
              <Avatar className="w-20 h-20 rounded-2xl border-4 border-card bg-muted shadow-lg absolute -top-10 left-1/2 -translate-x-1/2">
                <AvatarImage src={form.avatar_url} className="object-cover" />
                <AvatarFallback className="rounded-2xl text-2xl font-black text-muted-foreground">
                  {form.full_name?.charAt(0) || "U"}
                </AvatarFallback>
              </Avatar>

              <div className="mt-12 w-full">
                <h3 className="font-display font-black text-xl text-foreground flex items-center justify-center gap-1.5">
                  {form.full_name || "Your Name"}
                  {isComplete && <BadgeCheck className="w-5 h-5 text-primary" />}
                </h3>
                <p className="text-xs font-bold text-muted-foreground mt-1">
                  {form.agency_name || "Independent Consultant"}
                </p>

                <div className="flex items-center justify-center gap-4 mt-4 text-sm font-medium">
                  <div className="flex flex-col items-center">
                    <span className="font-black text-foreground">{listingCount}</span>
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Listings</span>
                  </div>
                  <div className="w-px h-6 bg-border/60" />
                  <div className="flex flex-col items-center">
                    <span className="font-black text-foreground">{form.experience_years || 0}+</span>
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Yrs Exp</span>
                  </div>
                  <div className="w-px h-6 bg-border/60" />
                  <div className="flex flex-col items-center">
                    <span className="font-black text-foreground flex items-center">
                      <Star className="w-3 h-3 fill-primary text-primary mr-1" />
                      {profile?.rating > 0 ? profile.rating.toFixed(1) : "—"}
                    </span>
                    <span className="text-[10px] uppercase tracking-wider text-muted-foreground">
                      {profile?.rating_count > 0 ? `${profile.rating_count} reviews` : "Rating"}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap justify-center gap-1.5 mt-5">
                  {form.specialization.slice(0, 3).map(spec => (
                    <Badge key={spec} variant="secondary" className="text-[9px] bg-primary/10 text-primary">{spec}</Badge>
                  ))}
                  {form.specialization.length > 3 && (
                    <Badge variant="secondary" className="text-[9px]">+{form.specialization.length - 3}</Badge>
                  )}
                </div>

                {form.bio && (
                  <p className="text-xs text-muted-foreground mt-5 leading-relaxed line-clamp-4">
                    {form.bio}
                  </p>
                )}

                <div className="grid grid-cols-2 gap-2 mt-6">
                  <Button variant="outline" className="rounded-xl h-10 font-bold text-xs" disabled>
                    <MessageSquare className="w-3.5 h-3.5 mr-1.5" /> Message
                  </Button>
                  {form.show_contact ? (
                    <Button className="rounded-xl h-10 bg-gradient-hero shadow-hero font-bold text-xs" disabled>
                      <Phone className="w-3.5 h-3.5 mr-1.5" /> Contact
                    </Button>
                  ) : (
                    <Button variant="secondary" className="rounded-xl h-10 font-bold text-xs" disabled>
                      Details Hidden
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Dashboard quick link */}
          <Button asChild variant="outline" className="w-full mt-4 rounded-2xl font-bold border-border/60">
            <Link to="/agent">
              <Edit3 className="w-4 h-4 mr-2" /> Go to Dashboard
            </Link>
          </Button>

          {!isComplete && (
            <div className="mt-4 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400">
              <p className="text-xs font-bold mb-1">Incomplete Profile</p>
              <p className="text-[11px] font-medium opacity-80">
                Fill in your name, phone, city, bio, and add at least one specialization to get the verified badge.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
