import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Plus,
  Pencil,
  Trash2,
  Eye,
  EyeOff,
  Search,
  IndianRupee,
  MapPin,
  BedDouble,
  Bath,
  Maximize,
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import PropertyFormDialog from "./PropertyFormDialog";

export default function PropertyManager() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingProperty, setEditingProperty] = useState(null);

  const fetchProperties = async () => {
    if (!user) return;
    try {
      const res = await api.get("/agent/properties");
      setProperties(res.data || []);
    } catch (error) {
      console.error("Failed to fetch properties:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProperties();
  }, [user]);

  const toggleStatus = async (property) => {
    const newStatus = property.status === "available" ? "draft" : "available";
    try {
      await api.patch(`/agent/properties/${property._id}/status`, { status: newStatus });
      toast({
        title: newStatus === "available" ? "Property Published" : "Property Unpublished",
      });
      fetchProperties();
    } catch (error) {
      toast({
        title: "Error",
        description: error.response?.data?.message || error.message,
        variant: "destructive",
      });
    }
  };

  const deleteProperty = async (id) => {
    if (!window.confirm("Are you sure you want to delete this property?")) return;
    try {
      await api.delete(`/agent/properties/${id}`);
      toast({ title: "Property Deleted" });
      fetchProperties();
    } catch (error) {
      toast({
        title: "Error",
        description: error.response?.data?.message || error.message,
        variant: "destructive",
      });
    }
  };

  const formatPrice = (price) => {
    if (price >= 10000000) return `₹${(price / 10000000).toFixed(2)} Cr`;
    if (price >= 100000) return `₹${(price / 100000).toFixed(2)} L`;
    return `₹${price.toLocaleString("en-IN")}`;
  };

  const filtered = properties.filter(
    (p) =>
      p.title.toLowerCase().includes(search.toLowerCase()) ||
      p.city?.toLowerCase().includes(search.toLowerCase()),
  );

  const statusColor = {
    active: "bg-success/10 text-success",
    draft: "bg-muted text-muted-foreground",
    sold: "bg-primary/10 text-primary",
    rented: "bg-info/10 text-info",
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search properties..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            asChild
            className="bg-gradient-hero text-primary-foreground shadow-hero"
          >
            <Link to="/agent/add-property" className="flex items-center">
              <Plus className="w-4 h-4 mr-2" /> Multi-step listing
            </Link>
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              setEditingProperty(null);
              setShowForm(true);
            }}
            className="font-bold"
          >
            Quick add
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-4">
                <div className="h-48 bg-muted rounded-lg" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <Card>
          <CardContent className="py-16 text-center">
            <p className="text-muted-foreground">
              No properties found. Add your first listing!
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          <AnimatePresence>
            {filtered.map((property) => (
              <motion.div
                key={property._id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
              >
                <Card className="overflow-hidden group hover:shadow-card-hover transition-shadow">
                  <div className="relative h-44 bg-muted">
                    {property.images?.[0] ? (
                      <img
                        src={property.images[0]}
                        alt={property.title}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                        No Image
                      </div>
                    )}
                    <Badge
                      className={`absolute top-3 left-3 ${statusColor[property.status] || ""}`}
                    >
                      {property.status}
                    </Badge>
                    <Badge className="absolute top-3 right-3 bg-foreground/70 text-primary-foreground">
                      {property.listing_type}
                    </Badge>
                  </div>
                  <CardContent className="p-4 space-y-3">
                    <div>
                      <h3 className="font-display font-bold text-foreground truncate">
                        {property.title}
                      </h3>
                      <p className="text-sm text-muted-foreground flex items-center gap-1 mt-1">
                        <MapPin className="w-3 h-3" /> {property.city || "N/A"},{" "}
                        {property.state || ""}
                      </p>
                    </div>
                    <p className="text-lg font-bold text-primary flex items-center gap-1">
                      <IndianRupee className="w-4 h-4" />{" "}
                      {formatPrice(property.price)}
                      {property.listing_type === "rent" && (
                        <span className="text-xs text-muted-foreground font-normal">
                          /mo
                        </span>
                      )}
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      {property.bedrooms > 0 && (
                        <span className="flex items-center gap-1">
                          <BedDouble className="w-3.5 h-3.5" />{" "}
                          {property.bedrooms} BHK
                        </span>
                      )}
                      {property.bathrooms > 0 && (
                        <span className="flex items-center gap-1">
                          <Bath className="w-3.5 h-3.5" /> {property.bathrooms}
                        </span>
                      )}
                      {property.area_sqft && (
                        <span className="flex items-center gap-1">
                          <Maximize className="w-3.5 h-3.5" />{" "}
                          {property.area_sqft} sqft
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 pt-2 border-t border-border">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleStatus(property)}
                        className="text-xs flex-1"
                      >
                        {property.status === "available" ? (
                          <>
                            <EyeOff className="w-3 h-3 mr-1" /> Unpublish
                          </>
                        ) : (
                          <>
                            <Eye className="w-3 h-3 mr-1" /> Publish
                          </>
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => {
                          setEditingProperty(property);
                          setShowForm(true);
                        }}
                      >
                        <Pencil className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => deleteProperty(property._id)}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}

      <PropertyFormDialog
        open={showForm}
        onOpenChange={setShowForm}
        property={editingProperty}
        onSaved={() => {
          setShowForm(false);
          fetchProperties();
        }}
      />
    </div>
  );
}
