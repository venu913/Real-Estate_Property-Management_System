import { motion } from "framer-motion";
import {
  Shield,
  Clock,
  Users,
  Award,
  Headphones,
  TrendingUp,
} from "lucide-react";

const features = [
  {
    icon: Shield,
    title: "Verified Listings",
    desc: "Every property is verified by our team for authenticity and accuracy.",
  },
  {
    icon: TrendingUp,
    title: "Best Prices",
    desc: "Compare prices across listings to get the best deals in the market.",
  },
  {
    icon: Users,
    title: "Expert Agents",
    desc: "Connect with 1000+ certified agents who know the local market.",
  },
  {
    icon: Clock,
    title: "Quick Process",
    desc: "From search to possession in the fastest timeline possible.",
  },
  {
    icon: Award,
    title: "RERA Compliant",
    desc: "All properties listed are RERA approved and legally verified.",
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    desc: "Our support team is available around the clock to assist you.",
  },
];

export default function WhyChooseUs() {
  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <p className="text-primary font-semibold text-sm uppercase tracking-wider mb-2">
            Why PropNest
          </p>
          <h2 className="font-display text-3xl lg:text-4xl font-bold text-foreground">
            Why Choose Us?
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="bg-card rounded-2xl p-7 shadow-card hover:shadow-card-hover transition-all duration-300 border border-border/50 group hover:-translate-y-1"
            >
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-gradient-hero group-hover:text-primary-foreground transition-all">
                <feature.icon className="w-6 h-6 text-primary group-hover:text-primary-foreground" />
              </div>
              <h3 className="font-display font-semibold text-lg text-card-foreground mb-2">
                {feature.title}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
