import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Phone } from "lucide-react";
import { Link } from "react-router-dom";

export default function CTASection() {
  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="bg-gradient-dark rounded-3xl p-10 lg:p-16 text-center relative overflow-hidden"
        >
          <div className="absolute inset-0 opacity-10">
            <div className="absolute top-10 left-10 w-40 h-40 rounded-full bg-primary/20 blur-3xl" />
            <div className="absolute bottom-10 right-10 w-60 h-60 rounded-full bg-accent/20 blur-3xl" />
          </div>

          <div className="relative z-10 max-w-2xl mx-auto">
            <h2 className="font-display text-3xl lg:text-5xl font-bold text-primary-foreground mb-4">
              Ready to Find Your{" "}
              <span className="text-gradient-hero">Perfect Home?</span>
            </h2>
            <p className="text-primary-foreground/60 text-lg mb-8">
              Talk to our experts and get personalised recommendations for free.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/login">
                <Button className="h-13 px-8 bg-gradient-hero text-primary-foreground shadow-hero font-semibold text-base rounded-xl">
                  Get Started <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </Link>
              <Button
                variant="outline"
                className="h-13 px-8 border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10 font-semibold text-base rounded-xl bg-transparent"
              >
                <Phone className="w-4 h-4 mr-2" /> Call Us
              </Button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
