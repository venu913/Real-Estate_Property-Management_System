import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { TrendingUp } from "lucide-react";
import { propertyService } from "@/services/property.service";
import PropertyCard from "@/components/PropertyCard";

export default function TrendingProperties() {
  const [properties, setProperties] = useState([]);
  
  useEffect(() => {
    propertyService.getProperties().then(setProperties).catch(console.error);
  }, []);

  const trending = properties.filter((p) => p.trending).slice(0, 4);

  return (
    <section className="py-20 bg-muted/50">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 text-accent text-sm font-semibold mb-4">
            <TrendingUp className="w-4 h-4" /> Trending Now
          </div>
          <h2 className="font-display text-3xl lg:text-4xl font-bold text-foreground">
            Most Popular Properties
          </h2>
          <p className="text-muted-foreground mt-3 max-w-lg mx-auto">
            Properties that buyers and renters are loving right now across India
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trending.map((property, i) => (
            <PropertyCard
              key={String(property._id || property.id || `trend-${i}`)}
              property={property}
              index={i}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
