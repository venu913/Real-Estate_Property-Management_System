import { useLocation, useOutlet } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";

function transitionKey(pathname) {
  if (pathname.startsWith("/agent")) return "agent-shell";
  return pathname;
}

export default function PageFadeLayout() {
  const location = useLocation();
  const outlet = useOutlet();
  const key = transitionKey(location.pathname);

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={key}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.12, ease: "easeOut" }}
        className="min-h-[100dvh]"
      >
        {outlet}
      </motion.div>
    </AnimatePresence>
  );
}
