import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  Menu,
  X,
  Heart,
  User,
  Search,
  Building2,
  LogOut,
  Mail,
  Lock,
  Eye,
  EyeOff,
  LayoutDashboard,
  Settings,
  ChevronDown,
  Plus,
  Bell,
  FileText,
  Calendar,
  Trash2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { authService } from "@/services/auth.service";
import {
  getPostLoginRedirect,
  deriveRoleFromUser,
  resolveEffectiveRole,
  ROLE_OVERRIDE_STORAGE_KEY,
} from "@/lib/authPaths";
import { setActiveTokenPreservingPrevious } from "@/lib/authTokens";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";

const navLinks = [
  { to: "/", label: "Home" },
  { to: "/properties", label: "Properties" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const [showLogin, setShowLogin] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  
  const location = useLocation();
  const navigate = useNavigate();
  const isHome = location.pathname === "/";
  const { user, profile, signOut, api, refreshProfile, isAgent } = useAuth();
  const { toast } = useToast();
  const { notifications, markNotificationRead, deleteNotification } = useBuyerActivity();
  const unreadAlerts = notifications.filter((n) => !n.read).length;

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleLogout = async () => {
    await signOut();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    });
    navigate("/");
  };

  const handleQuickLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const res = await api.post("/auth/login", {
        email,
        password,
      });

      let previousEmail = "";
      try {
        if (localStorage.getItem("token")) {
          const cur = await authService.me();
          previousEmail = cur?.email || "";
        }
      } catch {
        /* no valid prior session */
      }
      setActiveTokenPreservingPrevious(res.data.token, previousEmail);
      const me = await authService.me();
      await refreshProfile();
      const base = deriveRoleFromUser(me);
      const override = localStorage.getItem(ROLE_OVERRIDE_STORAGE_KEY);
      const effective = resolveEffectiveRole(base, override);

      toast({
        title: "Welcome back!",
        description: "You've been logged in successfully.",
      });
      navigate(getPostLoginRedirect(effective, location.pathname));
      setShowLogin(false);
      setEmail("");
      setPassword("");
    } catch (error) {
      const message = error.response?.data?.message || error.message || "An error occurred during login.";
      toast({
        title: "Login Failed",
        description: message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled || !isHome
            ? "bg-background/80 backdrop-blur-xl border-b border-border py-3"
            : "bg-transparent py-5"
        }`}
      >
        <div className="container mx-auto px-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2.5 group">
            <div className="w-10 h-10 rounded-xl bg-gradient-hero flex items-center justify-center shadow-hero group-hover:scale-105 transition-transform">
              <Building2 className="w-5.5 h-5.5 text-primary-foreground" />
            </div>
            <span className={`font-display text-2xl font-bold tracking-tight transition-colors ${
              !isHome || scrolled ? "text-foreground" : "text-primary-foreground"
            }`}>
              PropNest
            </span>
          </Link>

          <nav className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all hover:scale-105 ${
                  location.pathname === link.to
                    ? "bg-primary/10 text-primary"
                    : !isHome || scrolled 
                      ? "text-muted-foreground hover:text-foreground hover:bg-muted"
                      : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"
                }`}
              >
                {link.label}
              </Link>
            ))}
            {user && (
              <>
                <Link
                  to="/buyer/schedules"
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all hover:scale-105 ${
                    location.pathname === "/buyer/schedules"
                      ? "bg-primary/10 text-primary"
                      : !isHome || scrolled 
                        ? "text-muted-foreground hover:text-foreground hover:bg-muted"
                        : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"
                  }`}
                >
                  My Schedules
                </Link>
                <Link
                  to="/buyer/requests"
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all hover:scale-105 ${
                    location.pathname === "/buyer/requests"
                      ? "bg-primary/10 text-primary"
                      : !isHome || scrolled 
                        ? "text-muted-foreground hover:text-foreground hover:bg-muted"
                        : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"
                  }`}
                >
                  My Requests
                </Link>
                <Link
                  to="/tenant/leases"
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all hover:scale-105 ${
                    location.pathname === "/tenant/leases"
                      ? "bg-primary/10 text-primary"
                      : !isHome || scrolled 
                        ? "text-muted-foreground hover:text-foreground hover:bg-muted"
                        : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"
                  }`}
                >
                  My Leases
                </Link>
              </>
            )}
            {user ? (
              isAgent ? (
                <Link
                  to="/agent/add-property"
                  className={`px-4 py-2 rounded-lg text-sm font-bold transition-all hover:scale-105 flex items-center gap-2 ${
                    location.pathname === "/agent/add-property"
                      ? "bg-primary/10 text-primary"
                      : !isHome || scrolled
                        ? "text-primary hover:bg-primary/5"
                        : "text-primary-foreground hover:bg-white/10"
                  }`}
                >
                  <Plus className="w-4 h-4" /> Add listing
                </Link>
              ) : (
                <Link
                  to="/contact"
                  className={`px-4 py-2 rounded-lg text-sm font-bold transition-all hover:scale-105 flex items-center gap-2 ${
                    location.pathname === "/contact"
                      ? "bg-primary/10 text-primary"
                      : !isHome || scrolled
                        ? "text-primary hover:bg-primary/5"
                        : "text-primary-foreground hover:bg-white/10"
                  }`}
                >
                  <Plus className="w-4 h-4" /> Become an agent
                </Link>
              )
            ) : null}
          </nav>

          <div className="hidden lg:flex items-center gap-4">
            <Link to="/properties">
              <Button
                variant="ghost"
                size="icon"
                className={!isHome || scrolled ? "text-muted-foreground" : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"}
              >
                <Search className="w-5 h-5" />
              </Button>
            </Link>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className={`relative ${!isHome || scrolled ? "text-muted-foreground" : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"}`}
                >
                  <Bell className="w-5 h-5" />
                  {unreadAlerts > 0 && (
                    <span className="absolute top-2 right-2 flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-primary ring-2 ring-background" />
                    </span>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80 rounded-xl border-border/60 p-0 overflow-hidden">
                <DropdownMenuLabel className="px-4 py-3 text-xs font-black uppercase tracking-widest text-muted-foreground border-b border-border/50">
                  Live alerts
                </DropdownMenuLabel>
                <div className="max-h-72 overflow-y-auto py-1">
                  {notifications.map((n) => (
                    <DropdownMenuItem
                      key={n._id || n.id}
                      className="flex flex-col items-start gap-1 px-4 py-3 cursor-pointer rounded-none focus:bg-muted/80 relative group"
                      onClick={() => markNotificationRead(n._id || n.id)}
                    >
                      <div className="flex w-full justify-between gap-2">
                        <span className={`text-sm font-bold ${n.read ? "text-muted-foreground" : "text-foreground"}`}>
                          {n.title}
                        </span>
                        {!n.read && (
                          <span className="h-2 w-2 rounded-full bg-primary shrink-0 mt-1.5" />
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground font-medium leading-snug pr-6">{n.body}</span>
                      <span className="text-[10px] font-semibold text-muted-foreground/70">{n.time || new Date(n.createdAt).toLocaleDateString()}</span>
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8 text-destructive hover:bg-destructive/10"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteNotification(n._id || n.id);
                        }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </DropdownMenuItem>
                  ))}
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
            
            {user ? (
              <div className="flex items-center gap-3">
                <Link to="/saved">
                  <Button
                    variant="ghost"
                    size="icon"
                    className={!isHome || scrolled ? "text-muted-foreground" : "text-primary-foreground/80 hover:text-primary-foreground hover:bg-white/10"}
                  >
                    <Heart className="w-5 h-5" />
                  </Button>
                </Link>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-10 w-auto gap-2 px-2 hover:bg-white/10">
                      <div className="w-8 h-8 rounded-full bg-gradient-hero flex items-center justify-center text-primary-foreground text-sm font-bold shadow-sm">
                        {profile?.full_name?.charAt(0)?.toUpperCase() || user.email?.charAt(0)?.toUpperCase()}
                      </div>
                      <span className={`text-sm font-semibold max-w-[100px] truncate ${
                        !isHome || scrolled ? "text-foreground" : "text-primary-foreground"
                      }`}>
                        {profile?.full_name?.split(' ')[0] || "Account"}
                      </span>
                      <ChevronDown className={`w-4 h-4 transition-transform ${
                        !isHome || scrolled ? "text-muted-foreground" : "text-primary-foreground/70"
                      }`} />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56 mt-2 p-1.5 rounded-xl border-border/50 shadow-2xl backdrop-blur-xl bg-card/95">
                    <DropdownMenuLabel className="px-3 py-2">
                      <p className="text-xs font-medium text-muted-foreground">Signed in as</p>
                      <p className="text-sm font-semibold text-foreground truncate">{user.email}</p>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator className="bg-border/50" />
                    <DropdownMenuItem asChild className="rounded-lg cursor-pointer py-2.5">
                      <Link to="/profile" className="flex items-center gap-2.5">
                        <User className="w-4 h-4 text-primary" /> Profile Settings
                      </Link>
                    </DropdownMenuItem>

                    <DropdownMenuItem asChild className="rounded-lg cursor-pointer py-2.5">
                      <Link to="/saved" className="flex items-center gap-2.5">
                        <Heart className="w-4 h-4 text-primary" /> Saved Properties
                      </Link>
                    </DropdownMenuItem>
                    {isAgent && (
                      <DropdownMenuItem asChild className="rounded-lg cursor-pointer py-2.5">
                        <Link to="/agent" className="flex items-center gap-2.5">
                          <LayoutDashboard className="w-4 h-4 text-primary" /> Agent workspace
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuSeparator className="bg-border/50" />
                    <DropdownMenuItem 
                      onClick={handleLogout}
                      className="rounded-lg cursor-pointer py-2.5 text-destructive hover:text-destructive focus:bg-destructive/10"
                    >
                      <LogOut className="w-4 h-4 mr-2.5" /> Logout
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ) : (
              <div className="relative">
                <Button
                  onClick={() => setShowLogin(!showLogin)}
                  className="bg-gradient-hero text-primary-foreground shadow-hero font-bold px-6 h-11 rounded-xl hover:scale-105 active:scale-95 transition-all"
                >
                  <User className="w-4 h-4 mr-2" /> Login
                </Button>

                <AnimatePresence>
                  {showLogin && (
                    <motion.div
                      initial={{ opacity: 0, y: 15, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 15, scale: 0.95 }}
                      transition={{ type: "spring", damping: 20, stiffness: 300 }}
                      className="absolute right-0 top-full mt-4 w-80 bg-card/95 backdrop-blur-xl rounded-2xl shadow-hero border border-border/50 p-6 z-[60]"
                    >
                      <div className="flex items-center justify-between mb-5">
                        <div>
                          <h3 className="font-display text-xl font-bold text-foreground">
                            Welcome Back
                          </h3>
                          <p className="text-xs text-muted-foreground mt-0.5">Enter details to sign in</p>
                        </div>
                        <button
                          onClick={() => setShowLogin(false)}
                          className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-muted text-muted-foreground transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>

                      <form onSubmit={handleQuickLogin} className="space-y-4">
                        <div className="space-y-1">
                          <div className="relative">
                            <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input
                              type="email"
                              placeholder="Email address"
                              value={email}
                              onChange={(e) => setEmail(e.target.value)}
                              className="pl-11 h-12 bg-muted/30 border-border/50 focus:ring-primary/20"
                              required
                            />
                          </div>
                        </div>
                        <div className="space-y-1">
                          <div className="relative">
                            <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                            <Input
                              type={showPassword ? "text" : "password"}
                              placeholder="Password"
                              value={password}
                              onChange={(e) => setPassword(e.target.value)}
                              className="pl-11 pr-11 h-12 bg-muted/30 border-border/50 focus:ring-primary/20"
                              required
                            />

                            <button
                              type="button"
                              onClick={() => setShowPassword(!showPassword)}
                              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                            >
                              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                            </button>
                          </div>
                        </div>

                        <Button
                          type="submit"
                          disabled={loading}
                          className="w-full bg-gradient-hero text-primary-foreground shadow-hero font-bold h-12 rounded-xl text-base mt-2"
                        >
                          {loading ? (
                            <div className="flex items-center gap-2">
                              <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                              Signing in...
                            </div>
                          ) : "Sign In"}
                        </Button>
                      </form>

                      <div className="mt-5 flex items-center justify-between text-xs font-semibold">
                        <Link
                          to="/forgot-password"
                          onClick={() => setShowLogin(false)}
                          className="text-primary hover:text-primary/80 transition-colors"
                        >
                          Forgot password?
                        </Link>
                        <Link
                          to="/signup"
                          onClick={() => setShowLogin(false)}
                          className="text-foreground hover:text-primary transition-colors flex items-center gap-1"
                        >
                          New here? <span className="text-primary">Create Account</span>
                        </Link>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}
          </div>

          <button
            onClick={() => setOpen(!open)}
            className={`lg:hidden p-2 rounded-xl transition-colors ${
              !isHome || scrolled ? "text-foreground hover:bg-muted" : "text-primary-foreground hover:bg-white/10"
            }`}
          >
            {open ? <X className="w-7 h-7" /> : <Menu className="w-7 h-7" />}
          </button>
        </div>

        <AnimatePresence>
          {open && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="lg:hidden bg-card border-t border-border shadow-2xl overflow-hidden"
            >
              <div className="container mx-auto px-4 py-8 flex flex-col gap-3">
                {navLinks.map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    onClick={() => setOpen(false)}
                    className={`px-5 py-4 rounded-xl text-base font-bold transition-all active:scale-[0.98] ${
                      location.pathname === link.to
                        ? "bg-primary/10 text-primary border border-primary/20"
                        : "text-muted-foreground hover:bg-muted"
                    }`}
                  >
                    {link.label}
                  </Link>
                ))}
                {user ? (
                  isAgent ? (
                    <Link
                      to="/agent/add-property"
                      onClick={() => setOpen(false)}
                      className={`px-5 py-4 rounded-xl text-base font-bold transition-all active:scale-[0.98] flex items-center gap-3 ${
                        location.pathname === "/agent/add-property"
                          ? "bg-primary text-primary-foreground shadow-hero"
                          : "text-primary hover:bg-primary/5 border border-primary/10"
                      }`}
                    >
                      <Plus className="w-5 h-5" /> Add listing
                    </Link>
                  ) : (
                    <Link
                      to="/contact"
                      onClick={() => setOpen(false)}
                      className={`px-5 py-4 rounded-xl text-base font-bold transition-all active:scale-[0.98] flex items-center gap-3 ${
                        location.pathname === "/contact"
                          ? "bg-primary text-primary-foreground shadow-hero"
                          : "text-primary hover:bg-primary/5 border border-primary/10"
                      }`}
                    >
                      <Plus className="w-5 h-5" /> Become an agent
                    </Link>
                  )
                ) : null}
                
                <div className="h-px bg-border/50 my-2" />
                
                {user ? (
                  <>
                    <Link
                      to="/buyer/schedules"
                      onClick={() => setOpen(false)}
                      className="px-5 py-4 rounded-xl text-base font-bold text-muted-foreground flex items-center gap-3"
                    >
                      <Calendar className="w-5 h-5 text-primary" /> My Schedules
                    </Link>
                    <Link
                      to="/buyer/requests"
                      onClick={() => setOpen(false)}
                      className="px-5 py-4 rounded-xl text-base font-bold text-muted-foreground flex items-center gap-3"
                    >
                      <FileText className="w-5 h-5 text-primary" /> My Requests
                    </Link>
                    <Link
                      to="/tenant/leases"
                      onClick={() => setOpen(false)}
                      className="px-5 py-4 rounded-xl text-base font-bold text-muted-foreground flex items-center gap-3"
                    >
                      <FileText className="w-5 h-5 text-primary" /> My Leases
                    </Link>
                    <Link
                      to="/saved"
                      onClick={() => setOpen(false)}
                      className="px-5 py-4 rounded-xl text-base font-bold text-muted-foreground flex items-center gap-3"
                    >
                      <Heart className="w-5 h-5 text-primary" /> Saved Properties
                    </Link>
                    <Link
                      to="/profile"
                      onClick={() => setOpen(false)}
                      className="px-5 py-4 rounded-xl text-base font-bold text-muted-foreground flex items-center gap-3"
                    >
                      <User className="w-5 h-5 text-primary" /> My Profile
                    </Link>
                    {isAgent && (
                      <Link
                        to="/agent"
                        onClick={() => setOpen(false)}
                        className="px-5 py-4 rounded-xl text-base font-bold text-muted-foreground flex items-center gap-3"
                      >
                        <LayoutDashboard className="w-5 h-5 text-primary" /> Agent workspace
                      </Link>
                    )}
                    <Button
                      variant="outline"
                      onClick={() => {
                        handleLogout();
                        setOpen(false);
                      }}
                      className="mt-4 h-14 rounded-xl text-destructive border-destructive/20 font-bold bg-destructive/5"
                    >
                      <LogOut className="w-5 h-5 mr-3" /> Logout
                    </Button>
                  </>
                ) : (
                  <div className="flex flex-col gap-3 mt-4">
                    <Link to="/login" onClick={() => setOpen(false)}>
                      <Button className="w-full h-14 rounded-xl bg-gradient-hero text-primary-foreground font-bold text-base shadow-hero">
                        <User className="w-5 h-5 mr-3" /> Login to Account
                      </Button>
                    </Link>
                    <Link to="/signup" onClick={() => setOpen(false)}>
                      <Button variant="outline" className="w-full h-14 rounded-xl font-bold text-base border-border/50">
                        Join PropNest
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.header>

      <AnimatePresence>
        {showLogin && !user && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setShowLogin(false)}
            className="fixed inset-0 z-40 bg-foreground/30 backdrop-blur-md"
          />
        )}
      </AnimatePresence>
    </>
  );
}
