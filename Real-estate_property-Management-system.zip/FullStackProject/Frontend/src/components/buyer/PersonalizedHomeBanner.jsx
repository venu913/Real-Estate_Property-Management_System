import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";

function formatCr(n) {
  if (!n && n !== 0) return "";
  if (n >= 10000000) return `${(n / 10000000).toFixed(1)} Cr`;
  if (n >= 100000) return `${(n / 100000).toFixed(1)} L`;
  return `₹${Number(n).toLocaleString("en-IN")}`;
}

export default function PersonalizedHomeBanner() {
  const { onboarding } = useBuyerActivity();
  if (!onboarding?.completed || onboarding?.skipped) return null;
  const { city, budgetMin, budgetMax, propertyType } = onboarding;
  if (!city && !propertyType) return null;

  const search = new URLSearchParams();
  if (city) search.set("city", city);
  if (budgetMin != null) search.set("minPrice", String(budgetMin));
  if (budgetMax != null) search.set("maxPrice", String(budgetMax));
  if (propertyType) search.set("category", propertyType);

  return (
    <motion.section
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      className="container mx-auto px-4 -mt-6 mb-10 relative z-20"
    >
      <div className="rounded-2xl border border-primary/20 bg-gradient-to-r from-primary/10 via-card to-muted/40 p-5 md:p-6 flex flex-col md:flex-row md:items-center md:justify-between gap-4 shadow-sm">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/15 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-primary" />
          </div>
          <div>
            <p className="text-[10px] font-black uppercase tracking-widest text-primary mb-1">
              Personalized for you
            </p>
            <h2 className="font-display text-lg md:text-xl font-black text-foreground leading-tight">
              {city ? `${propertyType || "Homes"} in ${city}` : `${propertyType || "Homes"} in your style`}
              {budgetMin != null && budgetMax != null && (
                <span className="text-muted-foreground font-bold text-base block sm:inline sm:ml-1">
                  · {formatCr(budgetMin)} – {formatCr(budgetMax)}
                </span>
              )}
            </h2>
            <p className="text-sm text-muted-foreground font-medium mt-1">
              Jump straight into listings tuned from your onboarding preferences.
            </p>
          </div>
        </div>
        <Button
          asChild
          className="rounded-xl font-black uppercase tracking-wider text-xs h-11 px-6 shrink-0 bg-gradient-hero shadow-md transition-transform active:scale-[0.98]"
        >
          <Link to={`/properties?${search.toString()}`} className="gap-2">
            View matches
            <ArrowRight className="w-4 h-4" />
          </Link>
        </Button>
      </div>
    </motion.section>
  );
}
