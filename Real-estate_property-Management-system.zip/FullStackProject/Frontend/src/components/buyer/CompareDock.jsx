import { Link } from "react-router-dom";
import { GitCompare, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCompare } from "@/contexts/CompareContext";

export default function CompareDock() {
  const { items, count, removeProperty, clearAll } = useCompare();

  if (count === 0) return null;

  return (
    <div className="fixed bottom-0 inset-x-0 z-[90] pointer-events-none p-3 sm:p-4 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
      <div className="mx-auto max-w-4xl pointer-events-auto rounded-2xl border border-border/80 bg-card/95 backdrop-blur-xl shadow-2xl flex flex-col sm:flex-row sm:items-center gap-3 p-3 sm:px-4">
        <div className="flex items-center gap-2 text-sm font-black uppercase tracking-wide text-muted-foreground shrink-0">
          <GitCompare className="w-5 h-5 text-primary" />
          Compare
          <span className="rounded-full bg-primary/15 text-primary px-2 py-0.5 text-xs font-mono">{count}</span>
        </div>
        <div className="flex gap-2 flex-1 overflow-x-auto pb-1 sm:pb-0 scrollbar-thin">
          {items.map((p) => (
            <div
              key={p._id || p.id}
              className="flex items-center gap-2 shrink-0 rounded-xl bg-muted/60 pl-1 pr-2 py-1 border border-border/50"
            >
              <div className="h-11 w-11 rounded-lg overflow-hidden bg-muted shrink-0">
                <img
                  src={p.images?.[0] || p.image}
                  alt=""
                  className="h-full w-full object-cover"
                />
              </div>
              <span className="text-xs font-bold line-clamp-2 max-w-[100px]">{p.title}</span>
              <button
                type="button"
                className="p-1 rounded-md hover:bg-destructive/10 text-muted-foreground hover:text-destructive transition-colors"
                onClick={() => removeProperty(p._id || p.id)}
                aria-label="Remove from compare"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
        <div className="flex gap-2 shrink-0">
          <Button variant="ghost" size="sm" className="font-bold rounded-xl" onClick={clearAll}>
            Clear
          </Button>
          <Button asChild className="rounded-xl font-bold bg-gradient-hero shadow-hero">
            <Link to="/compare">Open compare</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
