import { useEffect, useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { Clock, ArrowRight } from "lucide-react";
import api from "@/services/api";
import PropertyCard from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";

export default function RecentlyViewedHome() {
  const { recentIds } = useBuyerActivity();
  const [pool, setPool] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await api.get("/properties");
        if (!cancelled) setPool(res.data || []);
      } catch {
        if (!cancelled) setPool([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const items = useMemo(() => {
    if (!recentIds.length || !pool.length) return [];
    const map = new Map(pool.map((p) => [String(p._id || p.id), p]));
    return recentIds.map((id) => map.get(String(id))).filter(Boolean).slice(0, 4);
  }, [recentIds, pool]);

  if (loading || items.length === 0) return null;

  return (
    <section className="py-20 md:py-28 bg-background">
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-10">
          <div>
            <div className="flex items-center gap-2 text-muted-foreground font-bold text-[10px] uppercase tracking-widest mb-2">
              <Clock className="w-3.5 h-3.5" /> Continue browsing
            </div>
            <h2 className="font-display text-3xl md:text-4xl font-black text-foreground">
              Recently viewed
            </h2>
          </div>
          <Link to="/buyer/dashboard">
            <Button variant="ghost" className="font-bold gap-2 text-primary">
              Buyer hub <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {items.map((property, i) => (
            <PropertyCard key={property._id || property.id} property={property} index={i} variant="buyer" />
          ))}
        </div>
      </div>
    </section>
  );
}
