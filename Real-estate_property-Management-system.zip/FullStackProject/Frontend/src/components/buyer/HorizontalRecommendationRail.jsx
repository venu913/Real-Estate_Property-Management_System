import { ChevronRight, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import RecommendationMiniCard from "./RecommendationMiniCard";
import { cn } from "@/lib/utils";

function RailSkeleton({ count = 5 }) {
  return (
    <div className="flex gap-4 overflow-hidden pb-2">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="shrink-0 w-[280px] sm:w-[300px] rounded-2xl border border-border/40 bg-muted/50 overflow-hidden animate-pulse"
        >
          <div className="aspect-[16/10] bg-muted" />
          <div className="p-4 space-y-2">
            <div className="h-4 bg-muted rounded w-3/4" />
            <div className="h-3 bg-muted rounded w-1/2" />
            <div className="h-3 bg-muted rounded w-2/3" />
          </div>
        </div>
      ))}
    </div>
  );
}

export default function HorizontalRecommendationRail({
  title,
  subtitle,
  icon: Icon = Sparkles,
  items,
  loading,
  emptyMessage,
  hrefSeeAll = "/properties",
  className,
}) {
  return (
    <section className={cn("py-10 md:py-14", className)}>
      <div className="container mx-auto px-4">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 text-primary mb-2">
              <Icon className="w-4 h-4" />
              <span className="text-[10px] font-black uppercase tracking-[0.25em]">
                Smart picks
              </span>
            </div>
            <h2 className="font-display text-2xl md:text-4xl font-black text-foreground tracking-tight">
              {title}
            </h2>
            {subtitle && (
              <p className="text-muted-foreground text-sm font-medium mt-2 max-w-2xl">
                {subtitle}
              </p>
            )}
          </div>
          <Button variant="outline" size="sm" className="rounded-full font-bold shrink-0" asChild>
            <Link to={hrefSeeAll}>
              See all <ChevronRight className="w-4 h-4 ml-1" />
            </Link>
          </Button>
        </div>

        {loading ? (
          <RailSkeleton />
        ) : !items?.length ? (
          <div className="rounded-2xl border border-dashed border-border/60 bg-muted/20 py-14 text-center text-sm text-muted-foreground font-medium">
            {emptyMessage || "No recommendations yet — browse a few listings to train your feed."}
          </div>
        ) : (
          <div className="relative">
            <div
              className={cn(
                "flex gap-4 overflow-x-auto pb-4 pt-1 -mx-1 px-1 snap-x snap-mandatory",
                "scrollbar-thin scrollbar-thumb-primary/20 scrollbar-track-transparent",
                "scroll-smooth",
              )}
              style={{ scrollbarWidth: "thin" }}
            >
              {items.map(({ property, tags }) => (
                <RecommendationMiniCard
                  key={property._id || property.id}
                  property={property}
                  tags={tags}
                />
              ))}
            </div>
            <div className="pointer-events-none absolute inset-y-0 right-0 w-16 bg-gradient-to-l from-background to-transparent hidden sm:block" />
          </div>
        )}
      </div>
    </section>
  );
}
