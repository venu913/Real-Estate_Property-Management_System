import { Link } from "react-router-dom";
import { MapPin, Bed, Maximize2 } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

function formatPrice(amount) {
  if (amount >= 10000000) return `${(amount / 10000000).toFixed(2)} Cr`;
  if (amount >= 100000) return `${(amount / 100000).toFixed(2)} L`;
  return amount?.toLocaleString("en-IN") ?? "—";
}

export default function RecommendationMiniCard({ property, tags = [], className }) {
  const id = property._id || property.id;
  const img = property.images?.[0] || property.image;

  return (
    <Link
      to={`/property/${id}`}
      className={cn(
        "group shrink-0 w-[280px] sm:w-[300px] snap-start rounded-2xl border border-border/60 bg-card shadow-sm overflow-hidden",
        "hover:border-primary/40 hover:shadow-lg transition-all duration-300",
        className,
      )}
    >
      <div className="relative aspect-[16/10] overflow-hidden">
        <img
          src={img || "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=600"}
          alt=""
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 max-w-[90%]">
          {tags.slice(0, 2).map((t) => (
            <Badge
              key={t}
              className="bg-primary/95 text-primary-foreground border-0 text-[9px] font-black uppercase tracking-wide shadow-md backdrop-blur-sm"
            >
              {t}
            </Badge>
          ))}
        </div>
        <div className="absolute bottom-3 left-3 right-3">
          <p className="text-white font-display font-black text-lg leading-tight line-clamp-2 drop-shadow-md">
            ₹{formatPrice(property.price)}
            {property.listing_type === "rent" && (
              <span className="text-xs font-bold text-white/80"> /mo</span>
            )}
          </p>
        </div>
      </div>
      <div className="p-4 space-y-2">
        <h3 className="font-bold text-sm text-foreground line-clamp-2 leading-snug group-hover:text-primary transition-colors">
          {property.title}
        </h3>
        <div className="flex items-center gap-1 text-xs text-muted-foreground font-semibold">
          <MapPin className="w-3.5 h-3.5 text-primary shrink-0" />
          <span className="truncate">{property.city}</span>
        </div>
        <div className="flex items-center gap-3 text-[11px] font-bold text-muted-foreground">
          <span className="flex items-center gap-1">
            <Bed className="w-3.5 h-3.5" />
            {property.bedrooms ?? 0} BHK
          </span>
          <span className="flex items-center gap-1">
            <Maximize2 className="w-3.5 h-3.5" />
            {property.area_sqft ?? "—"} sqft
          </span>
        </div>
      </div>
    </Link>
  );
}
