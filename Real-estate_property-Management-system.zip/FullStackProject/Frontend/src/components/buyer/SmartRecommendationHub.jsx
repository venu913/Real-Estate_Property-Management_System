import { useMemo, useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Brain, GitCompare, Orbit } from "lucide-react";
import api from "@/services/api";
import { useAuth } from "@/contexts/AuthContext";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";
import {
  buildForYouList,
  getSimilarProperties,
  getBecauseYouViewed,
} from "@/lib/recommendationEngine";
import HorizontalRecommendationRail from "./HorizontalRecommendationRail";

export default function SmartRecommendationHub() {
  const { activity, recentIds, searchPrefs } = useBuyerActivity();
  const { profile } = useAuth();
  const [seedProperty, setSeedProperty] = useState(null);

  const { data: properties = [], isLoading } = useQuery({
    queryKey: ["properties", "recommendations"],
    queryFn: async () => {
      const res = await api.get("/properties");
      return res.data || [];
    },
    staleTime: 60_000,
  });

  const savedIds = useMemo(
    () => (profile?.savedProperties || []).map(String),
    [profile?.savedProperties],
  );

  const ctx = useMemo(
    () => ({
      activity,
      searchPrefs,
    }),
    [activity, searchPrefs],
  );

  useEffect(() => {
    const firstId = recentIds[0];
    if (!firstId || !properties.length) {
      setSeedProperty(null);
      return;
    }
    const found = properties.find((p) => String(p._id || p.id) === String(firstId));
    setSeedProperty(found || null);
  }, [recentIds, properties]);

  const forYouPool = useMemo(
    () =>
      properties.filter((p) => !savedIds.includes(String(p._id || p.id))),
    [properties, savedIds],
  );

  const forYou = useMemo(() => {
    if (!forYouPool.length) return [];
    return buildForYouList(forYouPool, ctx, 14).map(({ property, tags }) => ({
      property,
      tags,
    }));
  }, [forYouPool, ctx]);

  const similar = useMemo(() => {
    if (!seedProperty) return [];
    return getSimilarProperties(seedProperty, properties, 12);
  }, [seedProperty, properties]);

  const because = useMemo(() => {
    if (!seedProperty) return [];
    return getBecauseYouViewed(seedProperty, properties, 12);
  }, [seedProperty, properties]);

  return (
    <div className="bg-gradient-to-b from-muted/30 via-background to-background border-y border-border/40">
      <HorizontalRecommendationRail
        title={<>Recommended for You</>}
        subtitle="Instantly ranked from your searches, saved homes, and cities you keep coming back to — tuned on the device, no server AI required."
        icon={Brain}
        items={forYou}
        loading={isLoading}
        emptyMessage="Explore properties and apply filters — your personalized rail will appear here."
      />

      <HorizontalRecommendationRail
        title={<>Similar Properties</>}
        subtitle={
          seedProperty
            ? `Aligned with ${seedProperty.city}, ${seedProperty.category || "your taste"}, and a comparable budget band.`
            : "Open any listing to unlock same-area, same-type matches."
        }
        icon={GitCompare}
        items={similar}
        loading={isLoading}
        emptyMessage="View a property detail page first — we’ll mirror its city, type, and price range."
        className="border-t border-border/30"
      />

      <HorizontalRecommendationRail
        title={
          <>
            Because you viewed{" "}
            {seedProperty ? (
              <span className="text-gradient-hero">{seedProperty.title?.slice(0, 32)}…</span>
            ) : (
              "…"
            )}
          </>
        }
        subtitle="A wider net: same city or category with flexible price — perfect for discovery."
        icon={Orbit}
        items={because}
        loading={isLoading}
        emptyMessage="Your last viewed home will drive this row — start browsing to see suggestions."
        className="border-t border-border/30 pb-4"
      />
    </div>
  );
}
