import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Building, Users, Calendar, DollarSign, TrendingUp, Home, 
  Activity, RefreshCw, Filter, BarChart3, ArrowUpRight,
  Eye, CheckCircle, AlertCircle, Zap
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useDashboardStats } from '@/hooks/useDashboardStats';
import { cn } from '@/lib/utils';

// Count-up animation component
const CountUp = ({ value, duration = 2000, prefix = '', suffix = '' }) => {
  const [displayValue, setDisplayValue] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const previousValue = useRef(0);

  useEffect(() => {
    if (value !== previousValue.current) {
      setIsAnimating(true);
      const startValue = previousValue.current;
      const endValue = value;
      const startTime = Date.now();

      const animate = () => {
        const now = Date.now();
        const progress = Math.min((now - startTime) / duration, 1);
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        const currentValue = Math.floor(startValue + (endValue - startValue) * easeOutQuart);
        
        setDisplayValue(currentValue);
        
        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setIsAnimating(false);
          previousValue.current = endValue;
        }
      };

      requestAnimationFrame(animate);
    }
  }, [value, duration]);

  return (
    <div className="relative">
      <span className={cn(
        "text-3xl font-display font-black tabular-nums",
        isAnimating && "text-primary"
      )}>
        {prefix}{displayValue.toLocaleString('en-IN')}{suffix}
      </span>
    </div>
  );
};

// Stat Card Component
const StatCard = ({ 
  title, 
  value, 
  icon: Icon, 
  change, 
  changeType = 'increase',
  color = 'blue',
  loading = false,
  prefix = '',
  suffix = ''
}) => {
  const colorClasses = {
    blue: 'from-blue-500/10 to-blue-500/5 border-blue-500/20',
    green: 'from-emerald-500/10 to-emerald-500/5 border-emerald-500/20',
    orange: 'from-orange-500/10 to-orange-500/5 border-orange-500/20',
    purple: 'from-purple-500/10 to-purple-500/5 border-purple-500/20'
  };

  const iconColorClasses = {
    blue: 'text-blue-500',
    green: 'text-emerald-500',
    orange: 'text-orange-500',
    purple: 'text-purple-500'
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -5, scale: 1.02 }}
      transition={{ duration: 0.3 }}
      className="group"
    >
      <Card className={cn(
        "relative overflow-hidden rounded-2xl border shadow-sm bg-gradient-to-br",
        colorClasses[color],
        "hover:shadow-lg transition-all duration-300"
      )}>
        <CardContent className="p-6">
          <div className="flex items-start justify-between mb-4">
            <div className={cn(
              "p-3 rounded-xl bg-white shadow-sm transition-transform group-hover:scale-110",
              iconColorClasses[color]
            )}>
              <Icon className="w-6 h-6" />
            </div>
            {change && (
              <Badge className={cn(
                "text-xs font-black px-2 py-1 rounded-full flex items-center gap-1",
                changeType === 'increase' 
                  ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                  : 'bg-red-500/10 text-red-500 border-red-500/20'
              )}>
                {changeType === 'increase' ? (
                  <TrendingUp className="w-3 h-3" />
                ) : (
                  <ArrowUpRight className="w-3 h-3 rotate-45" />
                )}
                {change}
              </Badge>
            )}
          </div>
          
          <div className="space-y-2">
            {loading ? (
              <div className="h-10 bg-muted/30 rounded-lg animate-pulse" />
            ) : (
              <CountUp 
                value={value} 
                prefix={prefix}
                suffix={suffix}
                duration={1500}
              />
            )}
            <p className="text-xs font-black text-muted-foreground uppercase tracking-widest">
              {title}
            </p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

// Revenue Chart Component (Simple Bar Chart)
const RevenueChart = ({ data, loading }) => {
  const maxRevenue = Math.max(...data.map(d => d.revenue || 0), 1);
  
  return (
    <Card className="rounded-2xl border shadow-sm">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="font-display text-lg font-black">Revenue Trend</CardTitle>
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Activity className="w-4 h-4" />
            Last 30 days
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        {loading ? (
          <div className="h-64 bg-muted/30 rounded-xl animate-pulse" />
        ) : data.length === 0 ? (
          <div className="h-64 flex items-center justify-center">
            <div className="text-center">
              <BarChart3 className="w-12 h-12 text-muted-foreground/20 mx-auto mb-3" />
              <p className="text-muted-foreground font-bold">No revenue data yet</p>
            </div>
          </div>
        ) : (
          <div className="h-64 flex items-end justify-between gap-2 px-2">
            {data.map((item, index) => (
              <motion.div
                key={item._id}
                initial={{ scaleY: 0 }}
                animate={{ scaleY: 1 }}
                transition={{ delay: index * 0.05, duration: 0.5 }}
                className="flex-1 flex flex-col items-center"
                style={{ origin: 'bottom' }}
              >
                <div 
                  className="w-full bg-gradient-to-t from-primary/80 to-primary rounded-t-lg transition-all hover:from-primary hover:to-primary"
                  style={{ 
                    height: `${(item.revenue / maxRevenue) * 100}%`,
                    minHeight: item.revenue > 0 ? '4px' : '0px'
                  }}
                />
                <p className="text-xs text-muted-foreground mt-2 tabular-nums">
                  {new Date(item._id).getDate()}
                </p>
              </motion.div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Main Dashboard Component
const DynamicDashboard = () => {
  const {
    stats,
    loading,
    error,
    revenueData,
    bookingTrends,
    timeFilter,
    refreshStats,
    updateTimeFilter,
    socket
  } = useDashboardStats();

  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await refreshStats();
    setIsRefreshing(false);
  };

  const statCards = [
    {
      title: 'Total Properties',
      value: stats.totalProperties,
      icon: Building,
      change: '+12%',
      changeType: 'increase',
      color: 'blue',
      loading: loading
    },
    {
      title: 'Total Users',
      value: stats.totalUsers,
      icon: Users,
      change: '+8%',
      changeType: 'increase',
      color: 'green',
      loading: loading
    },
    {
      title: 'Total Bookings',
      value: stats.totalBookings,
      icon: Calendar,
      change: '+15%',
      changeType: 'increase',
      color: 'orange',
      loading: loading
    },
    {
      title: 'Total Revenue',
      value: stats.totalRevenue,
      icon: DollarSign,
      change: '+22%',
      changeType: 'increase',
      color: 'purple',
      loading: loading,
      prefix: '₹'
    },
    {
      title: 'Active Listings',
      value: stats.activeListings,
      icon: Home,
      change: '+5%',
      changeType: 'increase',
      color: 'blue',
      loading: loading
    },
    {
      title: 'Sold Properties',
      value: stats.soldProperties,
      icon: CheckCircle,
      change: '+3%',
      changeType: 'increase',
      color: 'green',
      loading: loading
    }
  ];

  const hasData = Object.values(stats).some(value => value > 0);
  const connectionStatus = socket ? 'connected' : 'disconnected';

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="max-w-md p-8 text-center">
          <AlertCircle className="w-16 h-16 text-destructive mx-auto mb-4" />
          <h2 className="text-xl font-black mb-2">Dashboard Error</h2>
          <p className="text-muted-foreground mb-4">{error}</p>
          <Button onClick={handleRefresh} className="w-full">
            <RefreshCw className="w-4 h-4 mr-2" />
            Try Again
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-8">
        <div className="space-y-2">
          <h1 className="font-display text-3xl lg:text-4xl font-black text-foreground">
            PropNest Dashboard
          </h1>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                connectionStatus === 'connected' ? 'bg-emerald-500' : 'bg-red-500'
              )} />
              <span className="text-sm text-muted-foreground">
                {connectionStatus === 'connected' ? 'Live' : 'Offline'}
              </span>
            </div>
            <span className="text-sm text-muted-foreground">
              Last updated: {stats.lastUpdated ? new Date(stats.lastUpdated).toLocaleTimeString() : 'Never'}
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          <Select value={timeFilter} onValueChange={updateTimeFilter}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          
          <Button 
            variant="outline" 
            size="sm" 
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="rounded-xl"
          >
            <RefreshCw className={cn("w-4 h-4 mr-2", isRefreshing && "animate-spin")} />
            Refresh
          </Button>
          
          <Button 
            size="sm" 
            className="rounded-xl bg-gradient-hero text-white"
          >
            <Filter className="w-4 h-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* No Data State */}
      {!hasData && !loading && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center py-20"
        >
          <div className="max-w-md mx-auto">
            <div className="w-24 h-24 rounded-full bg-muted/20 flex items-center justify-center mx-auto mb-6">
              <Activity className="w-12 h-12 text-muted-foreground/30" />
            </div>
            <h2 className="font-display text-2xl font-black text-foreground mb-4">
              Welcome to PropNest Dashboard
            </h2>
            <p className="text-muted-foreground text-lg mb-8">
              Your dashboard is ready! Start adding properties, users, and bookings to see real-time statistics here.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 max-w-lg mx-auto">
              <div className="text-center p-6 rounded-xl bg-muted/10 border border-border/40">
                <Building className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
                <p className="text-sm font-bold text-muted-foreground">Add Properties</p>
              </div>
              <div className="text-center p-6 rounded-xl bg-muted/10 border border-border/40">
                <Users className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
                <p className="text-sm font-bold text-muted-foreground">Users Register</p>
              </div>
              <div className="text-center p-6 rounded-xl bg-muted/10 border border-border/40">
                <Calendar className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
                <p className="text-sm font-bold text-muted-foreground">Bookings Made</p>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* Stats Grid */}
      <AnimatePresence>
        {(hasData || loading) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="space-y-8"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {statCards.map((stat, index) => (
                <motion.div
                  key={stat.title}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <StatCard {...stat} />
                </motion.div>
              ))}
            </div>

            {/* Charts Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <RevenueChart data={revenueData} loading={loading} />
              
              <Card className="rounded-2xl border shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="font-display text-lg font-black">Quick Stats</CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Monthly Bookings</span>
                    <span className="text-sm font-bold text-primary">{stats.monthlyBookings}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Monthly Revenue</span>
                    <span className="text-sm font-bold text-emerald-600">₹{stats.monthlyRevenue?.toLocaleString('en-IN') || 0}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">Conversion Rate</span>
                    <span className="text-sm font-bold text-purple-600">
                      {stats.totalBookings > 0 ? Math.round((stats.soldProperties / stats.totalBookings) * 100) : 0}%
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Loading Skeleton */}
      {loading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-32 bg-muted/30 rounded-2xl animate-pulse" />
          ))}
        </div>
      )}
    </div>
  );
};

export default DynamicDashboard;
