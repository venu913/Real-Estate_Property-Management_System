import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import api from "@/services/api";
import PropertyCard from "@/components/PropertyCard";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";

export default function FeaturedProperties() {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const res = await api.get('/properties');
        setProperties(res.data);
      } catch (error) {
        console.error("Failed to fetch featured properties:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchFeatured();
  }, []);

  const featured = properties.filter((p) => p.featured || p.is_featured).slice(0, 4);
  // Fallback if no featured properties
  const displayProperties = featured.length > 0 ? featured : properties.slice(0, 4);

  return (
    <section className="py-24 md:py-32 bg-background relative overflow-hidden">
      {/* Decorative background element */}
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/5 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mb-16">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex items-center gap-2 mb-4"
          >
            <div className="w-8 h-px bg-primary" />
            <span className="text-primary font-black text-[10px] uppercase tracking-[0.3em] flex items-center gap-1.5">
              <Sparkles className="w-3 h-3" /> Handpicked Excellence
            </span>
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="flex flex-col md:flex-row md:items-end justify-between gap-6"
          >
            <h2 className="font-display text-4xl md:text-6xl font-black text-foreground leading-tight tracking-tighter">
              Featured <span className="text-gradient-hero">Collectibles.</span>
            </h2>
            <Link to="/properties">
              <Button
                variant="outline"
                className="group rounded-full px-8 h-12 border-primary/20 font-bold hover:bg-primary hover:text-white transition-all overflow-hidden relative"
              >
                <span className="relative z-10 flex items-center gap-2">
                  Browse Gallery <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </span>
              </Button>
            </Link>
          </motion.div>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="space-y-4">
                <div className="aspect-[16/11] bg-muted rounded-[2rem] animate-pulse" />
                <div className="space-y-2 px-4">
                  <div className="h-6 w-3/4 bg-muted rounded animate-pulse" />
                  <div className="h-4 w-1/2 bg-muted rounded animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {displayProperties.map((property, i) => (
              <PropertyCard key={property._id} property={property} index={i} />
            ))}
          </div>
        )}

        <motion.div 
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5 }}
          className="mt-20 text-center"
        >
          <p className="text-muted-foreground font-medium text-sm">
            Discover 500+ more premium options in our extended inventory. 
            <Link to="/properties" className="text-primary font-bold ml-1 hover:underline">Start Exploring</Link>
          </p>
        </motion.div>
      </div>
    </section>
  );
}
