import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { useBuyerActivity } from "@/contexts/BuyerActivityContext";

const SESSION_KEY = "propnest_live_toasts_v1";

export default function SimulatedLiveNotifications() {
  const { onboarding } = useBuyerActivity();
  const ran = useRef(false);

  useEffect(() => {
    if (ran.current) return;
    try {
      if (sessionStorage.getItem(SESSION_KEY)) return;
    } catch {
      /* ignore */
    }
    ran.current = true;

    const city = onboarding?.city || "Mumbai";
    const t1 = window.setTimeout(() => {
      toast.message("New property alert", {
        description: `A ${onboarding?.propertyType || "3 BHK"} in ${city} matches your filters.`,
        duration: 6500,
      });
      try {
        sessionStorage.setItem(SESSION_KEY, "1");
      } catch {
        /* ignore */
      }
    }, 9000);

    const t2 = window.setTimeout(() => {
      toast.info("Market pulse", {
        description: "12 new listings went live near prime corridors in the last 2 hours.",
        duration: 5500,
      });
    }, 24000);

    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [onboarding?.city, onboarding?.propertyType]);

  return null;
}
