import { useMemo, useEffect } from "react";
import { MapContainer, TileLayer, Marker, Popup, useMapEvents, useMap } from "react-leaflet";
import { MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import { getPropertyLatLng } from "@/lib/propertyGeo";
import { fixLeafletDefaultIcons } from "./leafletIcons";
import "leaflet/dist/leaflet.css";

function MapUpdater({ position, zoom }) {
  const map = useMap();
  useEffect(() => {
    if (position) map.setView(position, zoom ?? map.getZoom(), { animate: true });
  }, [position, zoom, map]);
  return null;
}

function LocationPicker({ onLocationSelect }) {
  useMapEvents({
    click(e) {
      if (onLocationSelect) {
        onLocationSelect(e.latlng.lat, e.latlng.lng);
      }
    },
  });
  return null;
}

export default function PropertyMiniMap({ property, className, onLocationSelect, draggable = false }) {
  fixLeafletDefaultIcons();

  const hasExactLocation = !!(property?.latitude && property?.longitude);

  const position = useMemo(() => {
    if (hasExactLocation) {
      return [property.latitude, property.longitude];
    }
    return getPropertyLatLng(property);
  }, [property, hasExactLocation]);

  const zoom = hasExactLocation ? 14 : 5;

  if (!property || !position) return null;

  return (
    <div
      className={cn(
        "rounded-[2rem] overflow-hidden border border-border/40 bg-muted shadow-inner",
        className,
      )}
    >
      <div className="flex items-center gap-2 px-6 pt-6 pb-2">
        <MapPin className="w-5 h-5 text-primary shrink-0" />
        <h3 className="font-display font-bold text-lg text-foreground">Location</h3>
      </div>
      <div className="px-4 pb-4">
        <MapContainer
          center={position}
          zoom={zoom}
          className="h-56 w-full rounded-2xl z-0 [&_.leaflet-control-attribution]:text-[9px]"
          scrollWheelZoom={false}
        >
          <TileLayer
            attribution='&copy; OpenStreetMap'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          <MapUpdater position={position} zoom={zoom} />
          {onLocationSelect && <LocationPicker onLocationSelect={onLocationSelect} />}
          {hasExactLocation ? (
            <Marker 
              position={position}
              draggable={draggable}
              eventHandlers={{
                dragend: (e) => {
                  const marker = e.target;
                  const pos = marker.getLatLng();
                  if (onLocationSelect) onLocationSelect(pos.lat, pos.lng);
                }
              }}
            >
              <Popup className="font-sans text-sm font-semibold">{property.title || "Selected Location"}</Popup>
            </Marker>
          ) : (
            <Marker 
              position={position}
              draggable={draggable}
              opacity={0.6}
              eventHandlers={{
                dragend: (e) => {
                  const marker = e.target;
                  const pos = marker.getLatLng();
                  if (onLocationSelect) onLocationSelect(pos.lat, pos.lng);
                }
              }}
            >
              <Popup className="font-sans text-sm font-semibold">Center of India. Click anywhere to set exact location!</Popup>
            </Marker>
          )}
        </MapContainer>
        <p className="text-[11px] text-muted-foreground mt-2 px-2">
          {draggable ? "Click on the map or drag the pin to set the exact location." : "Approximate map position; verify on site visit."}
        </p>
      </div>
    </div>
  );
}
