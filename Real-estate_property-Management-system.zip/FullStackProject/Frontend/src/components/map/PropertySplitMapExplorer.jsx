import { useMemo, useState, useCallback, useEffect } from "react";
import { Link } from "react-router-dom";
import { MapPin, LayoutGrid, Map as MapIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";

function formatPriceShort(price) {
  if (!price && price !== 0) return "—";
  if (price >= 10000000) return `₹${(price / 10000000).toFixed(2)} Cr`;
  if (price >= 100000) return `₹${(price / 100000).toFixed(2)} L`;
  return `₹${Number(price).toLocaleString("en-IN")}`;
}

/** Deterministic pseudo positions for map simulation (0–100%). */
function markerStyle(index, total) {
  const cols = Math.min(5, Math.max(1, Math.ceil(Math.sqrt(total))));
  const rows = Math.ceil(total / cols);
  const row = Math.floor(index / cols);
  const col = index % cols;
  const padX = 14;
  const padY = 12;
  const cellW = (100 - 2 * padX) / cols;
  const cellH = (100 - 2 * padY) / rows;
  const jitter = ((index * 17) % 7) - 3;
  const left = padX + col * cellW + cellW / 2 + jitter * 0.4;
  const top = padY + row * cellH + cellH / 2 + ((index * 11) % 5) * 0.5;
  return {
    left: `${clamp(left, 8, 92)}%`,
    top: `${clamp(top, 8, 88)}%`,
  };
}

function clamp(n, a, b) {
  return Math.min(b, Math.max(a, n));
}

export default function PropertySplitMapExplorer({ properties = [], className }) {
  const [selectedId, setSelectedId] = useState(() =>
    properties[0]?._id ? String(properties[0]._id) : null,
  );
  const [mobilePane, setMobilePane] = useState("list");

  const ids = useMemo(
    () => properties.map((p) => String(p._id || p.id)).join(","),
    [properties],
  );

  useEffect(() => {
    if (!properties.length) {
      setSelectedId(null);
      return;
    }
    const first = String(properties[0]._id || properties[0].id);
    setSelectedId((prev) => {
      if (prev && properties.some((p) => String(p._id || p.id) === prev)) return prev;
      return first;
    });
  }, [ids, properties]);

  const select = useCallback((id) => {
    setSelectedId(String(id));
    setMobilePane("map");
  }, []);

  return (
    <div className={cn("flex flex-col gap-3", className)}>
      <div className="flex md:hidden items-center gap-2 rounded-xl border border-border p-1 bg-muted/30">
        <Button
          type="button"
          variant={mobilePane === "list" ? "secondary" : "ghost"}
          size="sm"
          className="flex-1 rounded-lg font-bold text-xs gap-2"
          onClick={() => setMobilePane("list")}
        >
          <LayoutGrid className="w-4 h-4" />
          List
        </Button>
        <Button
          type="button"
          variant={mobilePane === "map" ? "secondary" : "ghost"}
          size="sm"
          className="flex-1 rounded-lg font-bold text-xs gap-2"
          onClick={() => setMobilePane("map")}
        >
          <MapIcon className="w-4 h-4" />
          Map
        </Button>
      </div>

      <div
        className={cn(
          "grid grid-cols-1 md:grid-cols-2 gap-4 min-h-[min(520px,calc(100vh-12rem))]",
          mobilePane === "list" && "max-md:[&>div:last-child]:hidden",
          mobilePane === "map" && "max-md:[&>div:first-child]:hidden",
        )}
      >
        <div className="flex flex-col rounded-2xl border border-border/60 bg-card overflow-hidden shadow-sm min-h-[320px] md:min-h-0">
          <div className="px-4 py-3 border-b border-border/50 bg-muted/20">
            <p className="text-xs font-black uppercase tracking-widest text-muted-foreground">
              {properties.length} listings
            </p>
          </div>
          <ScrollArea className="flex-1 h-[min(480px,55vh)] md:h-full md:max-h-[calc(100vh-14rem)]">
            <ul className="p-2 space-y-1">
              {properties.map((p) => {
                const id = String(p._id || p.id);
                const active = selectedId === id;
                return (
                  <li key={id}>
                    <button
                      type="button"
                      onClick={() => select(id)}
                      className={cn(
                        "w-full text-left rounded-xl px-3 py-3 transition-all border",
                        active
                          ? "bg-primary/10 border-primary/40 shadow-sm ring-2 ring-primary/20"
                          : "bg-card border-transparent hover:bg-muted/50 hover:border-border/60",
                      )}
                    >
                      <div className="flex gap-3">
                        <div className="w-20 h-16 rounded-lg overflow-hidden shrink-0 bg-muted">
                          <img
                            src={p.image || p.images?.[0]}
                            alt=""
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="min-w-0 flex-1">
                          <p className="font-bold text-sm text-foreground line-clamp-2 leading-snug">
                            {p.title}
                          </p>
                          <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                            <MapPin className="w-3 h-3 shrink-0" />
                            {p.city}
                          </p>
                          <p className="text-sm font-black text-primary mt-1 tabular-nums">
                            {formatPriceShort(p.price)}
                          </p>
                        </div>
                      </div>
                    </button>
                  </li>
                );
              })}
            </ul>
          </ScrollArea>
        </div>

        <div className="relative rounded-2xl border border-border/60 overflow-hidden bg-muted min-h-[280px] md:min-h-0 shadow-inner">
          <div
            className="absolute inset-0 opacity-90"
            style={{
              background:
                "linear-gradient(160deg, hsl(var(--muted)) 0%, hsl(210 25% 88%) 40%, hsl(160 20% 85%) 100%)",
            }}
          />
          <div
            className="absolute inset-0 opacity-[0.12]"
            style={{
              backgroundImage: `
                linear-gradient(hsl(var(--foreground) / 0.15) 1px, transparent 1px),
                linear-gradient(90deg, hsl(var(--foreground) / 0.15) 1px, transparent 1px)
              `,
              backgroundSize: "28px 28px",
            }}
          />
          <div className="absolute top-3 left-3 right-3 flex items-start justify-between gap-2 z-10">
            <Badge variant="secondary" className="text-[10px] font-black uppercase tracking-wide bg-card/90 backdrop-blur">
              Map preview
            </Badge>
            {selectedId && (
              <Button asChild size="sm" variant="secondary" className="h-8 text-xs font-bold rounded-lg shadow-md">
                <Link to={`/property/${selectedId}`}>Open listing</Link>
              </Button>
            )}
          </div>

          <div className="absolute inset-0 z-[5]">
            {properties.map((p, i) => {
              const id = String(p._id || p.id);
              const active = selectedId === id;
              const pos = markerStyle(i, properties.length);
              return (
                <button
                  key={id}
                  type="button"
                  title={p.title}
                  onClick={() => setSelectedId(id)}
                  className={cn(
                    "absolute w-4 h-4 rounded-full border-[3px] border-white shadow-lg -translate-x-1/2 -translate-y-1/2 transition-all duration-200",
                    active
                      ? "bg-primary scale-[1.35] ring-4 ring-primary/35 z-20"
                      : "bg-primary/80 hover:bg-primary hover:scale-110 z-10",
                  )}
                  style={{ left: pos.left, top: pos.top }}
                />
              );
            })}
          </div>

          <p className="absolute bottom-3 left-3 right-3 text-[10px] text-muted-foreground font-medium z-10 bg-card/80 backdrop-blur rounded-lg px-2 py-1.5 border border-border/40">
            Simulated map — pin layout is illustrative. Use Map view for real coordinates.
          </p>
        </div>
      </div>
    </div>
  );
}
