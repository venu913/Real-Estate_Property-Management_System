import { useEffect, useMemo, useState, useCallback } from "react";
import { MapContainer, TileLayer, Marker, Popup, CircleMarker, useMap } from "react-leaflet";
import { Link } from "react-router-dom";
import L from "leaflet";
import { MapPin, Navigation, Radio, LocateFixed } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { getPropertyLatLng, getBoundsCenter } from "@/lib/propertyGeo";
import { fixLeafletDefaultIcons } from "./leafletIcons";
import "leaflet/dist/leaflet.css";

function FitListingMarkers({ positions, fitKey }) {
  const map = useMap();
  useEffect(() => {
    if (!positions.length) return;
    const bounds = L.latLngBounds(positions);
    if (!bounds.isValid()) return;
    map.fitBounds(bounds, { padding: [40, 40], maxZoom: 14, animate: true });
  }, [map, fitKey, positions]);
  return null;
}

function FlyToUserOnce({ userLocation, flyNonce }) {
  const map = useMap();
  useEffect(() => {
    if (!userLocation || flyNonce === 0) return;
    map.flyTo(userLocation, 14, { duration: 0.7 });
  }, [map, userLocation, flyNonce]);
  return null;
}

function formatPrice(amount) {
  if (!amount && amount !== 0) return "—";
  if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(2)} Cr`;
  if (amount >= 100000) return `₹${(amount / 100000).toFixed(2)} L`;
  return `₹${amount.toLocaleString("en-IN")}`;
}

export default function PropertiesLiveMap({
  properties = [],
  className,
  userLocation,
  onUserLocation,
  fitKey,
}) {
  fixLeafletDefaultIcons();

  const markers = useMemo(() => {
    return properties
      .map((p) => {
        const ll = getPropertyLatLng(p);
        if (!ll) return null;
        return { property: p, position: ll, id: String(p._id || p.id) };
      })
      .filter(Boolean);
  }, [properties]);

  const positions = useMemo(() => markers.map((m) => m.position), [markers]);

  const initialCenter = useMemo(() => {
    if (positions.length) return getBoundsCenter(properties);
    return [20.5937, 78.9629];
  }, [positions.length, properties]);

  const [watchId, setWatchId] = useState(null);
  const [flyNonce, setFlyNonce] = useState(0);

  const stopWatching = useCallback(() => {
    if (watchId != null) {
      navigator.geolocation.clearWatch(watchId);
      setWatchId(null);
    }
  }, [watchId]);

  useEffect(() => () => stopWatching(), [stopWatching]);

  const requestLocation = useCallback(
    (watch = false) => {
      if (!navigator.geolocation) return;
      const onSuccess = (pos) => {
        const next = [pos.coords.latitude, pos.coords.longitude];
        onUserLocation?.(next);
        if (!watch) setFlyNonce((n) => n + 1);
      };
      const onErr = () => {};
      if (watch) {
        stopWatching();
        const id = navigator.geolocation.watchPosition(onSuccess, onErr, {
          enableHighAccuracy: true,
          maximumAge: 5000,
          timeout: 15000,
        });
        setWatchId(id);
      } else {
        navigator.geolocation.getCurrentPosition(onSuccess, onErr, {
          enableHighAccuracy: true,
          timeout: 12000,
        });
      }
    },
    [onUserLocation, stopWatching],
  );

  const userIcon = useMemo(
    () =>
      L.divIcon({
        className: "propnest-user-dot",
        html: `<div style="width:18px;height:18px;border-radius:9999px;background:#2563eb;border:3px solid white;box-shadow:0 0 0 2px #2563eb,0 4px 12px rgba(0,0,0,.35);"></div>`,
        iconSize: [18, 18],
        iconAnchor: [9, 9],
      }),
    [],
  );

  const boundsKey = fitKey ?? `${positions.length}-${positions.map((p) => p.join(",")).join("|")}`;

  return (
    <div
      className={cn(
        "relative rounded-2xl border border-border/60 overflow-hidden bg-muted shadow-inner",
        className,
      )}
    >
      <div className="absolute top-3 left-3 right-3 z-[500] flex flex-wrap gap-2 pointer-events-none">
        <div className="pointer-events-auto flex flex-wrap gap-2">
          <Button
            type="button"
            size="sm"
            variant="secondary"
            className="rounded-full shadow-md font-bold gap-2 h-9 bg-card/95 backdrop-blur"
            onClick={() => requestLocation(false)}
          >
            <LocateFixed className="w-4 h-4" />
            My location
          </Button>
          <Button
            type="button"
            size="sm"
            variant={watchId != null ? "default" : "secondary"}
            className={cn(
              "rounded-full shadow-md font-bold gap-2 h-9 bg-card/95 backdrop-blur",
              watchId != null && "bg-primary",
            )}
            onClick={() => (watchId != null ? stopWatching() : requestLocation(true))}
          >
            <Radio className={cn("w-4 h-4", watchId != null && "animate-pulse")} />
            {watchId != null ? "Stop live" : "Live tracking"}
          </Button>
        </div>
      </div>

      <MapContainer
        center={initialCenter}
        zoom={11}
        className="h-[min(520px,55vh)] w-full z-0 [&_.leaflet-control-attribution]:text-[10px]"
        scrollWheelZoom
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <FitListingMarkers positions={positions} fitKey={boundsKey} />
        <FlyToUserOnce userLocation={userLocation} flyNonce={flyNonce} />
        {markers.map(({ property, position, id }) => (
          <Marker key={id} position={position}>
            <Popup className="font-sans">
              <div className="min-w-[200px] space-y-2 py-1">
                <p className="font-bold text-sm leading-tight line-clamp-2">{property.title}</p>
                <p className="text-xs text-muted-foreground flex items-center gap-1">
                  <MapPin className="w-3 h-3 shrink-0" />
                  {property.city}
                </p>
                <p className="text-sm font-black text-primary">{formatPrice(property.price)}</p>
                <Button asChild size="sm" className="w-full rounded-lg h-8 text-xs font-bold">
                  <Link to={`/property/${id}`}>View listing</Link>
                </Button>
              </div>
            </Popup>
          </Marker>
        ))}
        {userLocation && (
          <Marker position={userLocation} icon={userIcon}>
            <Popup>You are here{watchId != null ? " (live)" : ""}</Popup>
          </Marker>
        )}
        {userLocation && (
          <CircleMarker
            center={userLocation}
            radius={watchId != null ? 90 : 60}
            pathOptions={{
              color: "#2563eb",
              fillColor: "#3b82f6",
              fillOpacity: 0.12,
              weight: 1,
            }}
          />
        )}
      </MapContainer>

      <div className="absolute bottom-2 left-2 right-2 z-[500] pointer-events-none">
        <p className="text-[10px] font-medium text-muted-foreground bg-card/90 backdrop-blur rounded-lg px-2 py-1 inline-block shadow-sm">
          <Navigation className="w-3 h-3 inline mr-1 align-middle" />
          Live location uses your browser; pins use listing coordinates from PropNest.
        </p>
      </div>
    </div>
  );
}
