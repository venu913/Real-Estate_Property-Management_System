import { motion, AnimatePresence } from "framer-motion";
import { Search, MapPin, Home, ChevronDown, Building2, Layout, Landmark, Zap, ArrowRight, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { cities, propertyTypes } from "@/lib/data";
import heroBg from "@/assets/hero-bg.jpg";

export default function HeroSection() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("buy");
  const [searchValue, setSearchValue] = useState("");
  const [city, setCity] = useState("Delhi");
  const [type, setType] = useState("");
  const [isFocused, setIsFocused] = useState(false);

  const tabs = [
    { key: "buy", label: "Buy", icon: Home },
    { key: "rent", label: "Rent", icon: Layout },
    { key: "commercial", label: "Commercial", icon: Landmark },
  ];

  const popularCities = ["Delhi", "Mumbai", "Bangalore", "Pune", "Hyderabad"];

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background with advanced overlay */}
      <div className="absolute inset-0">
        <motion.img
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.5, ease: "easeOut" }}
          src={heroBg}
          alt="Premium Real Estate"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/40 to-black/90" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,rgba(0,0,0,0.4)_100%)]" />
      </div>

      <div className="relative z-10 container mx-auto px-4 pt-20 pb-64">
        <div className="flex flex-col items-center text-center max-w-5xl mx-auto">
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 px-4 py-2 rounded-full border border-white/10 bg-white/5 backdrop-blur-md text-primary-foreground text-[10px] font-black uppercase tracking-[0.2em] mb-8 shadow-hero"
          >
            <ShieldCheck className="w-4 h-4 text-primary" />
            India's Most Trusted Housing Network
          </motion.div>

          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="font-display text-5xl sm:text-7xl lg:text-8xl font-black text-white leading-[1.1] mb-8 tracking-tighter"
          >
            Elevate Your <span className="text-gradient-hero italic">Living</span> <br />
            <span className="text-white/90">Standard.</span>
          </motion.h1>

          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-white/60 text-lg lg:text-xl max-w-2xl mx-auto mb-12 font-medium leading-relaxed"
          >
            Discover exclusive residential and commercial masterpieces across 
            India's prime locations. Your journey to a premium lifestyle starts here.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="w-full max-w-4xl"
          >
            {/* Premium Tabbed Interface */}
            <div className={`relative bg-background/95 backdrop-blur-2xl rounded-[2.5rem] shadow-[0_32px_64px_-16px_rgba(0,0,0,0.5)] border border-white/10 overflow-hidden transition-all duration-500 ${isFocused ? 'ring-8 ring-primary/10 scale-[1.02]' : ''}`}>
              
              <div className="flex px-4 md:px-8 pt-4 border-b border-white/5">
                {tabs.map((tab) => (
                  <button
                    key={tab.key}
                    onClick={() => setActiveTab(tab.key)}
                    className={`flex items-center gap-2.5 px-6 py-4 text-sm font-bold transition-all relative ${
                      activeTab === tab.key
                        ? "text-primary"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <tab.icon className={`w-4 h-4 ${activeTab === tab.key ? 'text-primary' : 'text-muted-foreground/50'}`} />
                    {tab.label}
                    {activeTab === tab.key && (
                      <motion.div
                        layoutId="activeTabHero"
                        className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-hero rounded-t-full"
                      />
                    )}
                  </button>
                ))}
              </div>

              <div className="p-4 md:p-8">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="flex-[1.5] relative group">
                    <MapPin className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-primary transition-transform group-focus-within:scale-110" />
                    <select
                      value={city}
                      onChange={(e) => setCity(e.target.value)}
                      onFocus={() => setIsFocused(true)}
                      onBlur={() => setIsFocused(false)}
                      className="w-full h-16 pl-14 pr-10 rounded-2xl bg-muted/50 border-white/5 text-base font-bold text-foreground focus:bg-background transition-all outline-none appearance-none"
                    >
                      {cities.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50 pointer-events-none" />
                  </div>

                  <div className="flex-1 relative group">
                    <Building2 className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-primary/70 transition-transform group-focus-within:scale-110" />
                    <select
                      value={type}
                      onChange={(e) => setType(e.target.value)}
                      onFocus={() => setIsFocused(true)}
                      onBlur={() => setIsFocused(false)}
                      className="w-full h-16 pl-14 pr-10 rounded-2xl bg-muted/50 border-white/5 text-base font-bold text-foreground focus:bg-background transition-all outline-none appearance-none"
                    >
                      <option value="">Property Type</option>
                      {propertyTypes.map((t) => (
                        <option key={t} value={t}>
                          {t}
                        </option>
                      ))}
                    </select>
                    <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground/50 pointer-events-none" />
                  </div>

                  <Button
                    onClick={() => navigate("/properties")}
                    className="h-16 px-10 bg-gradient-hero text-primary-foreground shadow-hero rounded-2xl font-black text-lg uppercase tracking-wider hover:scale-105 active:scale-95 transition-all lg:w-auto"
                  >
                    <Search className="w-5 h-5 mr-3" /> Find Assets
                  </Button>
                </div>
              </div>
            </div>

            {/* Micro-interactions: Popular Cities */}
            <div className="flex flex-wrap justify-center items-center gap-6 mt-12">
              <span className="text-white/40 text-[10px] font-black uppercase tracking-widest">Trending Hubs:</span>
              <div className="flex flex-wrap justify-center gap-3">
                {popularCities.map((c, i) => (
                  <motion.button
                    whileHover={{ y: -2 }}
                    key={c}
                    onClick={() => setCity(c)}
                    className={`px-4 py-2 rounded-full text-xs font-bold transition-all border ${
                      city === c 
                        ? 'bg-primary text-primary-foreground border-primary shadow-hero' 
                        : 'bg-white/5 text-white/50 border-white/5 hover:border-white/20 hover:text-white'
                    }`}
                  >
                    {c}
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Hero Stats */}
      <div className="absolute bottom-10 left-0 right-0 hidden md:block">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center bg-black/20 backdrop-blur-md rounded-[2rem] border border-white/5 p-8">
            {[
              { value: "45K+", label: "Premium Listings", icon: Zap },
              { value: "120+", label: "Top Developers", icon: Building2 },
              { value: "15K+", label: "Verified Reviews", icon: ShieldCheck },
              { value: "98%", label: "Success Rate", icon: TrendingUp },
            ].map((stat, i) => (
              <div key={i} className="flex items-center gap-5">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <stat.icon className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-display font-black text-white leading-none">{stat.value}</p>
                  <p className="text-[10px] font-bold text-white/40 uppercase tracking-widest mt-1">{stat.label}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function TrendingUp(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <polyline points="22 7 13.5 15.5 8.5 10.5 2 17" />
      <polyline points="16 7 22 7 22 13" />
    </svg>
  );
}
