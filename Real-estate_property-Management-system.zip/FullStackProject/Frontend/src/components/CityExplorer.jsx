import { motion } from "framer-motion";
import { cities } from "@/lib/data";
import { MapPin } from "lucide-react";

const cityImages = {
  Mumbai: "https://images.unsplash.com/photo-1570168007204-dfb528c6958f?w=400",
  Bangalore:
    "https://images.unsplash.com/photo-1596176530529-78163a4f7af2?w=400",
  Delhi: "https://images.unsplash.com/photo-1587474260584-136574528ed5?w=400",
  Hyderabad: "/images/hyderabad.png",
  Gurugram:
    "https://images.unsplash.com/photo-1524813686514-a57563d77965?w=400",
  Pune: "/images/pune.png",
  Chennai: "https://images.unsplash.com/photo-1582510003544-4d00b7f74220?w=400",
  Kolkata: "https://images.unsplash.com/photo-1558431382-27e303142255?w=400",
};

const propertyCount = {
  Mumbai: "2,400+",
  Bangalore: "1,800+",
  Delhi: "1,500+",
  Hyderabad: "1,200+",
  Gurugram: "900+",
  Pune: "1,100+",
  Chennai: "800+",
  Kolkata: "600+",
};

export default function CityExplorer() {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <p className="text-primary font-semibold text-sm uppercase tracking-wider mb-2">
            Explore by City
          </p>
          <h2 className="font-display text-3xl lg:text-4xl font-bold text-foreground">
            Top Cities in India
          </h2>
        </motion.div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {cities.map((city, i) => (
            <motion.a
              key={city}
              href="#"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              whileHover={{ y: -5 }}
              className="group relative rounded-2xl overflow-hidden aspect-[4/3]"
            >
              <img
                src={cityImages[city] || ""}
                alt={city}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />

              <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/20 to-transparent" />
              <div className="absolute bottom-4 left-4">
                <h3 className="font-display text-lg font-bold text-primary-foreground flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-primary" />
                  {city}
                </h3>
                <p className="text-primary-foreground/60 text-sm">
                  {propertyCount[city]} Properties
                </p>
              </div>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
