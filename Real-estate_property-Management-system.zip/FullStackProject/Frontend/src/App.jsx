import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { BuyerActivityProvider } from "@/contexts/BuyerActivityContext";
import { CompareProvider } from "@/contexts/CompareContext";
import CompareDock from "@/components/buyer/CompareDock";
import Compare from "./pages/Compare";
import RequireAuth from "@/components/routing/RequireAuth";
import RequireAgent from "@/components/routing/RequireAgent";
import RoleSwitcher from "@/components/dev/RoleSwitcher";
import AgentLayout from "@/pages/agent/AgentLayout";
import DashboardOverview from "@/components/agent/DashboardOverview";
import PropertyManager from "@/components/agent/PropertyManager";
import LeadTracker from "@/components/agent/LeadTracker";
import AgentProfileSettings from "@/components/agent/AgentProfileSettings";
import AgentMessages from "@/components/agent/AgentMessages";
import AgentAnalyticsDashboard from "@/components/agent/AgentAnalyticsDashboard";
import Index from "./pages/Index";
import Properties from "./pages/Properties";
import PropertyDetail from "./pages/PropertyDetail";
import About from "./pages/About";
import Contact from "./pages/Contact";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";
import Profile from "./pages/Profile";
import SavedProperties from "./pages/SavedProperties";
import AgentDashboard from "./pages/AgentDashboard";
import DynamicDashboardPage from "./pages/DynamicDashboard";
import BuyerDashboard from "./pages/BuyerDashboard";
import BuyerMessages from "./pages/BuyerMessages";
import BuyerRequests from "./pages/BuyerRequests";
import BuyerSchedules from "./pages/BuyerSchedules";
import TenantLeases from "./pages/TenantLeases";
import PostProperty from "./pages/PostProperty";
import NotFound from "./pages/NotFound";
import PageFadeLayout from "@/components/layout/PageFadeLayout";
import SimulatedLiveNotifications from "@/components/live/SimulatedLiveNotifications";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
        <AuthProvider>
          <BuyerActivityProvider>
            <CompareProvider>
            <>
            <SimulatedLiveNotifications />
            <Routes>
              <Route element={<PageFadeLayout />}>
                <Route path="/" element={<Index />} />
                <Route path="/properties" element={<Properties />} />
                <Route path="/property/:id" element={<PropertyDetail />} />
                <Route path="/compare" element={<Compare />} />
                <Route path="/about" element={<About />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/login" element={<Login />} />
                <Route path="/signup" element={<Signup />} />
                <Route path="/forgot-password" element={<ForgotPassword />} />
                <Route path="/reset-password" element={<ResetPassword />} />
                <Route path="/profile" element={<Profile />} />
                <Route path="/saved" element={<SavedProperties />} />
                <Route
                  path="/buyer/dashboard"
                  element={
                    <RequireAuth>
                      <BuyerDashboard />
                    </RequireAuth>
                  }
                />
                <Route
                  path="/buyer/messages"
                  element={
                    <RequireAuth>
                      <BuyerMessages />
                    </RequireAuth>
                  }
                />
                <Route
                  path="/buyer/requests"
                  element={
                    <RequireAuth>
                      <BuyerRequests />
                    </RequireAuth>
                  }
                />
                <Route
                  path="/buyer/schedules"
                  element={
                    <RequireAuth>
                      <BuyerSchedules />
                    </RequireAuth>
                  }
                />
                <Route
                  path="/tenant/leases"
                  element={
                    <RequireAuth>
                      <TenantLeases />
                    </RequireAuth>
                  }
                />
                <Route path="/agent-dashboard" element={<AgentDashboard />} />
                <Route path="/dashboard" element={<DynamicDashboardPage />} />
                <Route
                  path="/post-property"
                  element={
                    <RequireAgent>
                      <PostProperty />
                    </RequireAgent>
                  }
                />
                <Route
                  path="/agent"
                  element={
                    <RequireAgent>
                      <AgentLayout />
                    </RequireAgent>
                  }
                >
                  <Route index element={<DashboardOverview />} />
                  <Route path="listings" element={<PropertyManager />} />
                  <Route path="add-property" element={<PostProperty />} />
                  <Route path="leads" element={<LeadTracker />} />
                  <Route path="messages" element={<AgentMessages />} />
                  <Route path="analytics" element={<AgentAnalyticsDashboard />} />
                  <Route path="profile" element={<AgentProfileSettings />} />
                </Route>
                <Route path="*" element={<NotFound />} />
              </Route>
            </Routes>
            <CompareDock />
            <RoleSwitcher />
            </>
            </CompareProvider>
          </BuyerActivityProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
