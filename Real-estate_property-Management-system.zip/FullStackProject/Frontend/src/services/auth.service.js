import api from './api';

export const authService = {
  login: async (credentials) => {
    const response = await api.post('/auth/login', credentials);
    return response.data;
  },
  signup: async (userData) => {
    const response = await api.post('/auth/signup', userData);
    return response.data;
  },
  me: async () => {
    const response = await api.get('/auth/me');
    return response.data;
  },
  toggleSaveProperty: async (propertyId) => {
    const response = await api.post(`/auth/favorites/toggle/${propertyId}`);
    return response.data;
  },
  getSavedProperties: async () => {
    const response = await api.get('/auth/favorites');
    return response.data;
  }
};
