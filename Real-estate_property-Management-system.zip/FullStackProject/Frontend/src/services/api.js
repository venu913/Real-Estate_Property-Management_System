import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
});

// Add a request interceptor to attach JWT token
api.interceptors.request.use(
  (config) => {
    const token =
      typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Dashboard API functions
export const dashboardAPI = {
  getStats: () => api.get('/dashboard/stats'),
  getRevenue: (period = '30d') => api.get(`/dashboard/revenue?period=${period}`),
  getBookingTrends: (period = '30d') => api.get(`/dashboard/bookings/trends?period=${period}`),
};

export default api;
