const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ headless: "new" });
  const page = await browser.newPage();
  
  page.on('pageerror', err => {
    console.error('PAGE ERROR:', err.toString());
  });

  page.on('console', msg => {
    if (msg.type() === 'error') {
      console.error('CONSOLE ERROR:', msg.text());
    }
  });

  console.log('Navigating to /properties...');
  await page.goto('http://localhost:5173/properties');
  await page.waitForSelector('a[href="/"]');
  
  console.log('Clicking Home...');
  await page.click('a[href="/"]');
  
  // wait a bit for error to occur
  await new Promise(r => setTimeout(r, 2000));
  
  console.log('Done');
  await browser.close();
})();
