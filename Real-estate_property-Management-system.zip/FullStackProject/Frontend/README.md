# 🏠 PropNest - Modern Real Estate Platform

PropNest is a premium, full-featured real estate platform built with React and Vite. It offers a seamless experience for users to find, explore, and manage property listings with a high-end, responsive design.

![PropNest Banner](https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&q=80&w=1200&h=400)

## ✨ Features

- **🔍 Advanced Property Discovery**: Browse and filter properties by category, price, and location.
- **🌆 City Explorer**: Discover properties curated by popular cities.
- **🔐 Secure Authentication**: Full authentication suite including Signup, Login, Password Recovery, and JWT-based session management.
- **👤 User Profiles**: Manage personal information, property listings, and saved favorites.
- **📊 Agent Dashboard**: Specialized interface for real estate agents to manage their listings.
- **💖 Favorites System**: Save properties to your watchlist for easy access later.
- **📱 Responsive Design**: Fully optimized for mobile, tablet, and desktop viewing.
- **✨ Premium UI/UX**: Smooth animations using Framer Motion and modern components from Shadcn UI.

## 🚀 Tech Stack

- **Frontend Core**: [React 18](https://reactjs.org/) with [Vite](https://vitejs.dev/)
- **Styling**: [Tailwind CSS](https://tailwindcss.com/)
- **UI Components**: [Shadcn UI](https://ui.shadcn.com/) & [Lucide React](https://lucide.dev/)
- **Animations**: [Framer Motion](https://www.framer.com/motion/)
- **Routing**: [React Router Dom v6](https://reactrouter.com/)
- **State Management & Data Fetching**: [TanStack Query (React Query)](https://tanstack.com/query/latest)
- **Form Handling**: [React Hook Form](https://react-hook-form.com/) & [Zod](https://zod.dev/)
- **API Interactivity**: [Axios](https://axios-http.com/)

## 🛠️ Getting Started

### Prerequisites

- [Node.js](https://nodejs.org/) (v18 or higher)
- [npm](https://www.npmjs.com/) or [yarn](https://yarnpkg.com/)

### Installation

1. Clone the repository:
   ```bash
   git clone <repository-url>
   ```

2. Navigate to the frontend directory:
   ```bash
   cd Frontend
   ```

3. Install dependencies:
   ```bash
   npm install
   ```

4. Create a `.env` file in the root of the `Frontend` directory and add your backend URL:
   ```env
   VITE_API_BASE_URL=http://localhost:5000/api
   ```

5. Start the development server:
   ```bash
   npm run dev
   ```

## 📂 Project Structure

```text
src/
├── assets/          # Static assets like images and fonts
├── components/      # Reusable UI components (Navbar, Footer, Section components)
│   ├── ui/          # Low-level Shadcn UI components
│   └── agent/       # Agent-specific dashboard components
├── contexts/        # React Context providers (Auth, Theme)
├── hooks/           # Custom React hooks
├── integrations/    # External service configurations
├── pages/           # Page-level components (Home, Properties, Auth, etc.)
├── services/        # API service modules
└── lib/             # Utility functions and library wrappers
```

## 📝 License

This project is licensed under the MIT License.

---

Built with ❤️ by the PropNest Team.
