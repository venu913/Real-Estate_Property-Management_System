const mongoose = require('mongoose');
const Lead = require('./Backend/models/Lead');
require('dotenv').config({ path: './Backend/.env' });

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(async () => {
    const leads = await Lead.find().sort({ createdAt: -1 }).limit(10);
    console.log(JSON.stringify(leads, null, 2));
    process.exit(0);
  })
  .catch(err => console.error(err));
