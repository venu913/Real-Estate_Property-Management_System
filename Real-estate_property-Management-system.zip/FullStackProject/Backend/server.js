const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');
const { MongoMemoryServer } = require('mongodb-memory-server');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const propertiesRoutes = require('./routes/properties');
const agentRoutes = require('./routes/agent');
const leadsRoutes = require('./routes/leads');
const dashboardRoutes = require('./routes/dashboard');
const messagesRoutes = require('./routes/messages');
const leasesRoutes = require('./routes/leases');
const transactionsRoutes = require('./routes/transactions');
const notificationsRoutes = require('./routes/notifications');

const app = express();

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// mockProperties removed

// AGENT_SEEDS removed

// Connect to MongoDB
const connectDB = async () => {
  try {
    let dbUri = process.env.MONGO_URI;
    let mongoServer;

    if (!dbUri) {
      console.log('MONGO_URI not set, starting MongoDB Memory Server...');
      mongoServer = await MongoMemoryServer.create();
      dbUri = mongoServer.getUri();
      console.log('MongoDB Memory Server started at:', dbUri);
    }

    await mongoose.connect(dbUri);
    console.log(`MongoDB connected successfully to ${dbUri}`);

    // Drop properties collection to re-seed with new schema if needed
    // In a real app we'd use migrations, but for this dev setup we'll just re-seed
    const Property = require('./models/Property');
    // await Property.collection.drop().catch(e => console.log('Collection might not exist yet')); // DISABLED — preserving real DB data

    const User = require('./models/User');
    const bcrypt = require('bcryptjs');
    const userCount = await User.countDocuments();
    if (userCount === 0) {
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash('password123', salt);
      await User.create({
        email: 'admin@propnest.com',
        password: hashedPassword,
        full_name: 'PropNest Admin',
        role: 'admin',
      });
      await User.create({
        email: 'buyer@propnest.com',
        password: hashedPassword,
        full_name: 'Test Buyer',
        role: 'user',
        phone: '+91 9000000000',
      });
      console.log('Seeded admin@propnest.com (admin) and buyer@propnest.com (user) / password123');
    }

    // Agent seeding loop removed

    // CITY_GEO removed

    // Property seeding removed

  } catch (err) {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  }
};

connectDB();

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/properties', propertiesRoutes);
app.use('/api/agent', agentRoutes);
app.use('/api/leads', leadsRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/messages', messagesRoutes);
app.use('/api/leases', leasesRoutes);
app.use('/api/transactions', transactionsRoutes);
app.use('/api/notifications', notificationsRoutes);

app.get('/', (req, res) => {
  res.send('PropNest API is running');
});

// Create HTTP server for Socket.io
const server = http.createServer(app);

// Initialize Socket.io
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    methods: ["GET", "POST"]
  }
});

// Socket.io connection handling
io.on('connection', (socket) => {
  console.log('User connected to dashboard:', socket.id);

  // Join agent-specific room for real-time updates
  socket.on('join-agent-room', (agentId) => {
    socket.join(`agent-${agentId}`);
    console.log(`Agent ${agentId} joined their dashboard room`);
  });

  // Join buyer-specific room for real-time message updates
  socket.on('join-buyer-room', (buyerId) => {
    socket.join(`buyer-${buyerId}`);
    console.log(`Buyer ${buyerId} joined their message room`);
  });

  // Handle disconnection
  socket.on('disconnect', () => {
    console.log('User disconnected from dashboard:', socket.id);
  });
});

// Make io available globally for real-time updates
global.io = io;

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Socket.io server initialized for real-time dashboard updates`);
});
