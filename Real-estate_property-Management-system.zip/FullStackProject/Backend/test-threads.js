require('dotenv').config();
const mongoose = require('mongoose');

async function run() {
  await mongoose.connect(process.env.MONGO_URI);
  require('./models/Property');
  require('./models/User');
  const Lead = require('./models/Lead');
  const Message = require('./models/Message');

  const userId = '69e90f0a281cf06611af1d7b'; // The agent ID
  const userRole = 'agent';

  let filter = { status: 'accepted' };
  if (userRole === 'agent') {
    filter.agent_id = userId;
  } else if (userRole !== 'admin') {
    filter.buyer_user_id = userId;
  }

  const leads = await Lead.find(filter)
    .populate('property_id', 'title city images image')
    .sort({ updatedAt: -1 })
    .lean();

  console.log('Found leads:', leads.length);

  if (!leads.length) return process.exit(0);

  const leadIds = leads.map((l) => l._id);

  const lastMessages = await Message.aggregate([
    { $match: { lead_id: { $in: leadIds } } },
    { $sort: { createdAt: -1 } },
    {
      $group: {
        _id: '$lead_id',
        text: { $first: '$text' },
        createdAt: { $first: '$createdAt' },
        sender_role: { $first: '$sender_role' },
      },
    },
  ]);

  const unreadCounts = await Message.aggregate([
    {
      $match: {
        lead_id: { $in: leadIds },
        sender_id: { $ne: new mongoose.Types.ObjectId(userId) },
        read: false,
      },
    },
    { $group: { _id: '$lead_id', count: { $sum: 1 } } },
  ]);

  const lastMsgMap = {};
  lastMessages.forEach((m) => { lastMsgMap[String(m._id)] = m; });

  const unreadMap = {};
  unreadCounts.forEach((u) => { unreadMap[String(u._id)] = u.count; });

  const threads = leads.map((lead) => {
    const lid = String(lead._id);
    const lm = lastMsgMap[lid];
    const prop = lead.property_id;
    return {
      threadId: lid,
      leadName: lead.name,
      leadEmail: lead.email,
      propertyTitle: prop ? `${prop.title} · ${prop.city || ''}` : 'Property',
      propertyId: prop?._id,
      propertyImage: prop?.images?.[0] || prop?.image || '',
      lastMessage: lm ? lm.text : lead.message || '',
      lastAt: lm ? lm.createdAt : lead.createdAt,
      unread: unreadMap[lid] || 0,
      agentId: lead.agent_id,
      buyerUserId: lead.buyer_user_id,
    };
  });

  console.log('Threads:', threads);

  process.exit(0);
}
run();
