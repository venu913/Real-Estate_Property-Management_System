require('dotenv').config();
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');

async function test() {
  await mongoose.connect(process.env.MONGO_URI);
  const User = mongoose.model('User', new mongoose.Schema({}, {strict: false}));
  
  // Find ALL users who might be an agent or admin
  const users = await User.find({ role: { $in: ['admin', 'agent'] } });

  for (const user of users) {
    const payload = {
      user: {
        id: user._id,
        role: user.role
      }
    };
    const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '5h' });

    try {
      const res = await fetch('http://127.0.0.1:5000/api/messages/threads', {
        headers: { 'x-auth-token': token }
      });
      const data = await res.json();
      console.log(`User ${user._id} (${user.role}) - Threads returned:`, data.length || 0);
    } catch (err) {
      console.log(`User ${user._id} error:`, err.message);
    }
  }

  process.exit(0);
}
test();
