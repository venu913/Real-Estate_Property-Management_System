const express = require('express');
const router = express.Router();
const Message = require('../models/Message');
const Lead = require('../models/Lead');
const auth = require('../middleware/auth');

// All messaging routes require authentication
router.use(auth);

/**
 * GET /api/messages/threads
 * Returns all conversation threads for the current user.
 * - Agent: threads where agent_id matches
 * - Buyer: threads where buyer_user_id matches
 * Each thread is a lead enriched with the last message + unread count.
 */
router.get('/threads', async (req, res) => {
  try {
    const userId = req.user.id;
    let userRole = req.user.role;

    // Fallback in case the JWT token was issued without a role
    if (!userRole) {
      const userDoc = await require('../models/User').findById(userId).select('role').lean();
      userRole = userDoc ? userDoc.role : 'buyer';
    }

    let filter = { status: 'accepted' };
    if (userRole === 'agent') {
      filter.agent_id = userId;
    } else if (userRole !== 'admin') {
      filter.buyer_user_id = userId;
    }

    const leads = await Lead.find(filter)
      .populate('property_id', 'title city images image')
      .sort({ updatedAt: -1 })
      .lean();

    require('fs').appendFileSync('threads_debug.log', JSON.stringify({ userId, userRole, filter, count: leads.length }) + '\n');

    if (!leads.length) return res.json([]);

    const leadIds = leads.map((l) => l._id);

    // Last message per lead
    const lastMessages = await Message.aggregate([
      { $match: { lead_id: { $in: leadIds } } },
      { $sort: { createdAt: -1 } },
      {
        $group: {
          _id: '$lead_id',
          text: { $first: '$text' },
          createdAt: { $first: '$createdAt' },
          sender_role: { $first: '$sender_role' },
        },
      },
    ]);

    // Unread count per lead (messages NOT sent by current user + not read)
    const unreadCounts = await Message.aggregate([
      {
        $match: {
          lead_id: { $in: leadIds },
          sender_id: { $ne: require('mongoose').Types.ObjectId.createFromHexString(userId) },
          read: false,
        },
      },
      { $group: { _id: '$lead_id', count: { $sum: 1 } } },
    ]);

    const lastMsgMap = {};
    lastMessages.forEach((m) => { lastMsgMap[String(m._id)] = m; });

    const unreadMap = {};
    unreadCounts.forEach((u) => { unreadMap[String(u._id)] = u.count; });

    const threads = leads.map((lead) => {
      const lid = String(lead._id);
      const lm = lastMsgMap[lid];
      const prop = lead.property_id;
      return {
        threadId: lid, // lead _id is the thread id
        leadName: lead.name,
        leadEmail: lead.email,
        propertyTitle: prop
          ? `${prop.title} · ${prop.city || ''}`
          : 'Property',
        propertyId: prop?._id,
        propertyImage: prop?.images?.[0] || prop?.image || '',
        lastMessage: lm ? lm.text : lead.message || '',
        lastAt: lm ? lm.createdAt : lead.createdAt,
        unread: unreadMap[lid] || 0,
        agentId: lead.agent_id,
        buyerUserId: lead.buyer_user_id,
      };
    });

    res.json(threads);
  } catch (err) {
    console.error('GET /messages/threads', err);
    res.status(500).json({ message: 'Server Error' });
  }
});

/**
 * GET /api/messages/thread/:leadId
 * Returns all messages in a thread (lead).
 * Also marks received messages as read.
 */
router.get('/thread/:leadId', async (req, res) => {
  try {
    const userId = req.user.id;
    const { leadId } = req.params;

    // Verify access
    const lead = await Lead.findById(leadId).lean();
    if (!lead) return res.status(404).json({ message: 'Thread not found' });

    let userRole = req.user.role;
    if (!userRole) {
      const userDoc = await require('../models/User').findById(userId).select('role').lean();
      userRole = userDoc ? userDoc.role : 'buyer';
    }

    const isOwner = userRole === 'admin' || (userRole === 'agent'
      ? String(lead.agent_id) === userId
      : String(lead.buyer_user_id) === userId);

    if (!isOwner) return res.status(403).json({ message: 'Access denied' });

    // Mark messages from the other side as read
    await Message.updateMany(
      { lead_id: leadId, sender_id: { $ne: userId }, read: false },
      { $set: { read: true } }
    );

    const messages = await Message.find({ lead_id: leadId })
      .sort({ createdAt: 1 })
      .lean();

    res.json(messages);
  } catch (err) {
    console.error('GET /messages/thread/:leadId', err);
    res.status(500).json({ message: 'Server Error' });
  }
});

/**
 * POST /api/messages/thread/:leadId
 * Send a message in a thread.
 */
router.post('/thread/:leadId', async (req, res) => {
  try {
    const userId = req.user.id;
    const { leadId } = req.params;
    const { text } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ message: 'Message text is required' });
    }

    // Verify access
    const lead = await Lead.findById(leadId).lean();
    if (!lead) return res.status(404).json({ message: 'Thread not found' });

    let userRole = req.user.role;
    if (!userRole) {
      const userDoc = await require('../models/User').findById(userId).select('role').lean();
      userRole = userDoc ? userDoc.role : 'buyer';
    }

    const isOwner = userRole === 'admin' || (userRole === 'agent'
      ? String(lead.agent_id) === userId
      : String(lead.buyer_user_id) === userId);

    if (!isOwner) return res.status(403).json({ message: 'Access denied' });

    const isAgent = userRole === 'admin' || userRole === 'agent';
    const senderRole = isAgent ? 'agent' : 'buyer';

    const msg = await Message.create({
      lead_id: leadId,
      sender_id: userId,
      sender_role: senderRole,
      text: text.trim(),
    });

    // Update lead's updatedAt so threads list re-sorts
    await Lead.findByIdAndUpdate(leadId, { updatedAt: new Date() });

    // Emit real-time event via Socket.io
    if (global.io) {
      // Notify agent room
      global.io.to(`agent-${String(lead.agent_id)}`).emit('new-message', {
        leadId,
        message: msg,
      });
      // Notify buyer if connected
      if (lead.buyer_user_id) {
        global.io.to(`buyer-${String(lead.buyer_user_id)}`).emit('new-message', {
          leadId,
          message: msg,
        });
      }
    }

    res.status(201).json(msg);
  } catch (err) {
    console.error('POST /messages/thread/:leadId', err);
    res.status(500).json({ message: 'Server Error' });
  }
});

/**
 * POST /api/messages/start
 * Called when a buyer clicks "Message Agent" on a property.
 * Finds or creates a lead for this buyer+property, then creates the first message.
 */
router.post('/start', async (req, res) => {
  try {
    const userId = req.user.id;
    const { property_id, text, name, email, phone } = req.body;

    if (!property_id) return res.status(400).json({ message: 'property_id required' });

    const Property = require('../models/Property');
    const property = await Property.findById(property_id).lean();
    if (!property) return res.status(404).json({ message: 'Property not found' });

    const agent_id = property.agent_id;
    if (!agent_id) return res.status(400).json({ message: 'Property has no assigned agent' });

    // Find existing lead for this buyer+property
    let lead = await Lead.findOne({ property_id, buyer_user_id: userId });

    if (!lead) {
      lead = await Lead.create({
        property_id,
        agent_id,
        buyer_user_id: userId,
        name: name || 'Buyer',
        email: email || '',
        phone: phone || '',
        message: text || '',
        status: 'new',
      });
    }

    // Create initial message if text provided
    let firstMsg = null;
    if (text && text.trim()) {
      firstMsg = await Message.create({
        lead_id: lead._id,
        sender_id: userId,
        sender_role: 'buyer',
        text: text.trim(),
      });

      // Notify agent
      if (global.io) {
        global.io.to(`agent-${String(agent_id)}`).emit('new-message', {
          leadId: String(lead._id),
          message: firstMsg,
        });
      }
    }

    res.status(201).json({ threadId: String(lead._id), message: firstMsg });
  } catch (err) {
    console.error('POST /messages/start', err);
    res.status(500).json({ message: 'Server Error' });
  }
});

module.exports = router;
