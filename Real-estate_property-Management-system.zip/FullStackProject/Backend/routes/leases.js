const express = require('express');
const router = express.Router();
const Lease = require('../models/Lease');
const auth = require('../middleware/auth');

// @route   GET api/leases/my
// @desc    Get all leases for the logged-in user (as tenant or owner)
// @access  Private
router.get('/my', auth, async (req, res) => {
  try {
    const leases = await Lease.find({
      $or: [
        { tenant_id: req.user.id },
        { owner_id: req.user.id }
      ]
    })
      .populate('property_id', 'title address price')
      .populate('tenant_id', 'name email')
      .populate('owner_id', 'name email')
      .sort({ createdAt: -1 });

    res.json({ success: true, data: leases });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ success: false, message: error.message || 'Server Error' });
  }
});

module.exports = router;
