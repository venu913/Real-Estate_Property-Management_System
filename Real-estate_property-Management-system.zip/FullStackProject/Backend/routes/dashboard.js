const express = require('express');
const router = express.Router();
const { getDashboardStats, getRevenueData, getBookingTrends } = require('../controllers/dashboardController');
const auth = require('../middleware/auth');

// Get dashboard statistics
router.get('/stats', auth, getDashboardStats);

// Get revenue data for charts
router.get('/revenue', auth, getRevenueData);

// Get booking trends
router.get('/bookings/trends', auth, getBookingTrends);

module.exports = router;
