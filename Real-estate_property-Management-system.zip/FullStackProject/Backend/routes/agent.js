const express = require('express');
const router = express.Router();
const agentController = require('../controllers/agentController');
const auth = require('../middleware/auth');
const agentAccess = require('../middleware/agentAccess');

// All agent routes are protected (JWT + agent or admin)
router.use(auth);
router.use(agentAccess);

router.get('/stats', agentController.getStats);
router.get('/leads', agentController.getLeads);
router.get('/leads/recent', agentController.getRecentLeads);
router.get('/properties/top', agentController.getTopProperties);
router.get('/properties', agentController.getProperties);
router.post('/properties', agentController.createProperty);
router.patch('/properties/:id', agentController.updateProperty);
router.delete('/properties/:id', agentController.deleteProperty);
router.patch('/properties/:id/status', agentController.updatePropertyStatus);
router.patch('/leads/:id/status', agentController.updateLeadStatus);
router.delete('/leads/:id', agentController.deleteLead);
router.patch('/leads/:id/notes', agentController.updateLeadNotes);
router.patch('/leads/:id/visit', agentController.respondToVisit);
router.get('/performance', agentController.getPerformance);
router.get('/analytics', agentController.getAnalytics);

module.exports = router;
