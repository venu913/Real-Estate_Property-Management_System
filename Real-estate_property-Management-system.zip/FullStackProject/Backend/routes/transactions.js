const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const auth = require('../middleware/auth');

// @route   GET api/transactions/my
// @desc    Get all transactions for the logged-in user (as buyer or agent)
// @access  Private
router.get('/my', auth, async (req, res) => {
  try {
    const transactions = await Transaction.find({
      $or: [
        { buyerId: req.user.id },
        { agentId: req.user.id }
      ]
    })
      .populate('propertyId', 'title address price')
      .populate('buyerId', 'name email')
      .populate('agentId', 'name email')
      .sort({ transactionDate: -1 });

    res.json({ success: true, data: transactions });
  } catch (error) {
    console.error(error.message);
    res.status(500).json({ success: false, message: error.message || 'Server Error' });
  }
});

module.exports = router;
