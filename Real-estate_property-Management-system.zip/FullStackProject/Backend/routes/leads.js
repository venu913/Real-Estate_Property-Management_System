const express = require('express');
const router = express.Router();
const Lead = require('../models/Lead');
const Property = require('../models/Property');

// @route   POST api/leads
// @desc    Submit a lead (inquiry OR site-visit request) for a property
// @access  Public (Optional auth for buyer link)
const authOptional = require('../middleware/authOptional');
router.post('/', authOptional, async (req, res) => {
  const {
    property_id, name, email, phone, message,
    // visit scheduling
    lead_type, visit_date, visit_slot, visit_note,
  } = req.body;

  try {
    const property = await Property.findById(property_id);
    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    const agent_id = property.agent_id;
    if (!agent_id) {
      return res.status(400).json({ message: 'This listing has no assigned agent.' });
    }

    const buyer_user_id = req.user ? req.user.id : null;

    const newLead = new Lead({
      property_id,
      agent_id,
      buyer_user_id,
      name,
      email,
      phone,
      message,
      property_title: property.title,
      // visit scheduling fields
      lead_type: lead_type || 'inquiry',
      visit_date: visit_date ? new Date(visit_date) : undefined,
      visit_slot: visit_slot || undefined,
      visit_note: visit_note || undefined,
      // Auto-set status to site_visit if it's a site visit request
      status: lead_type === 'site_visit' ? 'site_visit' : 'new',
      visit_status: lead_type === 'site_visit' ? 'pending' : undefined,
    });

    await newLead.save();

    // Emit real-time notification to agent if socket.io is available
    if (global.io && lead_type === 'site_visit') {
      global.io.to(`agent-${agent_id}`).emit('new-visit-request', {
        lead: newLead,
        property_title: property.title,
      });
    }

    // Create persistent notification for agent (if needed)
    // Not explicitly asked by the user, user wants buyer notifications.
    // However, for completeness, if the agent has notifications, we could add them here.
    // Let's stick to buyer notifications. Actually, the user says "the notifications about schedules and inquiry make them permenent".
    // Since the frontend is BuyerActivityContext, it's mostly buyer notifications.
    // When a buyer creates a lead, we might want to notify them that it was sent successfully.
    if (buyer_user_id) {
      const Notification = require('../models/Notification');
      await Notification.create({
        user_id: buyer_user_id,
        title: lead_type === 'site_visit' ? 'Visit Request Sent' : 'Inquiry Sent',
        body: lead_type === 'site_visit' 
          ? `Your visit request for ${property.title} was sent.`
          : `Your inquiry for ${property.title} was sent.`,
        type: lead_type === 'site_visit' ? 'schedule' : 'inquiry',
        related_lead_id: newLead._id
      });
    }

    res.json({
      message: lead_type === 'site_visit'
        ? 'Visit request sent! The agent will confirm shortly.'
        : 'Inquiry sent successfully!',
      lead_id: newLead._id,
    });
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

const auth = require('../middleware/auth');

// @route   GET api/leads/my-requests
// @desc    Get all inquiries and visit requests for the logged-in buyer
// @access  Private
router.get('/my-requests', auth, async (req, res) => {
  try {
    const leads = await Lead.find({ buyer_user_id: req.user.id })
      .populate('property_id', 'title address price images')
      .populate('agent_id', 'name email')
      .sort({ createdAt: -1 });

    res.json({ success: true, data: leads });
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ success: false, message: err.message || 'Server Error' });
  }
});

module.exports = router;
