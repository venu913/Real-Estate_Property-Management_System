# 🔧 PropNest Backend

This is the server-side component of the PropNest application, providing a secure and scalable API for property management and user authentication.

## 🚀 Features

- **🔐 Authentication**: Secure JWT-based authentication for users and agents.
- **🏠 Property Management**: CRUD operations for property listings with image gallery support.
- **👤 Profile API**: Endpoints for managing user data and saved properties.
- **🛡️ Middleware**: Implementation of Auth and Admin middlewares for protected routes.
- **💾 Database**: Mongoose-based data modeling with optimized schemas.

## 🛠️ Tech Stack

- **Runtime**: [Node.js](https://nodejs.org/)
- **Framework**: [Express.js](https://expressjs.com/)
- **Database**: [MongoDB](https://www.mongodb.com/) with [Mongoose](https://mongoosejs.com/)
- **Authentication**: JsonWebToken (JWT) & BcryptJS
- **Development**: [Nodemon](https://nodemon.io/)
- **Mock DB**: `mongodb-memory-server` (used for development/testing without a local MongoDB setup)

## 📋 API Endpoints

### Auth Routes (`/api/auth`)
- `POST /signup` - Register a new user
- `POST /login` - Login user and get token
- `POST /forgot-password` - Request password reset
- `POST /reset-password` - Update password

### Property Routes (`/api/properties`)
- `GET /` - List all properties
- `GET /:id` - Get single property details
- `POST /` - Create a new property (Agent/Admin)
- `POST /seed` - Seed the database with initial data

### User Routes (`/api/users`)
- `GET /profile` - Get current user profile
- `PUT /profile` - Update profile data
- `POST /saved/:propertyId` - Save/unsave a property

## ⚙️ Configuration

Create a `.env` file in the `Backend` directory:
```env
PORT=5000
JWT_SECRET=your_jwt_secret_key
# MONGODB_URI=your_mongodb_connection_string (Optional, will use memory server if omitted)
```

## 🏃 Running the Server

```bash
npm install
npm run dev
```
