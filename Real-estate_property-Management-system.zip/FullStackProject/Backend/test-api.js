require('dotenv').config();
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');

async function test() {
  await mongoose.connect(process.env.MONGO_URI);
  const User = mongoose.model('User', new mongoose.Schema({}, {strict: false}));
  
  // Find an admin or the agent
  const user = await User.findOne({ _id: '69e90f0a281cf06611af1d7b' }); // Agent
  if (!user) {
    console.log("Agent not found!");
    process.exit(1);
  }

  // Generate token exactly like authController
  const payload = {
    user: {
      id: user._id,
      role: user.role
    }
  };

  const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '5h' });

  try {
    const res = await fetch('http://127.0.0.1:5000/api/messages/threads', {
      headers: { 'x-auth-token': token }
    });
    console.log("Status:", res.status);
    const data = await res.json();
    console.log("Data:", data);
  } catch (err) {
    console.log("Error:", err.message);
  }
  process.exit(0);
}
test();
