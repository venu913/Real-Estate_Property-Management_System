const fs = require('fs');
const path = 'c:/Full_stack_Real-estate/FullStackProject/Backend/server.js';
let content = fs.readFileSync(path, 'utf8');

// 1. Remove mockProperties array
content = content.replace(/\/\/ mock data for seeding[\s\S]*?const mockProperties = \[[\s\S]*?\];/g, '// mockProperties removed');

// 2. Remove AGENT_SEEDS array
content = content.replace(/\/\*\* One User per listing agent[\s\S]*?const AGENT_SEEDS = \[[\s\S]*?\];/g, '// AGENT_SEEDS removed');

// 3. Remove agent seeding loop
content = content.replace(/const saltAgents = await bcrypt\.genSalt\(10\);[\s\S]*?console\.log\(`Ensured \$\{AGENT_SEEDS\.length\} listing agent accounts \(password123\)`\);/g, '// Agent seeding loop removed');

// 4. Remove CITY_GEO and geoForProperty
content = content.replace(/const CITY_GEO = \{[\s\S]*?function geoForProperty\(p, index\) \{[\s\S]*?\}/g, '// CITY_GEO removed');

// 5. Remove Seed properties insertMany block
content = content.replace(/\/\/ Seed properties \(each listing has exactly one agent_id\)[\s\S]*?console\.log\('Seeded mock properties with updated schema'\);/g, '// Property seeding removed');

fs.writeFileSync(path, content);
console.log('Cleanup script finished');
