const Property = require('../models/Property');
const Lead = require('../models/Lead');
const User = require('../models/User');
const mongoose = require('mongoose');
const Transaction = require('../models/Transaction');
const Lease = require('../models/Lease');

function propertyScope(req, extra = {}) {
  if (req.accessRole === 'admin') return extra;
  return { ...extra, agent_id: new mongoose.Types.ObjectId(req.user.id) };
}

function leadScope(req, extra = {}) {
  if (req.accessRole === 'admin') return extra;
  return { ...extra, agent_id: new mongoose.Types.ObjectId(req.user.id) };
}

// Get agent stats
exports.getStats = async (req, res) => {
  try {
    const [totalProperties, activeProperties, totalLeads, newLeads] = await Promise.all([
      Property.countDocuments(propertyScope(req)),
      Property.countDocuments(propertyScope(req, { status: 'available' })),
      Lead.countDocuments(leadScope(req)),
      Lead.countDocuments(leadScope(req, { status: 'new' })),
    ]);

    res.json({
      totalProperties,
      activeProperties,
      totalLeads,
      newLeads
    });
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Get agent leads
exports.getLeads = async (req, res) => {
  try {
    const leads = await Lead.find(leadScope(req)).sort({ createdAt: -1 });
    res.json(leads);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Get recent leads (limit 5)
exports.getRecentLeads = async (req, res) => {
  try {
    const leads = await Lead.find(leadScope(req)).sort({ createdAt: -1 }).limit(5);
    res.json(leads);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Get agent properties
exports.getProperties = async (req, res) => {
  try {
    const properties = await Property.find(propertyScope(req)).sort({ createdAt: -1 });
    res.json(properties);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Create property
exports.createProperty = async (req, res) => {
  try {
    let agent_id;
    if (req.accessRole === 'agent') {
      agent_id = req.user.id;
    } else {
      agent_id = req.body.agent_id;
      if (!agent_id) {
        return res.status(400).json({ message: 'Admin must pass agent_id for the listing agent.' });
      }
      const listingAgent = await User.findById(agent_id).select('role');
      if (!listingAgent || listingAgent.role !== 'agent') {
        return res.status(400).json({ message: 'agent_id must reference a user with role agent.' });
      }
    }

    const { agent_id: _omit, ...rest } = req.body;
    const listingUser = await User.findById(agent_id).select('full_name phone');
    const property = new Property({
      ...rest,
      agent_id,
      agent: {
        name: listingUser?.full_name || rest.agent?.name || '',
        phone: listingUser?.phone || rest.agent?.phone || '',
        avatar: rest.agent?.avatar || '',
      },
    });
    await property.save();
    res.status(201).json(property);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Update property
exports.updateProperty = async (req, res) => {
  try {
    const filter = propertyScope(req, { _id: req.params.id });
    const property = await Property.findOneAndUpdate(filter, req.body, { new: true });

    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    res.json(property);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Delete property
exports.deleteProperty = async (req, res) => {
  try {
    const filter = propertyScope(req, { _id: req.params.id });
    const property = await Property.findOneAndDelete(filter);

    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    res.json({ message: 'Property deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Update property status
exports.updatePropertyStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const filter = propertyScope(req, { _id: req.params.id });
    const property = await Property.findOneAndUpdate(filter, { status }, { new: true });

    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    res.json(property);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Update lead status
exports.updateLeadStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const filter = leadScope(req, { _id: req.params.id });
    const lead = await Lead.findOneAndUpdate(filter, { status }, { new: true });

    if (!lead) {
      return res.status(404).json({ message: 'Lead not found' });
    }

    if (status === 'accepted' && lead.buyer_user_id) {
      const property = await Property.findById(lead.property_id);
      if (property) {
        if (property.listing_type === 'rent') {
          const existingLease = await Lease.findOne({ bookingId: lead._id });
          if (!existingLease) {
            await Lease.create({
              tenant_id: lead.buyer_user_id,
              owner_id: req.user.id,
              property_id: lead.property_id,
              bookingId: lead._id,
              status: 'active',
              startDate: new Date()
            });
          }
        } else if (property.listing_type === 'sale') {
          const existingTransaction = await Transaction.findOne({ bookingId: lead._id });
          if (!existingTransaction) {
            await Transaction.create({
              buyerId: lead.buyer_user_id,
              agentId: req.user.id,
              propertyId: lead.property_id,
              bookingId: lead._id,
              status: 'pending',
              amount: property.price || 0,
              commission: 0,
              paymentMethod: 'online'
            });
          }
        }
      }
    }

    res.json(lead);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Delete a lead
exports.deleteLead = async (req, res) => {
  try {
    const filter = leadScope(req, { _id: req.params.id });
    const lead = await Lead.findOneAndDelete(filter);

    if (!lead) {
      return res.status(404).json({ message: 'Lead not found' });
    }

    res.json({ message: 'Lead deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Update lead notes
exports.updateLeadNotes = async (req, res) => {
  try {
    const { notes } = req.body;
    const filter = leadScope(req, { _id: req.params.id });
    const lead = await Lead.findOneAndUpdate(filter, { notes }, { new: true });

    if (!lead) {
      return res.status(404).json({ message: 'Lead not found' });
    }

    res.json(lead);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Get top performing properties (by views desc)
exports.getTopProperties = async (req, res) => {
  try {
    const properties = await Property.find(propertyScope(req))
      .sort({ views: -1 })
      .limit(5)
      .select('title price views inquiries status');
    res.json(properties);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Get performance data over a time range
exports.getPerformance = async (req, res) => {
  try {
    const { range = '30d' } = req.query;
    const days = range === '7d' ? 7 : range === '90d' ? 90 : 30;
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    const leadMatch = { ...leadScope(req), createdAt: { $gte: since } };

    const leadsByDay = await Lead.aggregate([
      { $match: leadMatch },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          inquiries: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    const map = {};
    leadsByDay.forEach((d) => { map[d._id] = d.inquiries; });

    const result = Array.from({ length: days }, (_, i) => {
      const d = new Date(Date.now() - (days - 1 - i) * 24 * 60 * 60 * 1000);
      const key = d.toISOString().slice(0, 10);
      return {
        date: d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short' }),
        inquiries: map[key] || 0,
        views: 0,
        conversions: 0,
      };
    });

    res.json(result);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};

// Respond to a visit request (confirm / reschedule / cancel)
exports.respondToVisit = async (req, res) => {
  try {
    const { visit_status, visit_agent_date, visit_agent_slot, visit_agent_message } = req.body;
    const filter = leadScope(req, { _id: req.params.id });
    const lead = await Lead.findOne(filter);

    if (!lead) return res.status(404).json({ message: 'Lead not found' });
    if (lead.lead_type !== 'site_visit') {
      return res.status(400).json({ message: 'This lead is not a site-visit request' });
    }

    lead.visit_status = visit_status;
    if (visit_agent_date) lead.visit_agent_date = new Date(visit_agent_date);
    if (visit_agent_slot) lead.visit_agent_slot = visit_agent_slot;
    if (visit_agent_message) lead.visit_agent_message = visit_agent_message;

    // Auto-update lead status
    if (visit_status === 'confirmed') lead.status = 'site_visit';
    if (visit_status === 'cancelled') lead.status = 'lost';
    if (visit_status === 'rescheduled') lead.status = 'site_visit';

    await lead.save();

    // Notify buyer in real-time if they're connected
    if (global.io && lead.buyer_user_id) {
      global.io.to(`buyer-${lead.buyer_user_id}`).emit('visit-response', {
        lead_id: lead._id,
        visit_status: lead.visit_status,
        visit_agent_date: lead.visit_agent_date,
        visit_agent_slot: lead.visit_agent_slot,
        visit_agent_message: lead.visit_agent_message,
      });
    }

    // Create persistent notification for buyer
    if (lead.buyer_user_id) {
      const Notification = require('../models/Notification');
      await Notification.create({
        user_id: lead.buyer_user_id,
        title: 'Visit Schedule Updated',
        body: `Your visit request was ${visit_status} by the agent.`,
        type: 'schedule',
        related_lead_id: lead._id
      });
    }

    res.json(lead);
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};
exports.getAnalytics = async (req, res) => {
  try {
    const scope = propertyScope(req);

    // All agent properties
    const properties = await Property.find(scope)
      .select('title views saves inquiries createdAt')
      .lean();

    const totalViews    = properties.reduce((s, p) => s + (p.views    || 0), 0);
    const totalSaves    = properties.reduce((s, p) => s + (p.saves    || 0), 0);
    const totalInquiries = properties.reduce((s, p) => s + (p.inquiries || 0), 0);

    // Lead count matches actual Lead docs (ground truth for inquiries)
    const leadCount = await Lead.countDocuments(leadScope(req));

    // Get actual inquiry counts per property
    const leadsByProperty = await Lead.aggregate([
      { $match: leadScope(req) },
      { $group: { _id: '$property_id', count: { $sum: 1 } } }
    ]);
    const inquiryMap = {};
    leadsByProperty.forEach(l => { 
      if(l._id) inquiryMap[l._id.toString()] = l.count; 
    });

    // Per-property breakdown (top 8 by views + inquiries)
    const propertyPerf = properties
      .map(p => {
        const trueInquiries = inquiryMap[p._id.toString()] || p.inquiries || 0;
        return { ...p, trueInquiries };
      })
      .sort((a, b) => ((b.views || 0) + b.trueInquiries) - ((a.views || 0) + a.trueInquiries))
      .slice(0, 8)
      .map(p => ({
        name: p.title.length > 18 ? p.title.slice(0, 18) + '…' : p.title,
        views: p.views || 0,
        saves: p.saves || 0,
        inquiries: p.trueInquiries,
      }));

    // Weekly lead trend — last 8 weeks
    const weeks = 8;
    const since = new Date(Date.now() - weeks * 7 * 24 * 60 * 60 * 1000);
    const leadsByWeek = await Lead.aggregate([
      { $match: { ...leadScope(req), createdAt: { $gte: since } } },
      {
        $group: {
          _id: { $isoWeek: '$createdAt' },
          year: { $first: { $isoWeekYear: '$createdAt' } },
          inquiries: { $sum: 1 },
        },
      },
      { $sort: { year: 1, _id: 1 } },
    ]);

    // Build a map keyed by ISO week number
    const weekMap = {};
    leadsByWeek.forEach(w => { weekMap[w._id] = w.inquiries; });

    // Generate last 8 ISO weeks
    const weekSeries = Array.from({ length: weeks }, (_, i) => {
      const d = new Date(Date.now() - (weeks - 1 - i) * 7 * 24 * 60 * 60 * 1000);
      // ISO week number
      const tmp = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
      tmp.setUTCDate(tmp.getUTCDate() + 4 - (tmp.getUTCDay() || 7));
      const yearStart = new Date(Date.UTC(tmp.getUTCFullYear(), 0, 1));
      const isoWeek = Math.ceil((((tmp - yearStart) / 86400000) + 1) / 7);
      return {
        week: `W${i + 1}`,
        inquiries: weekMap[isoWeek] || 0,
      };
    });

    res.json({
      totals: {
        views: totalViews,
        saves: totalSaves,
        inquiries: leadCount,          // use Lead doc count as ground truth
        properties: properties.length,
      },
      propertyPerf,
      weekSeries,
    });
  } catch (error) {
    res.status(500).json({ message: 'Server Error', error: error.message });
  }
};
