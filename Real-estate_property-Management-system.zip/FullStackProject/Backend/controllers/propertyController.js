const Property = require('../models/Property');

// Helper function to emit dashboard updates
const emitDashboardUpdate = (type, data, agentId) => {
  if (global.io) {
    const updateData = {
      type,
      data,
      timestamp: new Date()
    };
    
    // Emit to all connected clients for general updates
    global.io.emit('dashboard-update', updateData);
    
    // Emit to specific agent room if agentId is provided
    if (agentId) {
      global.io.to(`agent-${agentId}`).emit('agent-dashboard-update', updateData);
    }
  }
};

function escapeRegex(str) {
  return String(str).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Get all properties (supports query filters for listing search)
exports.getProperties = async (req, res) => {
  try {
    const {
      q,
      city,
      listingType,
      category,
      minPrice,
      maxPrice,
      bhk,
      amenities,
      sort,
    } = req.query;

    const filter = {};

    if (city && String(city).trim()) {
      filter.city = new RegExp(`^${escapeRegex(String(city).trim())}$`, 'i');
    }

    if (listingType && listingType !== 'all') {
      filter.listing_type = listingType;
    }

    if (category && category !== 'all' && String(category).trim()) {
      filter.category = new RegExp(`^${escapeRegex(String(category).trim())}$`, 'i');
    }

    const min = minPrice !== undefined && minPrice !== '' ? Number(minPrice) : NaN;
    const max = maxPrice !== undefined && maxPrice !== '' ? Number(maxPrice) : NaN;
    if (!Number.isNaN(min) || !Number.isNaN(max)) {
      filter.price = {};
      if (!Number.isNaN(min)) filter.price.$gte = min;
      if (!Number.isNaN(max)) filter.price.$lte = max;
    }

    if (bhk && bhk !== 'all') {
      if (bhk === '4+') {
        filter.bedrooms = { $gte: 4 };
      } else {
        const n = Number(bhk);
        if (!Number.isNaN(n)) filter.bedrooms = n;
      }
    }

    if (amenities && String(amenities).trim()) {
      const list = String(amenities)
        .split(',')
        .map((a) => a.trim())
        .filter(Boolean);
      if (list.length) {
        filter.amenities = { $all: list };
      }
    }

    if (q && String(q).trim()) {
      const rx = new RegExp(escapeRegex(String(q).trim()), 'i');
      filter.$or = [
        { title: rx },
        { city: rx },
        { location: rx },
        { description: rx },
      ];
    }

    let sortOption = { createdAt: -1 };
    if (sort === 'price-asc') sortOption = { price: 1 };
    else if (sort === 'price-desc') sortOption = { price: -1 };
    else if (sort === 'popularity') sortOption = { reviews: -1, rating: -1 };

    const properties = await Property.find(filter).sort(sortOption);
    res.json(properties);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// Create a new property
exports.createProperty = async (req, res) => {
  try {
    const propertyData = req.body;
    const property = new Property(propertyData);
    await property.save();

    // Emit real-time dashboard update
    emitDashboardUpdate('property-created', property, req.user.id);

    res.status(201).json(property);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// Update a property
exports.updateProperty = async (req, res) => {
  try {
    const propertyId = req.params.id;
    const propertyData = req.body;
    const property = await Property.findByIdAndUpdate(propertyId, propertyData, {
      new: true,
    });

    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }

    // Emit real-time dashboard update
    emitDashboardUpdate('property-updated', property, req.user.id);

    res.json(property);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};

// Get a single property by ID
exports.getPropertyById = async (req, res) => {
  try {
    const property = await Property.findById(req.params.id).populate(
      'agent_id',
      'full_name email phone',
    );
    if (!property) {
      return res.status(404).json({ message: 'Property not found' });
    }
    const out = property.toObject();
    if (out.agent_id && typeof out.agent_id === 'object') {
      out.agent = {
        ...out.agent,
        name: out.agent_id.full_name || out.agent?.name,
        phone: out.agent_id.phone || out.agent?.phone,
      };
    }
    res.json(out);
  } catch (error) {
    res.status(500).json({ message: 'Server Error' });
  }
};
