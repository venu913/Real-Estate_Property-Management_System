const mongoose = require('mongoose');
const Property = require('../models/Property');
const User = require('../models/User');
const Booking = require('../models/Booking');
const Transaction = require('../models/Transaction');

// Get real-time dashboard statistics
const getDashboardStats = async (req, res) => {
  try {
    const agentId = req.user?.id; // Get agent ID from authenticated user
    
    // Get total counts with aggregation
    const [
      totalProperties,
      totalUsers,
      totalBookings,
      totalRevenue,
      activeListings,
      soldProperties,
      monthlyBookings,
      monthlyRevenue
    ] = await Promise.all([
      // Total Properties (for this agent or all if admin)
      Property.countDocuments(agentId ? { agentId } : {}),
      
      // Total Users
      User.countDocuments({ role: 'buyer' }),
      
      // Total Bookings
      Booking.countDocuments(agentId ? { agentId } : {}),
      
      // Total Revenue (from completed transactions)
      Transaction.aggregate([
        {
          $match: agentId ? { 
            agentId: mongoose.Types.ObjectId(agentId),
            status: 'completed' 
          } : { 
            status: 'completed' 
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$amount' }
          }
        }
      ]),
      
      // Active Listings
      Property.countDocuments(agentId ? { 
        agentId, 
        status: 'available' 
      } : { 
        status: 'available' 
      }),
      
      // Sold Properties
      Property.countDocuments(agentId ? { 
        agentId, 
        status: 'sold' 
      } : { 
        status: 'sold' 
      }),
      
      // Monthly Bookings
      Booking.countDocuments({
        ...agentId && { agentId },
        bookingDate: {
          $gte: new Date(new Date().setDate(1)) // First day of current month
        }
      }),
      
      // Monthly Revenue
      Transaction.aggregate([
        {
          $match: {
            ...agentId && { agentId: mongoose.Types.ObjectId(agentId) },
            status: 'completed',
            transactionDate: {
              $gte: new Date(new Date().setDate(1)) // First day of current month
            }
          }
        },
        {
          $group: {
            _id: null,
            total: { $sum: '$amount' }
          }
        }
      ])
    ]);

    // Format the response
    const stats = {
      totalProperties,
      totalUsers,
      totalBookings,
      totalRevenue: totalRevenue[0]?.total || 0,
      activeListings,
      soldProperties,
      monthlyBookings,
      monthlyRevenue: monthlyRevenue[0]?.total || 0,
      lastUpdated: new Date()
    };

    res.json({
      success: true,
      data: stats
    });

  } catch (error) {
    console.error('Dashboard Stats Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch dashboard statistics',
      error: error.message
    });
  }
};

// Get revenue data for charts
const getRevenueData = async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    const agentId = req.user?.id;
    
    let startDate;
    switch (period) {
      case '7d':
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        break;
      default: // 30d
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    }

    const revenueData = await Transaction.aggregate([
      {
        $match: {
          ...agentId && { agentId: mongoose.Types.ObjectId(agentId) },
          status: 'completed',
          transactionDate: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$transactionDate"
            }
          },
          revenue: { $sum: "$amount" },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { "_id": 1 }
      }
    ]);

    res.json({
      success: true,
      data: revenueData
    });

  } catch (error) {
    console.error('Revenue Data Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch revenue data',
      error: error.message
    });
  }
};

// Get booking trends data
const getBookingTrends = async (req, res) => {
  try {
    const { period = '30d' } = req.query;
    const agentId = req.user?.id;
    
    let startDate;
    switch (period) {
      case '7d':
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
        break;
      case '90d':
        startDate = new Date(Date.now() - 90 * 24 * 60 * 60 * 1000);
        break;
      default: // 30d
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    }

    const bookingData = await Booking.aggregate([
      {
        $match: {
          ...agentId && { agentId: mongoose.Types.ObjectId(agentId) },
          bookingDate: { $gte: startDate }
        }
      },
      {
        $group: {
          _id: {
            $dateToString: {
              format: "%Y-%m-%d",
              date: "$bookingDate"
            }
          },
          count: { $sum: 1 }
        }
      },
      {
        $sort: { "_id": 1 }
      }
    ]);

    res.json({
      success: true,
      data: bookingData
    });

  } catch (error) {
    console.error('Booking Trends Error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch booking trends',
      error: error.message
    });
  }
};

module.exports = {
  getDashboardStats,
  getRevenueData,
  getBookingTrends
};
