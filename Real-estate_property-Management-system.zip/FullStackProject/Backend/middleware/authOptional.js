const jwt = require('jsonwebtoken');

module.exports = function (req, res, next) {
  const authHeader = req.header('Authorization');

  if (!authHeader) {
    return next(); // Proceed without req.user
  }

  const token = authHeader.replace('Bearer ', '');

  if (!token) {
    return next();
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'propnest_secret_key_2024');
    req.user = decoded.user; // Contains id, role, email
    next();
  } catch (err) {
    // If token is invalid, just act like no user
    next();
  }
};
