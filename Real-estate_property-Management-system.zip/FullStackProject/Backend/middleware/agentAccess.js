const User = require('../models/User');

/**
 * After `auth` JWT middleware: loads DB role and allows only agents and admins.
 * Sets req.accessRole to 'agent' | 'admin'.
 */
module.exports = async function agentAccess(req, res, next) {
  try {
    const user = await User.findById(req.user.id).select('role is_agent');
    if (!user) {
      return res.status(401).json({ message: 'User not found' });
    }

    if (user.role === 'admin' || user.role === 'agent' || user.is_agent === true) {
      req.accessRole = user.role === 'admin' ? 'admin' : 'agent';
      return next();
    }

    return res.status(403).json({ message: 'Agent or admin access required' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};
