const mongoose = require('mongoose');

const notificationSchema = new mongoose.Schema({
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: {
    type: String,
    required: true
  },
  body: {
    type: String,
    required: true
  },
  type: {
    type: String, // 'schedule', 'inquiry', 'system'
    default: 'system'
  },
  read: {
    type: Boolean,
    default: false
  },
  related_lead_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Lead'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Notification', notificationSchema);
