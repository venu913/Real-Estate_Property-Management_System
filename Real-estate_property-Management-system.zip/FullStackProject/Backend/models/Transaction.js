const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  propertyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property',
    required: true
  },
  buyerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  agentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  bookingId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Booking',
    required: true
  },
  amount: {
    type: Number,
    required: true
  },
  commission: {
    type: Number,
    required: true
  },
  transactionDate: {
    type: Date,
    default: Date.now
  },
  status: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded'],
    default: 'pending'
  },
  paymentMethod: {
    type: String,
    enum: ['cash', 'bank_transfer', 'online', 'loan'],
    required: true
  },
  documents: [{
    type: String,
    url: String
  }]
}, {
  timestamps: true
});

// Index for better query performance
transactionSchema.index({ transactionDate: -1 });
transactionSchema.index({ status: 1 });
transactionSchema.index({ agentId: 1 });

module.exports = mongoose.model('Transaction', transactionSchema);
