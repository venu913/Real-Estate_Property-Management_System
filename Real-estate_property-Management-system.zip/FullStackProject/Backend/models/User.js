const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true,
  },
  password: {
    type: String,
    required: true,
  },
  full_name: {
    type: String,
    required: true,
  },
  /** Primary access level: admin, agent, or normal user (buyer). */
  role: {
    type: String,
    enum: ['admin', 'agent', 'user'],
    default: 'user',
  },
  is_agent: {
    type: Boolean,
    default: false,
  },
  phone: {
    type: String,
  },
  savedProperties: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property'
  }],
  // --- Agent Advanced Profile Fields ---
  avatar_url: { type: String },
  cover_url: { type: String },
  bio: { type: String },
  city: { type: String },
  state: { type: String },
  languages: [{ type: String }],
  specialization: [{ type: String }],
  experience_years: { type: Number, default: 0 },
  certifications: [{ type: String }],
  agency_name: { type: String },
  rera_number: { type: String },
  website: { type: String },
  social: {
    whatsapp: { type: String },
    linkedin: { type: String },
    instagram: { type: String },
    youtube: { type: String },
  },
  show_contact: { type: Boolean, default: true },
  availability: { type: String, enum: ['Available', 'Busy'], default: 'Available' },
  public_profile: { type: Boolean, default: true },
  rating: { type: Number, default: 0, min: 0, max: 5 },
  rating_count: { type: Number, default: 0 },
  // -------------------------------------
  roles: [{
    type: String
  }]
}, {
  timestamps: true,
});

userSchema.pre('save', function () {
  if (!this.role) {
    this.role = this.is_agent ? 'agent' : 'user';
  }
  if (this.role === 'agent') {
    this.is_agent = true;
    this.roles = ['agent', 'user'];
  } else if (this.role === 'admin') {
    this.is_agent = false;
    this.roles = ['admin'];
  } else {
    this.is_agent = false;
    this.roles = ['user'];
  }
});

module.exports = mongoose.model('User', userSchema);
