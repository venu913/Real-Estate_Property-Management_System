const mongoose = require('mongoose');

const leadSchema = new mongoose.Schema({
  property_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Property',
    required: true
  },
  agent_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  // Optional: if lead was submitted by a logged-in buyer user
  buyer_user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null,
  },
  name: {
    type: String,
    required: true
  },
  email: {
    type: String,
    required: true
  },
  phone: {
    type: String
  },
  message: {
    type: String
  },
  notes: {
    type: String
  },
  status: {
    type: String,
    enum: ['new', 'contacted', 'interested', 'site_visit', 'negotiation', 'closed', 'lost', 'accepted', 'rejected'],
    default: 'new'
  },
  // ─── Visit Scheduling ────────────────────────────────────────────────
  lead_type: {
    type: String,
    enum: ['inquiry', 'site_visit'],
    default: 'inquiry',
  },
  property_title: { type: String },   // cached for easy display
  // Buyer's requested slot
  visit_date: { type: Date },
  visit_slot: { type: String },       // e.g. "9-11", "2-4"
  visit_note: { type: String },
  // Agent's response
  visit_status: {
    type: String,
    enum: ['pending', 'confirmed', 'rescheduled', 'cancelled', 'rejected'],
    default: 'pending',
  },
  visit_agent_date: { type: Date },   // agent suggests different date
  visit_agent_slot: { type: String }, // agent suggests different slot
  visit_agent_message: { type: String },
  // ─────────────────────────────────────────────────────────────────────
}, {
  timestamps: true
});

module.exports = mongoose.model('Lead', leadSchema);
