const mongoose = require('mongoose');

const propertySchema = new mongoose.Schema({
  title: { type: String, required: true },
  location: { type: String, required: true },
  address: { type: String },
  city: { type: String, required: true },
  state: { type: String, default: 'Maharashtra' },
  price: { type: Number, required: true },
  priceUnit: { type: String, required: true },
  type: { type: String }, // Keep for compatibility
  listing_type: { type: String, default: 'sale' },
  category: { type: String, required: true },
  bedrooms: { type: Number, default: 0 },
  bathrooms: { type: Number, default: 0 },
  area: { type: Number }, // Keep for compatibility
  area_sqft: { type: Number, required: true },
  areaUnit: { type: String, default: 'sqft' },
  image: { type: String, required: true },
  images: [{ type: String }],
  amenities: [{ type: String }],
  status: { type: String, default: 'available' },
  featured: { type: Boolean, default: false },
  trending: { type: Boolean, default: false },
  is_verified: { type: Boolean, default: false },
  is_new: { type: Boolean, default: false },
  rating: { type: Number, default: 0 },
  reviews: { type: Number, default: 0 },
  views: { type: Number, default: 0 },
  saves: { type: Number, default: 0 },
  inquiries: { type: Number, default: 0 },
  /** Exactly one listing agent (User with role agent). */
  agent_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  agent: {
    name: { type: String },
    avatar: { type: String },
    phone: { type: String }
  },
  description: { type: String, required: true },
  yearBuilt: { type: Number },
  furnished: { type: String },
  furnishing: { type: String }, // For frontend compatibility
  parking: { type: Number, default: 0 },
  floor: { type: String },
  facing: { type: String },
  latitude: { type: Number },
  longitude: { type: Number },
}, { timestamps: true });

module.exports = mongoose.model('Property', propertySchema);
