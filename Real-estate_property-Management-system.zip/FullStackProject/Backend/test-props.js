require('dotenv').config();
const mongoose = require('mongoose');

async function checkProps() {
  await mongoose.connect(process.env.MONGO_URI);
  const Property = require('./models/Property');
  
  const latest = await Property.find().sort({ createdAt: -1 }).limit(3);
  for (const p of latest) {
    console.log("Title:", p.title);
    console.log("Image type:", typeof p.image);
    console.log("Image length:", p.image ? p.image.length : 'N/A');
    if (p.image) {
      console.log("Image starts with:", p.image.substring(0, 50));
    }
    console.log("---");
  }
  process.exit(0);
}
checkProps();
