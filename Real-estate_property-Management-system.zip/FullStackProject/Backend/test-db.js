require('dotenv').config();
const mongoose = require('mongoose');

async function run() {
  await mongoose.connect(process.env.MONGO_URI);
  const Lead = mongoose.model('Lead', new mongoose.Schema({}, {strict: false}));
  const User = mongoose.model('User', new mongoose.Schema({}, {strict: false}));

  const leads = await Lead.find({ status: 'accepted' });
  console.log('Accepted leads count:', leads.length);
  leads.forEach(l => console.log('Lead ID:', l._id, 'Agent ID:', l.agent_id, 'Buyer ID:', l.buyer_user_id));

  const users = await User.find({ role: { $in: ['admin', 'agent'] } });
  console.log('Admins/Agents:', users.map(u => ({ id: u._id, role: u.role, name: u.name })));

  process.exit(0);
}
run();
